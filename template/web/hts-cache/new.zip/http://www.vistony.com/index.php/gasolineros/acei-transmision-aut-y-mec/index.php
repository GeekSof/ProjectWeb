
<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml" xml:lang="es-es" lang="es-es" dir="ltr" class='com_virtuemart view-category itemid-1108 j34 mm-hover'>
  <head>
        <script type="text/javascript" src="/templates/t3_blank/js/jquery.min.js"></script>
    <script type="text/javascript" src="/templates/t3_blank/js/jquery-migrate.min.js"></script>
    <script type="text/javascript" src="/templates/t3_blank/js/mod_cart.js"></script>
    <!-- google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

      <base href="http://www.vistony.com/index.php/gasolineros/acei-transmision-aut-y-mec/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="lubricante,aceites lubricantes,distribuidora de aceites y lubricantes,aceites lubricantes automotrices,aceites lubricantes industriales,venta de lubricantes" />
  <meta name="title" content="LUBRICANTES PARA TRANSMISIÓN AUTOMÁTICA Y MECÁNICA" />
  <meta name="description" content="Vistony SAC es una empresa con más de 20 años de experiencia especializada en la Fabricación, Comercialización y Distribución de Lubricantes y Grasas de la marca VISTONY enfocada en los segmentos del Sector Industrial, Automotriz y Minero." />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>LUBRICANTES PARA TRANSMISIÓN AUTOMÁTICA Y MECÁNICA</title>
  <link href="/index.php/gasolineros/acei-transmision-aut-y-mec/manufacturer/" rel="canonical" />
  <link href="/index.php/gasolineros/acei-transmision-aut-y-mec?format=feed&type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/index.php/gasolineros/acei-transmision-aut-y-mec?format=feed&type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="/templates/t3_blank/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <link rel="stylesheet" href="/templates/t3_blank/local/css/themes/themeblue/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="/components/com_k2/css/k2.css" type="text/css" />
  <link rel="stylesheet" href="/components/com_virtuemart/assets/css/ui/jquery.ui.all.css?vmver=8847" type="text/css" />
  <link rel="stylesheet" href="/media/system/css/modal.css" type="text/css" />
  <link rel="stylesheet" href="/templates/system/css/system.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/local/css/themes/themeblue/template.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/local/css/themes/themeblue/bootstrap-responsive.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/local/css/themes/themeblue/template-responsive.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/local/css/themes/themeblue/megamenu.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/local/css/themes/themeblue/megamenu-responsive.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/local/css/themes/themeblue/off-canvas.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/fonts/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/css/custom.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/css/animate.css" type="text/css" />
  <link rel="stylesheet" href="/templates/t3_blank/css/custom-responsive.css" type="text/css" />
  <link rel="stylesheet" href="/media/mod_social_slider/css/style.css" type="text/css" />
  <link rel="stylesheet" href="http://www.vistony.com/media/com_uniterevolution2/assets/rs-plugin/css/settings.css" type="text/css" />
  <link rel="stylesheet" href="http://www.vistony.com/index.php?option=com_uniterevolution2&amp;action=getcaptions" type="text/css" />
  <link rel="stylesheet" href="http://www.vistony.com/media/com_uniterevolution2/assets/rs-plugin/css/static-captions.css" type="text/css" />
  <style type="text/css">
@media screen and (max-width: 480px){ul#jj_sl_navigation { display: none; }}ul#jj_sl_navigation li a {background-color:#33353b;text-align:right;color:#ffffff !important;}ul#jj_sl_navigation li { right: 0;position:relative;-webkit-transition: right 0.3s;-moz-transition: right 0.3s;-ms-transition: right 0.3s;-o-transition: right 0.3s;transition: right 0.3s;}ul#jj_sl_navigation { right:-140px;top:250px;}ul#jj_sl_navigation li:hover { right: 140px;}ul#jj_sl_navigation li a { padding: 11px 10px 11px 0px;}ul#jj_sl_navigation .jj_sl_facebook a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/facebook-white.png);
			 }ul#jj_sl_navigation .jj_sl_twitter a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/twitter-white.png);
			 }ul#jj_sl_navigation .jj_sl_google a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/google-white.png);
			 }ul#jj_sl_navigation .jj_sl_myspace a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/myspace-white.png);
			 }ul#jj_sl_navigation .jj_sl_youtube a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/youtube-white.png);
			 }ul#jj_sl_navigation .jj_sl_linkedin a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/linkedin-white.png);
			 }ul#jj_sl_navigation .jj_sl_steam a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/steam-white.png);
			 }ul#jj_sl_navigation .jj_sl_lastfm a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/lastfm-white.png);
			 }ul#jj_sl_navigation .jj_sl_pinterest a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/pinterest-white.png);
			 }ul#jj_sl_navigation .jj_sl_soundcloud a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/soundcloud-white.png);
			 }ul#jj_sl_navigation .jj_sl_tumblr a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/tumblr-white.png);
			 }ul#jj_sl_navigation .jj_sl_github a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/github-white.png);
			 }ul#jj_sl_navigation .jj_sl_flickr a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/flickr-white.png);
			 }ul#jj_sl_navigation .jj_sl_rss a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/rss-white.png);
			 }ul#jj_sl_navigation .jj_sl_vimeo a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/vimeo-white.png);
			 }ul#jj_sl_navigation .jj_sl_custom1 a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/icon_buscador.png);
			 }ul#jj_sl_navigation .jj_sl_custom2 a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/otros_lubricantes.png);
			 }ul#jj_sl_navigation .jj_sl_custom3 a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/icon.png);
			 }ul#jj_sl_navigation .jj_sl_custom4 a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/icon.png);
			 }ul#jj_sl_navigation .jj_sl_custom5 a {
					background-position: 4px 50%;
					background-image: url(http://www.vistony.com/media/mod_social_slider/icons/icon.png);
			 }ul#jj_sl_navigation .jj_sl_custom1 a:hover{
			background-color: #ffffff;
		   }
		   ul#jj_sl_navigation .jj_sl_custom2 a:hover{
			background-color: #000000;
		   }
		   ul#jj_sl_navigation .jj_sl_custom3 a:hover{
			background-color: #000000;
		   }
		   ul#jj_sl_navigation .jj_sl_custom4 a:hover{
			background-color: #000000;
		   }
		   ul#jj_sl_navigation .jj_sl_custom5 a:hover{
			background-color: #000000;
		}
  </style>
  <script src="/media/system/js/mootools-core.js" type="text/javascript"></script>
  <script src="/media/system/js/core.js" type="text/javascript"></script>
  <script src="/components/com_k2/js/k2.js?v2.6.9&amp;sitepath=/" type="text/javascript"></script>
  <script src="/media/system/js/mootools-more.js" type="text/javascript"></script>
  <script src="/media/system/js/modal.js" type="text/javascript"></script>
  <script src="/components/com_virtuemart/assets/js/vmsite.js?vmver=8847" type="text/javascript"></script>
  <script src="/components/com_virtuemart/assets/js/i18n/jquery.ui.datepicker-en-GB.js?vmver=8847" type="text/javascript" defer="defer"></script>
  <script src="/plugins/system/t3/base/bootstrap/js/bootstrap.js" type="text/javascript"></script>
  <script src="/plugins/system/t3/base/js/jquery.tap.min.js" type="text/javascript"></script>
  <script src="/plugins/system/t3/base/js/off-canvas.js" type="text/javascript"></script>
  <script src="/plugins/system/t3/base/js/script.js" type="text/javascript"></script>
  <script src="/plugins/system/t3/base/js/menu.js" type="text/javascript"></script>
  <script src="/plugins/system/t3/base/js/responsive.js" type="text/javascript"></script>
  <script src="/templates/t3_blank/js/vmprices2.js" type="text/javascript"></script>
  <script src="/templates/t3_blank/js/validate.js" type="text/javascript"></script>
  <script src="http://www.vistony.com/media/com_uniterevolution2/assets/rs-plugin/js/jquery.themepunch.tools.min.js" type="text/javascript"></script>
  <script src="http://www.vistony.com/media/com_uniterevolution2/assets/rs-plugin/js/jquery.themepunch.revolution.min.js" type="text/javascript"></script>
  <script src="/media/ajax_scroll/assets/jquery-ias.js" type="text/javascript"></script>
  <script type="text/javascript">

		jQuery(function($) {
			SqueezeBox.initialize({});
			SqueezeBox.assign($('a.modal').get(), {
				parse: 'rel'
			});
		});
		function jModalClose() {
			SqueezeBox.close();
		}
jQuery(document).ready(function () {
	jQuery('.orderlistcontainer').hover(
		function() {
		jQuery(this).find('.orderlist').has('div').stop().show();
		jQuery(this).find('.activeOrder').addClass('hover');
		},
		function() {
		jQuery(this).find('.orderlist').has('div').stop().hide();
		jQuery(this).find('.activeOrder').removeClass('hover');
		}
	)
	jQuery('.orderlistcontainer .orderlist').each(function(){
	 jQuery(this).parent().find('.activeOrder').addClass('block');
	})
});

		jQuery().ready(function() {
			var options = {
				dataType: 'json',
				parse: function(data) {return jQuery.map(data, function(row) {return {data: row,value: row.product_name,result: row.product_name}});},
				minChars:3,
				delay:400,
				selectFirst:false,
				max: 5,
				resultsClass: 'ac_result',
				width:298,
				scrollHeight:false,
				formatItem: function(row) {var item=''; item+='<span class="product_img"><img src="'+ row.product_thumb_path + row.product_thumb_image + '"/></span> ';item+=row.product_name;item+='<br/><span class="product_sku">'+row.product_sku+'</span>';return item;},
				extraParams:{ac:1,option:'com_virtuemart',view:'virtuemart',searchcat:0,searchmanuf:0,searchsku:1,searchchilds:0}
			};
			fresult = function(event, data, formatted){if (data.link) {document.location.href = data.link;}}
			jQuery('.ac_vm[name="keyword"],.ac_vm[type="text"]').autocomplete('index.php',options).result(fresult);

		});
  </script>
  <script type="text/javascript">
                    jQuery.ias({
                     container :  ".loadmore #slider",
                     item: ".item",
                     pagination: ".pagination.vm",
                     next: ".pagination.vm .next a",
                     triggerPageThreshold: "99999",
					 trigger: false,
					 history : false,
                     loader: "<img src=\"/media/ajax_scroll/assets/ajax-loader.gif\"/>",
                     noneleft: false,
					 onRenderComplete: function () {
						 jQuery("#product_list.grid .hasTooltip").tooltip("hide");
						 jQuery("#product_list .vmproduct li").each(function(indx, element){
								var my_product_id = jQuery(this).find(".quick_ids").val();
								jQuery(this).append("<div class=\"quick_btn\" onClick =\"quick_btn("+my_product_id+")\"><i class=\"icon-eye-open\"></i>"+show_quicktext+"</div>");
								jQuery(this).find(".quick_id").remove();
								Virtuemart.product(jQuery("form.product"));
							  jQuery("form.js-recalculate").each(function(){
								if (jQuery(this).find(".product-fields").length) {
								  var id= jQuery(this).find("input[name=\"virtuemart_product_id[]\"]").val();
								  Virtuemart.setproducttype(jQuery(this),id);
								}
							  });
						});
						
				}
						  });
        </script>

    <!-- META FOR IOS & HANDHELD -->
<link href='//fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:800' rel='stylesheet' type='text/css'>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
 
<meta name="HandheldFriendly" content="true" />
<meta name="apple-mobile-web-app-capable" content="YES" />
<!-- //META FOR IOS & HANDHELD -->



<script>
var notAnimate = '1';
</script>
<!--[if lte IE 8]>
    <link rel="stylesheet" type="text/css" href="/templates/t3_blank/css/custom_ie8.css" />
<![endif]-->


<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 8]>
<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!-- For IE6-8 support of media query -->
<!--[if lt IE 9]>
<script type="text/javascript" src="/plugins/system/t3/base/js/respond.min.js"></script>
<![endif]-->
<!--[if lt IE 9]>
    <div style=' clear: both; text-align:center; position: relative; z-index:9999;'>
        <a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="/templates/t3_blank/images/old_browser.jpg" border="0" &nbsp;alt="" /></a>
    </div>
<![endif]-->

<!-- You can add Google Analytics here-->
<!-- You can add Google Analytics here-->  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<!-- GOOGLE ANALYTICS -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48561166-3', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body class="resp  no_content  boxed">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.5&appId=692446717502716";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="boxed-indent">
<div class="boxed-box">


 	 <div class="container cookies_height">
<div class="cookies">

</div>
</div>
<!-- topHEADER -->
<div class="header-top">
<div class="header-top-border">
<div class="container top-header">
    	<!-- SPOTLIGHT -->
	<div class="t3-spotlight t3-topheader  row">
					<div class="span3 item-first" data-default="span3" data-xtablet="span12" data-tablet="span12" data-mobile=" hidden-mobile ">
								&nbsp;
							</div>
					<div class="span5 " data-default="span5" data-xtablet="span12 spanfirst" data-tablet="span12 spanfirst" data-mobile=" span50 hidden-mobile ">
									<div class="t3-module module_topmenu" id="Mod100">
    <div class="module-inner">
                  <div class="module-ct">
      
<ul class="nav ">
<li class="item-1154"><a href="/index.php/la-empresa" >La Empresa</a></li><li class="item-1155"><a href="/index.php/noticias" >Noticias</a></li><li class="item-1157"><a href="/index.php/contacto" >Contacto</a></li><li class="item-1251">	<a href="https://mail.vistony.com/OWA" target="_blank" >e-Corporativo</a></li><li class="item-1274">	<a href="http://www.vistony.com/epicorwebaccess/syslogin.aspx?Return=ui.salesorderentry.salesorderform._c_orderentrysistemasweb.aspx" target="_blank" >Epicor</a></li></ul>
      </div>
    </div>
  </div>
  	
							</div>
					<div class="span2 " data-default="span2" data-xtablet="span6 spanfirst" data-tablet="span6 spanfirst" data-mobile=" span50 hidden-mobile ">
								&nbsp;
							</div>
					<div class="span2 item-last" data-default="span2" data-xtablet="span6" data-tablet="span6" data-mobile=" hidden-mobile ">
								&nbsp;
							</div>
			</div>
<!-- SPOTLIGHT --> </div>
 <div class="clear"></div>
</div>
</div>
<!-- //topHEADER -->
    <div id="head-row" class="nofixed">
		<!-- HEADER -->
<header id="t3-header">
<div class="container header">
    <!-- LOGO -->
    <div class="logo">
      <div class="logo-image">
        <h1>
          <a href="/" title="Vistony" style="background-image:url(/images/vistony/logo/logovistony.png);">
            <span>Vistony</span>
          </a>
          <small class="site-slogan hidden-phone"></small>
        </h1>
      </div>
    </div>
     	<!-- SPOTLIGHT -->
	<div class="t3-spotlight t3-elmentheader  row">
					<div class="span3 item-first" data-default="span3" data-xtablet="span2" data-tablet="span1">
								&nbsp;
							</div>
					<div class="span3 " data-default="span3" data-xtablet="span2" data-tablet=" span6 hidden-tablet " data-mobile=" hidden-mobile ">
									<div class="t3-module module_phone" id="Mod187">
    <div class="module-inner">
                  <div class="module-ct">
      

<div class="custom_phone"  >
	<p style="font-family:Roboto;color:#005EA8">Central <span style="font-family:Roboto;color:#005EA8">(051)01 552-1325</span></p></div>
      </div>
    </div>
  </div>
  	
							</div>
					<div class="span4 " data-default="span4" data-xtablet="span5" data-tablet="span6" data-mobile=" hidden-mobile ">
									<div class="t3-module module_search" id="Mod182">
    <div class="module-inner">
                  <div class="module-ct">
      <!--BEGIN Search Box -->
<form action="/index.php/selector-de-aceites/search" method="get">
<div class="search_search">
<input style="vertical-align :middle;" name="keyword" id="mod_virtuemart_search" maxlength="34" alt="Buscar" class="inputbox_search ac_vm" type="text" size="34" value="Escriba el nombre de su producto"  onblur="if(this.value=='') this.value='Escriba el nombre de su producto';" onfocus="if(this.value=='Escriba el nombre de su producto') this.value='';" /><input type="submit" value="Buscar" class="button_search" /><i class="icon-search"></i></div>
		<input type="hidden" name="limitstart" value="0" />
		<input type="hidden" name="option" value="com_virtuemart" />
		<input type="hidden" name="view" value="category" />

	  </form>
      <div class="ac_result" style="display:none;"></div>

<!-- End Search Box -->
      </div>
    </div>
  </div>
  	
							</div>
					<div class="span2 item-last" data-default="span2" data-xtablet="span3" data-tablet="span6 spanfirst" data-mobile=" span50 hidden-mobile ">
								&nbsp;
							</div>
			</div>
<!-- SPOTLIGHT -->    <!-- //LOGO -->
   
  </div>
</header>
<!-- //HEADER -->
        
<!-- MAIN NAVIGATION -->
<nav id="t3-mainnav" class="wrap t3-mainnav navbar-collapse-fixed-top">
  <div class="container navbar">
    <div class="navbar-inner">
    
      <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
        <i class="icon-reorder"></i>
      </button>

      <div class="nav-collapse collapse always-show">
              <div  class="t3-megamenu animate zoom"  data-duration="400" data-responsive="true">
<ul class="nav navbar-nav level0">
<li class="active dropdown mega mega-align-justify" data-id="1101" data-level="1" data-alignsub="justify">
<a class=" dropdown-toggle" href="#"   data-target="#" data-toggle="dropdown">LUBRICANTES GASOLINEROS<b class="caret"></b></a>

<div class="nav-child dropdown-menu mega-dropdown-menu span12"  ><div class="mega-dropdown-inner">
<div class="row-fluid">
<div class="span5 mega-col-nav" data-width="5"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1107" data-level="2">
<a class="" href="/index.php/gasolineros/lubricantes-para-motor-gasolinero-y-o-gas"   data-target="#"><img src="/images/vistony/menu/lubricantes_para_motores_gasolineros_gas.png" alt="LUBRICANTES PARA MOTOR GASOLINERO Y/O GAS" /><span class="image-title">LUBRICANTES PARA MOTOR GASOLINERO Y/O GAS</span>  </a>

</li>
</ul>
</div></div>
<div class="span5 mega-col-nav" data-width="5"><div class="mega-inner">
<ul class="mega-nav level1">
<li class="current active" data-id="1108" data-level="2">
<a class="" href="/index.php/gasolineros/acei-transmision-aut-y-mec"   data-target="#"><img src="/images/vistony/menu/lubricantes_para_transmision_automatica_mecanica.png" alt="LUBRICANTES PARA TRANSMISIÓN AUTOMÁTICA Y MECÁNICA" /><span class="image-title">LUBRICANTES PARA TRANSMISIÓN AUTOMÁTICA Y MECÁNICA</span>  </a>

</li>
</ul>
</div></div>
</div>
</div></div>
</li>
<li class="dropdown mega mega-align-justify" data-id="1102" data-level="1" data-alignsub="justify">
<a class=" dropdown-toggle" href="#"   data-target="#" data-toggle="dropdown">LUBRICANTES DIÉSEL<b class="caret"></b></a>

<div class="nav-child dropdown-menu mega-dropdown-menu span12"  ><div class="mega-dropdown-inner">
<div class="row-fluid">
<div class="span5 mega-col-nav" data-width="5"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1113" data-level="2">
<a class="" href="/index.php/lubricantes-diesel/lubricantes-para-motor-diesel-y-o-gas"   data-target="#"><img src="/images/vistony/menu/lubricantes_para_motores_diesel_gas.png" alt="LUBRICANTES PARA MOTOR DIESEL Y/O GAS " /><span class="image-title">LUBRICANTES PARA MOTOR DIESEL Y/O GAS </span>  </a>

</li>
</ul>
</div></div>
<div class="span5 mega-col-nav" data-width="5"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1228" data-level="2">
<a class="" href="/index.php/lubricantes-diesel/lubricantes-de-transmision"   data-target="#"><img src="/images/vistony/menu/lubricantes_transmision_diesel.png" alt="LUBRICANTES DE TRANSMISIÓN" /><span class="image-title">LUBRICANTES DE TRANSMISIÓN</span>  </a>

</li>
</ul>
</div></div>
</div>
</div></div>
</li>
<li class="dropdown mega mega-align-justify" data-id="1103" data-level="1" data-alignsub="justify">
<a class=" dropdown-toggle" href="#"   data-target="#" data-toggle="dropdown">LUBRICANTES MOTOS / ACUÁTICOS<b class="caret"></b></a>

<div class="nav-child dropdown-menu mega-dropdown-menu span12"  ><div class="mega-dropdown-inner">
<div class="row-fluid">
<div class="span4 mega-col-nav" data-width="4"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1117" data-level="2">
<a class="" href="/index.php/lubricantes-motos-acuaticos/lubricantes-para-motos-4t"   data-target="#"><img src="/images/vistony/menu/lubricantes_motos_4t.png" alt="LUBRICANTES PARA MOTOS 4T" /><span class="image-title">LUBRICANTES PARA MOTOS 4T</span>  </a>

</li>
</ul>
</div></div>
<div class="span4 mega-col-nav" data-width="4"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1118" data-level="2">
<a class="" href="/index.php/lubricantes-motos-acuaticos/lubricantes-para-motos-2t"   data-target="#"><img src="/images/vistony/menu/lubricantes_motos_2t.png" alt="LUBRICANTES PARA MOTOS 2T" /><span class="image-title">LUBRICANTES PARA MOTOS 2T</span>  </a>

</li>
</ul>
</div></div>
<div class="span4 mega-col-nav" data-width="4"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1162" data-level="2">
<a class="" href="/index.php/lubricantes-motos-acuaticos/acuaticos"   data-target="#"><img src="/images/vistony/menu/aquaticos.png" alt="ACUÁTICOS" /><span class="image-title">ACUÁTICOS</span>  </a>

</li>
</ul>
</div></div>
</div>
</div></div>
</li>
<li class="mega-align-justify" data-id="1105" data-level="1" data-alignsub="justify">
<a class="" href="/index.php/grasas-lubricantes"   data-target="#">GRASAS LUBRICANTES </a>

</li>
<li class="dropdown mega mega-align-justify" data-id="1231" data-level="1" data-alignsub="justify">
<a class=" dropdown-toggle" href="#"   data-target="#" data-toggle="dropdown">COMPLEMENTARIOS<b class="caret"></b></a>

<div class="nav-child dropdown-menu mega-dropdown-menu span12"  ><div class="mega-dropdown-inner">
<div class="row-fluid">
<div class="span2 mega-col-nav" data-width="2"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1232" data-level="2">
<a class="" href="/index.php/complementarios/aditivos"   data-target="#"><img src="/images/vistony/menu/complementarios/aditivo24.png" alt="ADITIVOS" /><span class="image-title">ADITIVOS</span>  </a>

</li>
</ul>
</div></div>
<div class="span2 mega-col-nav" data-width="2"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1233" data-level="2">
<a class="" href="/index.php/complementarios/refrigerantes"   data-target="#"><img src="/images/vistony/menu/complementarios/refrigerantes.png" alt="REFRIGERANTES" /><span class="image-title">REFRIGERANTES</span>  </a>

</li>
</ul>
</div></div>
<div class="span2 mega-col-nav" data-width="2"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1234" data-level="2">
<a class="" href="/index.php/complementarios/liquidos-para-frenos"   data-target="#"><img src="/images/vistony/menu/complementarios/liquido_para_frenos.png" alt="LÍQUIDOS PARA FRENOS" /><span class="image-title">LÍQUIDOS PARA FRENOS</span>  </a>

</li>
</ul>
</div></div>
<div class="span2 mega-col-nav" data-width="2"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1235" data-level="2">
<a class="" href="/index.php/complementarios/cuidado-del-vehiculo"   data-target="#"><img src="/images/vistony/menu/complementarios/cuidado_de_vehiculos.png" alt="CUIDADO DEL VEHÍCULO" /><span class="image-title">CUIDADO DEL VEHÍCULO</span>  </a>

</li>
</ul>
</div></div>
<div class="span2 mega-col-nav" data-width="2"><div class="mega-inner">
<ul class="mega-nav level1">
<li  data-id="1236" data-level="2">
<a class="" href="/index.php/complementarios/otros"   data-target="#"><img src="/images/vistony/menu/complementarios/otros.png" alt="OTROS" /><span class="image-title">OTROS</span>  </a>

</li>
</ul>
</div></div>
</div>
</div></div>
</li>
<li class="mega-align-justify" data-id="1104" data-level="1" data-alignsub="justify">
<a class="" href="http://www.vistony.com/productos-industriales/"   data-target="#">PRODUCTOS INDUSTRIALES</a>

</li>
</ul>
</div>

            </div>
    </div>
  </div>
</nav>
<!-- //MAIN NAVIGATION -->	</div>
    
<div id="Slider">
<div class="container">
  <div class="row">
<!-- topslider -->
   

<!-- //topslider -->
</div>
</div>
         <!-- HEADcustom -->
        <div class="screen head-custom">     
          <!-- START REVOLUTION SLIDER 4.6.92 fullwidth mode -->

<div id="rev_slider_5_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" style="margin:0px auto;background-color:#E9E9E9;padding:0px;margin-top:0px;margin-bottom:0px;max-height:230px;">
	<div id="rev_slider_5_1" class="rev_slider fullwidthabanner" style="display:none;max-height:230px;height:230px;">
<ul>	<!-- SLIDE  1-->
	<li data-transition="notransition" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src="http://www.vistony.com/images/vistony/slider/encabezado/lubricantes_para_transmision_automatica_mecanica.png"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
		<!-- LAYERS -->
	</li>
	<!-- SLIDE  2-->
	<li data-transition="notransition" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src="http://www.vistony.com/images/vistony/slider/encabezado/lubricantes_para_transmision_automatica_mecanica.png"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
		<!-- LAYERS -->
	</li>
</ul>
<div class="tp-bannertimer"></div>	</div>
			
			<script type="text/javascript">

					
				/******************************************
					-	PREPARE PLACEHOLDER FOR SLIDER	-
				******************************************/
								
				 
						var setREVStartSize = function() {
							var	tpopt = new Object(); 
								tpopt.startwidth = 1250;
								tpopt.startheight = 230;
								tpopt.container = jQuery('#rev_slider_5_1');
								tpopt.fullScreen = "off";
								tpopt.forceFullWidth="off";

							tpopt.container.closest(".rev_slider_wrapper").css({height:tpopt.container.height()});tpopt.width=parseInt(tpopt.container.width(),0);tpopt.height=parseInt(tpopt.container.height(),0);tpopt.bw=tpopt.width/tpopt.startwidth;tpopt.bh=tpopt.height/tpopt.startheight;if(tpopt.bh>tpopt.bw)tpopt.bh=tpopt.bw;if(tpopt.bh<tpopt.bw)tpopt.bw=tpopt.bh;if(tpopt.bw<tpopt.bh)tpopt.bh=tpopt.bw;if(tpopt.bh>1){tpopt.bw=1;tpopt.bh=1}if(tpopt.bw>1){tpopt.bw=1;tpopt.bh=1}tpopt.height=Math.round(tpopt.startheight*(tpopt.width/tpopt.startwidth));if(tpopt.height>tpopt.startheight&&tpopt.autoHeight!="on")tpopt.height=tpopt.startheight;if(tpopt.fullScreen=="on"){tpopt.height=tpopt.bw*tpopt.startheight;var cow=tpopt.container.parent().width();var coh=jQuery(window).height();if(tpopt.fullScreenOffsetContainer!=undefined){try{var offcontainers=tpopt.fullScreenOffsetContainer.split(",");jQuery.each(offcontainers,function(e,t){coh=coh-jQuery(t).outerHeight(true);if(coh<tpopt.minFullScreenHeight)coh=tpopt.minFullScreenHeight})}catch(e){}}tpopt.container.parent().height(coh);tpopt.container.height(coh);tpopt.container.closest(".rev_slider_wrapper").height(coh);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(coh);tpopt.container.css({height:"100%"});tpopt.height=coh;}else{tpopt.container.height(tpopt.height);tpopt.container.closest(".rev_slider_wrapper").height(tpopt.height);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(tpopt.height);}
						};
						
						/* CALL PLACEHOLDER */
						setREVStartSize();
								
				
				var tpj=jQuery;				
				tpj.noConflict();				
				var revapi5;
				
				
				
				tpj(document).ready(function() {
				
					
								
				if(tpj('#rev_slider_5_1').revolution == undefined){
					revslider_showDoubleJqueryError('#rev_slider_5_1');
				}else{
				   revapi5 = tpj('#rev_slider_5_1').show().revolution(
					{
											
						dottedOverlay:"none",
						delay:999000,
						startwidth:1250,
						startheight:230,
						hideThumbs:200,
						
						thumbWidth:100,
						thumbHeight:50,
						thumbAmount:1,
													
						simplifyAll:"off",						
						navigationType:"none",
						navigationArrows:"none",
						navigationStyle:"round",						
						touchenabled:"on",
						onHoverStop:"on",						
						nextSlideOnWindowFocus:"off",
						
						swipe_threshold: 75,
						swipe_min_touches: 1,
						drag_block_vertical: false,
																		
																		
						keyboardNavigation:"off",
						
						navigationHAlign:"center",
						navigationVAlign:"bottom",
						navigationHOffset:0,
						navigationVOffset:20,

						soloArrowLeftHalign:"left",
						soloArrowLeftValign:"center",
						soloArrowLeftHOffset:20,
						soloArrowLeftVOffset:0,

						soloArrowRightHalign:"right",
						soloArrowRightValign:"center",
						soloArrowRightHOffset:20,
						soloArrowRightVOffset:0,
								
						shadow:0,
						fullWidth:"on",
						fullScreen:"off",

												spinner:"spinner0",
																		
						stopLoop:"off",
						stopAfterLoops:-1,
						stopAtSlide:-1,

						shuffle:"off",
						
						autoHeight:"off",						
						forceFullWidth:"off",						
												
												
												
						hideThumbsOnMobile:"off",
						hideNavDelayOnMobile:1500,
						hideBulletsOnMobile:"off",
						hideArrowsOnMobile:"off",
						hideThumbsUnderResolution:0,
						
												hideSliderAtLimit:0,
						hideCaptionAtLimit:0,
						hideAllCaptionAtLilmit:0,
						startWithSlide:0,
						isJoomla: true
					});
					
					
					
									}					
				});	/*ready*/
									
			</script>
			</div>
<!-- END REVOLUTION SLIDER -->	

<div class="custom"  >
	<h4 style="padding-left: 60px; padding-right: 30px; font-family: 'Roboto'; font-weight: lighter; color: #fff;text-align: justify;">Nuestros lubricantes para transmisión son altamente eficaces en la protección interna de los sistemas de tu vehículo.</h4></div>

        </div>
        <!-- //HEADcustom -->
      </div>
    <div class="banner_row pad-boxed">
    
    </div>
	<div class="breadcrumbs pad-boxed"><div class="container">

</div></div>
    
<div id="t3-mainbody" >
<section class="container t3-mainbody">
  <div class="row">
    <div class="main-content">
    <!-- MAIN CONTENT -->
    <div id="t3-content" class="t3-content span12"  data-default="span12"><div id="t3-content-inner">
            
<div id="system-message-container">
<div id="system-message">
</div>
</div>
           
     
     
     
     
      
<div id="prodlist-box">
	<!--<h3 class="module-title"><span><span>LUBRICANTES PARA TRANSMISIÓN AUTOMÁTICA Y MECÁNICA&nbsp;Categorías</span></span></h3> -->



 		
			
		    <form action="/index.php/gasolineros/acei-transmision-aut-y-mec" method="get">

		    <!--BEGIN Search Box --><div class="virtuemart_search" style="padding-bottom:10px;">
		    <input name="keyword" class="inputbox" type="text" size="20" value="" />
		    <input type="submit" value="Buscar en la tienda" class="button" onclick="this.form.keyword.focus();"/>
		    </div>
				    <input type="hidden" name="search" value="true" />
				    <input type="hidden" name="view" value="category" />

		</form>
		<!-- End Search Box -->
		


			<div class="orderby-displaynumber z-index">
            <div class="box-style">
				<div class="width100 border_bot">
               		<div id="navigation" class="navigation_grid">
                    	<span>Modo de Vista:</span>
                        <a class="active hasTooltip Cgrid" href="#"  title="Grid">Grid<i class="icon-th"></i></a>
                        <a class="hasTooltip Clist" href="#"  title="List">List<i class="icon-list-ul"></i></a>

                    </div>
					<div class="orderlistcontainer"><div class="title">Ordenar por</div><div class="activeOrder"><a title=" +/-" href="/index.php/gasolineros/acei-transmision-aut-y-mec?dir=DESC">Precio del producto  +/-</a></div><div class="orderlist"><div><a title="Producto" href="/index.php/gasolineros/acei-transmision-aut-y-mec?orderby=product_name">Producto</a></div><div><a title="Ref. del producto" href="/index.php/gasolineros/acei-transmision-aut-y-mec?orderby=product_sku">Ref. del producto</a></div><div><a title="Categoría" href="/index.php/gasolineros/acei-transmision-aut-y-mec?orderby=category_name">Categoría</a></div><div><a title="Descripción de categoría " href="/index.php/gasolineros/acei-transmision-aut-y-mec?orderby=category_description">Descripción de categoría </a></div><div><a title="Nombre del fabricante" href="/index.php/gasolineros/acei-transmision-aut-y-mec?orderby=mf_name">Nombre del fabricante</a></div><div><a title="Id de producto" href="/index.php/gasolineros/acei-transmision-aut-y-mec?orderby=virtuemart_product_id">Id de producto</a></div></div></div>					
                </div>
                <div class="Results">
                    <div class="floatleft display-number"><span>
Resultados 1 - 6 de 6</span><span>Mostrar:&nbsp;&nbsp;<select name="" class="inputbox" size="1" onchange="window.top.location.href=this.options[this.selectedIndex].value">
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=6">6</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=9">9</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=12">12</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=16" selected="selected">16</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=100">100</option>
</select>
&nbsp;&nbsp;Productos por Página</span>
                    </div>
                    <div id="bottom-pagination-top" class="pagination"></div>
                    <div class="clear"></div>
                </div>
               </div>
			</div>
             <div class="clear"></div>
			 <!-- end of orderby-displaynumber -->

	<div id="product_list" class="grid layout">
										<ul id="slider" class="vmproduct">


					
					 <li>
                     <input type="hidden" class="quick_ids" name="virtuemart_product_id" value="73"/>
                       <div class="prod-row">
							 
						<div class="product-box front_w spacer  ">
                            <div class="browseImage ">
                                                                                              <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/atf-70-detail" ><img src="/images/stories/virtuemart/product/resized/atf_280x280.png" alt="atf" class="browseProductImage featuredProductImage" id="Img_to_Js_73" border="0" /></a>                            </div>
                                    <div class="Title">
                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/atf-70-detail" title="ATF (FLUIDO DE TRANSMISIÓN AUTOMÁTICA)">ATF (FLUIDO DE TRANSMISIÓN AUTOMÁTICA)</a>                                    </div>
                            												<div class="product-price marginbottom12" id="productPrice73">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$1.32</span></div>										</div>
                                        
                       </div>


                       <div class="product-box hover hover back_w  spacer  ">
                       <div class="left-img">
                            <div class="browseImage ">
                                                                                            <div class="img-wrapper">
                                   <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/atf-70-detail" ><img src="/images/stories/virtuemart/product/resized/atf_280x280.png" alt="atf" id="Img_to_Js_73" class="browseProductImage featuredProductImageFirst" border="0" /></a>                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/atf-70-detail" ><img src="/images/stories/virtuemart/product/resized/atf_280x280.png" alt="atf" class="browseProductImage  featuredProductImage" border="0" /></a>                                    </div>



                            </div>
                            </div>
                            <div class="slide-hover">
                                <div class="wrapper">
                                            <div class="Title">
                                            <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/atf-70-detail" title="ATF (FLUIDO DE TRANSMISIÓN AUTOMÁTICA)">ATF (FLUIDO DE TRANSMISIÓN AUTOMÁTICA)</a>                                            </div>
                                            <div class="clear"></div>
                                         
                                                                  <div class="Price">

										<div class="product-price marginbottom12" id="productPrice73">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$1.32</span></div>										</div>

                                </div>
                                <div class="clear"></div>
                                                                </div>
                                    <div class="wrapper-slide">
                                    									<div class="addtocart-area2">
																				<form method="post" class="product" action="index.php" id="addtocartproduct73">
                                          <input name="quantity" type="hidden" value="1" />
										<div class="addtocart-bar2">
                                        <script type="text/javascript">
													function check(obj) {
													// use the modulus operator '%' to see if there is a remainder
													remainder=obj.value % 1;
													quantity=obj.value;
													if (remainder  != 0) {
														alert('¡Puede comprar este producto solo en múltiplos de 1 piezas!!');
														obj.value = quantity-remainder;
														return false;
														}
													return true;
													}
											</script>
											
											<span class="attributes"><b>*</b> Product has attributes</span>
                                            <div class="addtocart_button2">
											<a href="/index.php/gasolineros/acei-transmision-aut-y-mec/atf-70-detail" title="Select Option" class="addtocart-button hasTooltips">Select Option<span>&nbsp;</span></a>                                      	  </div>

																			</div>
									</form>
									                                    </div>
							
                                                                 		 <div class="wishlist list_wishlists73">
										    
<a class="add_wishlist hasTooltip "  title="Add To Wishlist"  onclick="addToWishlists('73');"><i class="fa fa-heart-o"></i><span>Add To Wishlist</span></a>
 


                                     </div>
                           		                                                                    		 <div class="jClever compare_cat list_compare73">
										<a class="compare-label add_compare hasTooltip " title="Add To Compare"  onclick="addToCompare('73');"><i class="fa fa-files-o"></i><span>Add To Compare</span></a>
                                     </div>
                           		                                       </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            </div>
                           <div class="clear"></div>
					</li>

					
					 <li>
                     <input type="hidden" class="quick_ids" name="virtuemart_product_id" value="74"/>
                       <div class="prod-row">
							 
						<div class="product-box front_w spacer  ">
                            <div class="browseImage ">
                                                                                              <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-iii-70-detail" ><img src="/images/stories/virtuemart/product/resized/brikson_iii_280x280.png" alt="brikson_iii" class="browseProductImage featuredProductImage" id="Img_to_Js_74" border="0" /></a>                            </div>
                                    <div class="Title">
                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-iii-70-detail" title="BRIKSON III">BRIKSON III</a>                                    </div>
                            												<div class="product-price marginbottom12" id="productPrice74">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$2.65</span></div>										</div>
                                        
                       </div>


                       <div class="product-box hover hover back_w  spacer  ">
                       <div class="left-img">
                            <div class="browseImage ">
                                                                                            <div class="img-wrapper">
                                   <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-iii-70-detail" ><img src="/images/stories/virtuemart/product/resized/brikson_iii_280x280.png" alt="brikson_iii" id="Img_to_Js_74" class="browseProductImage featuredProductImageFirst" border="0" /></a>                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-iii-70-detail" ><img src="/images/stories/virtuemart/product/resized/brikson_iii_280x280.png" alt="brikson_iii" class="browseProductImage  featuredProductImage" border="0" /></a>                                    </div>



                            </div>
                            </div>
                            <div class="slide-hover">
                                <div class="wrapper">
                                            <div class="Title">
                                            <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-iii-70-detail" title="BRIKSON III">BRIKSON III</a>                                            </div>
                                            <div class="clear"></div>
                                         
                                                                  <div class="Price">

										<div class="product-price marginbottom12" id="productPrice74">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$2.65</span></div>										</div>

                                </div>
                                <div class="clear"></div>
                                                                </div>
                                    <div class="wrapper-slide">
                                    									<div class="addtocart-area2">
																				<form method="post" class="product" action="index.php" id="addtocartproduct74">
                                          <input name="quantity" type="hidden" value="1" />
										<div class="addtocart-bar2">
                                        <script type="text/javascript">
													function check(obj) {
													// use the modulus operator '%' to see if there is a remainder
													remainder=obj.value % 1;
													quantity=obj.value;
													if (remainder  != 0) {
														alert('¡Puede comprar este producto solo en múltiplos de 1 piezas!!');
														obj.value = quantity-remainder;
														return false;
														}
													return true;
													}
											</script>
											
											<span class="attributes"><b>*</b> Product has attributes</span>
                                            <div class="addtocart_button2">
											<a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-iii-70-detail" title="Select Option" class="addtocart-button hasTooltips">Select Option<span>&nbsp;</span></a>                                      	  </div>

																			</div>
									</form>
									                                    </div>
							
                                                                 		 <div class="wishlist list_wishlists74">
										    
<a class="add_wishlist hasTooltip "  title="Add To Wishlist"  onclick="addToWishlists('74');"><i class="fa fa-heart-o"></i><span>Add To Wishlist</span></a>
 


                                     </div>
                           		                                                                    		 <div class="jClever compare_cat list_compare74">
										<a class="compare-label add_compare hasTooltip " title="Add To Compare"  onclick="addToCompare('74');"><i class="fa fa-files-o"></i><span>Add To Compare</span></a>
                                     </div>
                           		                                       </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            </div>
                           <div class="clear"></div>
					</li>

					
					 <li>
                     <input type="hidden" class="quick_ids" name="virtuemart_product_id" value="75"/>
                       <div class="prod-row">
							 
						<div class="product-box front_w spacer  ">
                            <div class="browseImage ">
                                                                                              <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/gearoil-sae-90,-140,-250,-75w-90,-80w-90-y-85w-140-api-gl-5-detail" ><img src="/images/stories/virtuemart/product/resized/gearoil_gl5_80w90_5gal_280x280.png" alt="gearoil_gl5_80w90_5gal" class="browseProductImage featuredProductImage" id="Img_to_Js_75" border="0" /></a>                            </div>
                                    <div class="Title">
                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/gearoil-sae-90,-140,-250,-75w-90,-80w-90-y-85w-140-api-gl-5-detail" title="GEAROIL 90, 140, 250, 75W-90, 80W-90 Y 85W-140  GL-5">GEAROIL 90, 140, 250, 75W-90, 80W-90 Y 85W-140  GL-5</a>                                    </div>
                            												<div class="product-price marginbottom12" id="productPrice75">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$3.97</span></div>										</div>
                                        
                       </div>


                       <div class="product-box hover hover back_w  spacer  ">
                       <div class="left-img">
                            <div class="browseImage ">
                                                                                            <div class="img-wrapper">
                                   <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/gearoil-sae-90,-140,-250,-75w-90,-80w-90-y-85w-140-api-gl-5-detail" ><img src="/images/stories/virtuemart/product/resized/gearoil_gl5_80w90_5gal_280x280.png" alt="gearoil_gl5_80w90_5gal" id="Img_to_Js_75" class="browseProductImage featuredProductImageFirst" border="0" /></a>                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/gearoil-sae-90,-140,-250,-75w-90,-80w-90-y-85w-140-api-gl-5-detail" ><img src="/images/stories/virtuemart/product/resized/gearoil_gl5_85w140_5gal_280x280.png" alt="gearoil_gl5_85w140_5gal" id="Img_to_Js_75" class="browseProductImage featuredProductImagesecond" border="0" /></a>                                    </div>



                            </div>
                            </div>
                            <div class="slide-hover">
                                <div class="wrapper">
                                            <div class="Title">
                                            <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/gearoil-sae-90,-140,-250,-75w-90,-80w-90-y-85w-140-api-gl-5-detail" title="GEAROIL 90, 140, 250, 75W-90, 80W-90 Y 85W-140  GL-5">GEAROIL 90, 140, 250, 75W-90, 80W-90 Y 85W-140  GL-5</a>                                            </div>
                                            <div class="clear"></div>
                                         
                                                                  <div class="Price">

										<div class="product-price marginbottom12" id="productPrice75">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$3.97</span></div>										</div>

                                </div>
                                <div class="clear"></div>
                                                                </div>
                                    <div class="wrapper-slide">
                                    									<div class="addtocart-area2">
																				<form method="post" class="product" action="index.php" id="addtocartproduct75">
                                          <input name="quantity" type="hidden" value="1" />
										<div class="addtocart-bar2">
                                        <script type="text/javascript">
													function check(obj) {
													// use the modulus operator '%' to see if there is a remainder
													remainder=obj.value % 1;
													quantity=obj.value;
													if (remainder  != 0) {
														alert('¡Puede comprar este producto solo en múltiplos de 1 piezas!!');
														obj.value = quantity-remainder;
														return false;
														}
													return true;
													}
											</script>
											
											<span class="attributes"><b>*</b> Product has attributes</span>
                                            <div class="addtocart_button2">
											<a href="/index.php/gasolineros/acei-transmision-aut-y-mec/gearoil-sae-90,-140,-250,-75w-90,-80w-90-y-85w-140-api-gl-5-detail" title="Select Option" class="addtocart-button hasTooltips">Select Option<span>&nbsp;</span></a>                                      	  </div>

																			</div>
									</form>
									                                    </div>
							
                                                                 		 <div class="wishlist list_wishlists75">
										    
<a class="add_wishlist hasTooltip "  title="Add To Wishlist"  onclick="addToWishlists('75');"><i class="fa fa-heart-o"></i><span>Add To Wishlist</span></a>
 


                                     </div>
                           		                                                                    		 <div class="jClever compare_cat list_compare75">
										<a class="compare-label add_compare hasTooltip " title="Add To Compare"  onclick="addToCompare('75');"><i class="fa fa-files-o"></i><span>Add To Compare</span></a>
                                     </div>
                           		                                       </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            </div>
                           <div class="clear"></div>
					</li>

					
					 <li>
                     <input type="hidden" class="quick_ids" name="virtuemart_product_id" value="77"/>
                       <div class="prod-row">
							 
						<div class="product-box front_w spacer  ">
                            <div class="browseImage ">
                                                                                              <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-90,-140-y-250-gl-1-detail" ><img src="/images/stories/virtuemart/product/resized/143939182664_280x280.png" alt="143939182664" class="browseProductImage featuredProductImage" id="Img_to_Js_77" border="0" /></a>                            </div>
                                    <div class="Title">
                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-90,-140-y-250-gl-1-detail" title="TRANSMEC 90, 140 Y 250 GL-1">TRANSMEC 90, 140 Y 250 GL-1</a>                                    </div>
                            												<div class="product-price marginbottom12" id="productPrice77">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$5.30</span></div>										</div>
                                        
                       </div>


                       <div class="product-box hover hover back_w  spacer  ">
                       <div class="left-img">
                            <div class="browseImage ">
                                                                                            <div class="img-wrapper">
                                   <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-90,-140-y-250-gl-1-detail" ><img src="/images/stories/virtuemart/product/resized/143939182664_280x280.png" alt="143939182664" id="Img_to_Js_77" class="browseProductImage featuredProductImageFirst" border="0" /></a>                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-90,-140-y-250-gl-1-detail" ><img src="/images/stories/virtuemart/product/resized/1439391835294_280x280.png" alt="1439391835294" id="Img_to_Js_77" class="browseProductImage featuredProductImagesecond" border="0" /></a>                                    </div>



                            </div>
                            </div>
                            <div class="slide-hover">
                                <div class="wrapper">
                                            <div class="Title">
                                            <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-90,-140-y-250-gl-1-detail" title="TRANSMEC 90, 140 Y 250 GL-1">TRANSMEC 90, 140 Y 250 GL-1</a>                                            </div>
                                            <div class="clear"></div>
                                         
                                                                  <div class="Price">

										<div class="product-price marginbottom12" id="productPrice77">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$5.30</span></div>										</div>

                                </div>
                                <div class="clear"></div>
                                                                </div>
                                    <div class="wrapper-slide">
                                    									<div class="addtocart-area2">
																				<form method="post" class="product" action="index.php" id="addtocartproduct77">
                                          <input name="quantity" type="hidden" value="1" />
										<div class="addtocart-bar2">
                                        <script type="text/javascript">
													function check(obj) {
													// use the modulus operator '%' to see if there is a remainder
													remainder=obj.value % 1;
													quantity=obj.value;
													if (remainder  != 0) {
														alert('¡Puede comprar este producto solo en múltiplos de 1 piezas!!');
														obj.value = quantity-remainder;
														return false;
														}
													return true;
													}
											</script>
											
											<span class="attributes"><b>*</b> Product has attributes</span>
                                            <div class="addtocart_button2">
											<a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-90,-140-y-250-gl-1-detail" title="Select Option" class="addtocart-button hasTooltips">Select Option<span>&nbsp;</span></a>                                      	  </div>

																			</div>
									</form>
									                                    </div>
							
                                                                 		 <div class="wishlist list_wishlists77">
										    
<a class="add_wishlist hasTooltip "  title="Add To Wishlist"  onclick="addToWishlists('77');"><i class="fa fa-heart-o"></i><span>Add To Wishlist</span></a>
 


                                     </div>
                           		                                                                    		 <div class="jClever compare_cat list_compare77">
										<a class="compare-label add_compare hasTooltip " title="Add To Compare"  onclick="addToCompare('77');"><i class="fa fa-files-o"></i><span>Add To Compare</span></a>
                                     </div>
                           		                                       </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            </div>
                           <div class="clear"></div>
					</li>

					
					 <li>
                     <input type="hidden" class="quick_ids" name="virtuemart_product_id" value="186"/>
                       <div class="prod-row">
							 
						<div class="product-box front_w spacer  ">
                            <div class="browseImage ">
                                                                                              <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-ii-detail" ><img src="/images/stories/virtuemart/product/resized/brikson_ii_280x280.png" alt="brikson_ii" class="browseProductImage featuredProductImage" id="Img_to_Js_186" border="0" /></a>                            </div>
                                    <div class="Title">
                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-ii-detail" title="BRIKSON II">BRIKSON II</a>                                    </div>
                            												<div class="product-price marginbottom12" id="productPrice186">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$1.99</span></div>										</div>
                                        
                       </div>


                       <div class="product-box hover hover back_w  spacer  ">
                       <div class="left-img">
                            <div class="browseImage ">
                                                                                            <div class="img-wrapper">
                                   <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-ii-detail" ><img src="/images/stories/virtuemart/product/resized/brikson_ii_280x280.png" alt="brikson_ii" id="Img_to_Js_186" class="browseProductImage featuredProductImageFirst" border="0" /></a>                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-ii-detail" ><img src="/images/stories/virtuemart/product/resized/brikson_ii_280x280.png" alt="brikson_ii" class="browseProductImage  featuredProductImage" border="0" /></a>                                    </div>



                            </div>
                            </div>
                            <div class="slide-hover">
                                <div class="wrapper">
                                            <div class="Title">
                                            <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-ii-detail" title="BRIKSON II">BRIKSON II</a>                                            </div>
                                            <div class="clear"></div>
                                         
                                                                  <div class="Price">

										<div class="product-price marginbottom12" id="productPrice186">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$1.99</span></div>										</div>

                                </div>
                                <div class="clear"></div>
                                                                </div>
                                    <div class="wrapper-slide">
                                    									<div class="addtocart-area2">
																				<form method="post" class="product" action="index.php" id="addtocartproduct186">
                                          <input name="quantity" type="hidden" value="1" />
										<div class="addtocart-bar2">
                                        <script type="text/javascript">
													function check(obj) {
													// use the modulus operator '%' to see if there is a remainder
													remainder=obj.value % 1;
													quantity=obj.value;
													if (remainder  != 0) {
														alert('¡Puede comprar este producto solo en múltiplos de 1 piezas!!');
														obj.value = quantity-remainder;
														return false;
														}
													return true;
													}
											</script>
											
											<span class="attributes"><b>*</b> Product has attributes</span>
                                            <div class="addtocart_button2">
											<a href="/index.php/gasolineros/acei-transmision-aut-y-mec/brikson-ii-detail" title="Select Option" class="addtocart-button hasTooltips">Select Option<span>&nbsp;</span></a>                                      	  </div>

																			</div>
									</form>
									                                    </div>
							
                                                                 		 <div class="wishlist list_wishlists186">
										    
<a class="add_wishlist hasTooltip "  title="Add To Wishlist"  onclick="addToWishlists('186');"><i class="fa fa-heart-o"></i><span>Add To Wishlist</span></a>
 


                                     </div>
                           		                                                                    		 <div class="jClever compare_cat list_compare186">
										<a class="compare-label add_compare hasTooltip " title="Add To Compare"  onclick="addToCompare('186');"><i class="fa fa-files-o"></i><span>Add To Compare</span></a>
                                     </div>
                           		                                       </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            </div>
                           <div class="clear"></div>
					</li>

					
					 <li>
                     <input type="hidden" class="quick_ids" name="virtuemart_product_id" value="187"/>
                       <div class="prod-row">
							 
						<div class="product-box front_w spacer  ">
                            <div class="browseImage ">
                                                                                              <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-dual-90,-140-y-250-gl-4-detail" ><img src="/images/stories/virtuemart/product/resized/1443363527405_280x280.png" alt="1443363527405" class="browseProductImage featuredProductImage" id="Img_to_Js_187" border="0" /></a>                            </div>
                                    <div class="Title">
                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-dual-90,-140-y-250-gl-4-detail" title="TRANSMEC DUAL  90, 140 Y 250 GL-4">TRANSMEC DUAL  90, 140 Y 250 GL-4</a>                                    </div>
                            												<div class="product-price marginbottom12" id="productPrice187">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$4.64</span></div>										</div>
                                        
                       </div>


                       <div class="product-box hover hover back_w  spacer  ">
                       <div class="left-img">
                            <div class="browseImage ">
                                                                                            <div class="img-wrapper">
                                   <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-dual-90,-140-y-250-gl-4-detail" ><img src="/images/stories/virtuemart/product/resized/1443363527405_280x280.png" alt="1443363527405" id="Img_to_Js_187" class="browseProductImage featuredProductImageFirst" border="0" /></a>                                    <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-dual-90,-140-y-250-gl-4-detail" ><img src="/images/stories/virtuemart/product/resized/1443363527153_280x280.png" alt="1443363527153" id="Img_to_Js_187" class="browseProductImage featuredProductImagesecond" border="0" /></a>                                    </div>



                            </div>
                            </div>
                            <div class="slide-hover">
                                <div class="wrapper">
                                            <div class="Title">
                                            <a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-dual-90,-140-y-250-gl-4-detail" title="TRANSMEC DUAL  90, 140 Y 250 GL-4">TRANSMEC DUAL  90, 140 Y 250 GL-4</a>                                            </div>
                                            <div class="clear"></div>
                                         
                                                                  <div class="Price">

										<div class="product-price marginbottom12" id="productPrice187">
											<div class="PricesalesPrice vm-display vm-price-value"><span class="vm-price-desc"></span><span class="PricesalesPrice">$4.64</span></div>										</div>

                                </div>
                                <div class="clear"></div>
                                                                </div>
                                    <div class="wrapper-slide">
                                    									<div class="addtocart-area2">
																				<form method="post" class="product" action="index.php" id="addtocartproduct187">
                                          <input name="quantity" type="hidden" value="1" />
										<div class="addtocart-bar2">
                                        <script type="text/javascript">
													function check(obj) {
													// use the modulus operator '%' to see if there is a remainder
													remainder=obj.value % 1;
													quantity=obj.value;
													if (remainder  != 0) {
														alert('¡Puede comprar este producto solo en múltiplos de 1 piezas!!');
														obj.value = quantity-remainder;
														return false;
														}
													return true;
													}
											</script>
											
											<span class="attributes"><b>*</b> Product has attributes</span>
                                            <div class="addtocart_button2">
											<a href="/index.php/gasolineros/acei-transmision-aut-y-mec/transmec-dual-90,-140-y-250-gl-4-detail" title="Select Option" class="addtocart-button hasTooltips">Select Option<span>&nbsp;</span></a>                                      	  </div>

																			</div>
									</form>
									                                    </div>
							
                                                                 		 <div class="wishlist list_wishlists187">
										    
<a class="add_wishlist hasTooltip "  title="Add To Wishlist"  onclick="addToWishlists('187');"><i class="fa fa-heart-o"></i><span>Add To Wishlist</span></a>
 


                                     </div>
                           		                                                                    		 <div class="jClever compare_cat list_compare187">
										<a class="compare-label add_compare hasTooltip " title="Add To Compare"  onclick="addToCompare('187');"><i class="fa fa-files-o"></i><span>Add To Compare</span></a>
                                     </div>
                           		                                       </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            </div>
                           <div class="clear"></div>
					</li>

					
					</ul>
</div>
<div class="clear"></div>

<div class="orderby-displaynumber">
            <div class="box-style">
				                <div class="Results">
                    <div class="floatleft display-number"><span>
Resultados 1 - 6 de 6</span><span>Mostrar:&nbsp;&nbsp;<select name="" class="inputbox" size="1" onchange="window.top.location.href=this.options[this.selectedIndex].value">
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=6">6</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=9">9</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=12">12</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=16" selected="selected">16</option>
	<option value="/index.php/gasolineros/acei-transmision-aut-y-mec?limit=100">100</option>
</select>
&nbsp;&nbsp;Productos por Página</span>
                    </div>
                    <div id="bottom-pagination-top" class="pagination"></div>
                    <div class="clear"></div>
                </div>
               </div>
			</div>
	<div class="clear"></div>

</div>
	<script type="text/javascript" src="/templates/t3_blank/html/com_virtuemart/category/jquery.formstyler.min.js"></script>
<script type="text/javascript" src="/templates/t3_blank/html/com_virtuemart/category/Cookie.js"></script>
<script type="text/javascript">
function tooltip(){
	jQuery('.navigation_grid .hasTooltip , #product_list.grid .hasTooltips ,#product_list.grid .add_wishlist,#product_list.grid .add_compare').tooltip();
}
 jQuery(document).ready(function($) {
	tooltip();
	 $('.Results select').styler();
	var cc = $.cookie('list_grid');
	if (cc == 'g') {
		$('#product_list').addClass('list');
		$('#product_list').removeClass('grid');
		$('.Cgrid').removeClass('active');
		$('.Clist').addClass('active');
	} else {
		$('#product_list').addClass('grid');
		$('#product_list').removeClass('list');
		$('.Clist').removeClass('active');
		$('.Cgrid').addClass('active');
	}
	$('.Cgrid').click(function() {
		$('.Cgrid').addClass('active');
		$('.Clist').removeClass('active');
		$('#product_list').fadeOut(300, function() {
			$(this).addClass('grid').removeClass('list').fadeIn(300);
		});
		$.cookie('list_grid', '1' , { expires: 7, path: vmSiteurl });
		return false;
	});
	$('.Clist').click(function() {
		$('.Clist').addClass('active');
		$('.Cgrid').removeClass('active');
		$('#product_list').fadeOut(300, function() {
			$(this).removeClass('grid').addClass('list').fadeIn(300);
		});
		$.cookie('list_grid','g', { expires: 7, path: vmSiteurl });
		return false;
	});
 $(function() {
    	$('#product_list div.prod-row').each(function() {
        var tip = $(this).find('div.count_holder_small');

        $(this).hover(
            function() { tip.appendTo('body'); },
            function() { tip.appendTo(this); }
        ).mousemove(function(e) {
            var x = e.pageX + 60,
                y = e.pageY - 50,
                w = tip.width(),
                h = tip.height(),
                dx = $(window).width() - (x + w),
                dy = $(window).height() - (y + h);

            if ( dx < 50 ) x = e.pageX - w - 60;
            if ( dy < 50 ) y = e.pageY - h + 130;

            tip.css({ left: x, top: y });
        	});
    	});
		});
});
</script>


<script id="vm.countryState_js" type="text/javascript"> //<![CDATA[
		jQuery( function($) {
			$("#virtuemart_country_id").vm2front("list",{dest : "#virtuemart_state_id",ids : "",prefiks : ""});
		});
//]]> </script><script id="datepicker_js" type="text/javascript"> //<![CDATA[
			jQuery(document).ready( function($) {
			$(document).on( "focus",".datepicker", function() {
				$( this ).datepicker({
					changeMonth: true,
					changeYear: true,
					yearRange: "1915:2015",
					dateFormat:"y.mm.dd",
					altField: $(this).prev(),
					altFormat: "yy-mm-dd"
				});
			});
			jQuery(document).on( "click",".js-date-reset", function() {
				$(this).prev("input").val("-Nunca-").prev("input").val("0");
			});
		});
//]]> </script><script id="vm.countryStateshipto__js" type="text/javascript"> //<![CDATA[
		jQuery( function($) {
			$("#shipto_virtuemart_country_id").vm2front("list",{dest : "#shipto_virtuemart_state_id",ids : "",prefiks : "shipto_"});
		});
//]]> </script><script id="jsVars_js" type="text/javascript">//<![CDATA[ 
vmSiteurl = 'http://www.vistony.com/' ;
vmLang = '&lang=es' ; //]]>
</script><script id="ready.vmprices_js" type="text/javascript">//<![CDATA[ 
jQuery(document).ready(function($) {
	Virtuemart.product(jQuery("form.product"));

	/*$("form.js-recalculate").each(function(){
		if ($(this).find(".product-fields").length && !$(this).find(".no-vm-bind").length) {
			var id= $(this).find('input[name="virtuemart_product_id[]"]').val();
			Virtuemart.setproducttype($(this),id);

		}
	});*/
}); //]]>
</script>
    </div></div>
    <!-- //MAIN CONTENT -->

        
    
  </div>
  </div>
</section> 
</div>
    

    
<!-- NAV HELPER -->
<nav class="pad-boxed wrap t3-navhelper">
  <div class="container">
    
  </div>
</nav>
<!-- //NAV HELPER -->
    <footer id="t3-footer" class="wrap t3-footer">
 <p id="back-top">
    	<a href="#top" title="Go to Top"><span></span></a>
 </p>

<ul id="jj_sl_navigation"><li class="jj_sl_custom1"><a href="/index.php/selector-de-aceites" target="_blank"><span class="jj_social_text">.</span></a></li><li class="jj_sl_custom2"><a href="/index.php/otros-lubricantes/" target="_blank"><span class="jj_social_text">.</span></a></li></ul>
  <aside class="t3-aside pad-boxed">
        <div class="container">
        	<!-- SPOTLIGHT -->
	<div class="t3-spotlight t3-footnav  row">
					<div class="span2 item-first" data-default="span2" data-xtablet="span3" data-tablet="span4">
									<div class="t3-module module_footmenu" id="Mod115">
    <div class="module-inner">
                  <h3 class="module-title"><span>La Empresa</span></h3>
      <b class="click"></b>
            <div class="module-ct">
      
<ul class="nav ">
<li class="item-1130">	<a href="/index.php/la-empresa" >Quienes Somos</a></li><li class="item-1131"><a href="/index.php/historia" >Historia</a></li><li class="item-1132"><a href="/index.php/mision-y-vision" >Misión y Visión</a></li><li class="item-1134"><a href="/index.php/politica-de-calidad" >Política de calidad</a></li><li class="item-1253">	<a href="/index.php/contacto" >Contacto</a></li></ul>
      </div>
    </div>
  </div>
  	
							</div>
					<div class="span2 " data-default="span2" data-wide="span3" data-xtablet="span3" data-tablet="span4">
									<div class="t3-module module_footmenu2" id="Mod116">
    <div class="module-inner">
                  <h3 class="module-title"><span>Productos</span></h3>
      <b class="click"></b>
            <div class="module-ct">
      
<ul class="nav ">
<li class="item-1142">	<a href="/index.php/gasolineros/lubricantes-para-motor-gasolinero-y-o-gas/gasolineros/acei-transmision-aut-y-mec" >Lubricantes Gasolineros</a></li><li class="item-1143">	<a href="http://www.vistony.com/index.php/lubricantes-diesel/lubricantes-para-motor-diesel-y-o-gas" >Lubricantes Diésel</a></li><li class="item-1144">	<a href="/index.php/lubricantes-motos-acuaticos/lubricantes-para-motos-4t/gasolineros/acei-transmision-aut-y-mec" >Lubricantes Motos / Acuáticos</a></li><li class="item-1145">	<a href="/index.php/grasas-lubricantes/grasa-automotriz-industrial/gasolineros/acei-transmision-aut-y-mec" >Grasas Lubricantes</a></li><li class="item-1146">	<a href="http://www.vistony.com/productos-industriales/" >Productos Industriales</a></li><li class="item-1147">	<a href="/index.php/complementarios/aditivos/gasolineros/acei-transmision-aut-y-mec" >Complementarios</a></li></ul>
      </div>
    </div>
  </div>
  	
							</div>
					<div class="span3 " data-default="span3" data-xtablet="span6" data-tablet="span4">
									<div class="t3-module module_footmenu2" id="Mod241">
    <div class="module-inner">
                  <h3 class="module-title"><span>Herramientas</span></h3>
      <b class="click"></b>
            <div class="module-ct">
      
<ul class="nav ">
<li class="item-1254"><a href="/index.php/selector-de-aceites" >Selector de Aceites</a></li><li class="item-1255">	<a href="/index.php/contacto" >Vistony en el Mundo</a></li><li class="item-1256">	<a href="https://mail.vistony.com/OWA/" target="_blank" >Correo Corporativo</a></li><li class="item-1257">	<a href="/index.php/noticias" >Noticias</a></li></ul>
      </div>
    </div>
  </div>
  	
							</div>
					<div class="span3 " data-default="span3" data-xtablet="span7 spanfirst" data-tablet="span4 spanfirst">
									<div class="t3-module module" id="Mod250">
    <div class="module-inner">
                  <h3 class="module-title"><span>Síguenos en facebook</span></h3>
      <b class="click"></b>
            <div class="module-ct">
      

<div class="custom"  >
	<div class="fb-page" data-href="https://www.facebook.com/vistony/" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/vistony/"><a href="https://www.facebook.com/vistony/">Vistony</a></blockquote></div></div></div>
      </div>
    </div>
  </div>
  	
							</div>
					<div class="span2 item-last" data-default="span2" data-wide=" span2 hidden-wide " data-xtablet="span5" data-tablet="span4">
								&nbsp;
							</div>
			</div>
<!-- SPOTLIGHT -->        </div>
  </aside>

  <section class="t3-copyright pad-boxed">
    <div class="container">
      <div class="row">
        <div class="span12 copyright">
          <small>Copyright &#169; 2015 <a href="/index.php">Vistony</a>. Todos los derechos reservados. Dise&ntilde;ado por <a href="http://www.jobalcorp.com/" TARGET="_blank" title="Web para Empresas">JobalCorp.com</a>.</small>

        </div>
      </div>
    </div>
  </section>
</footer>
     </div>
        </div>
         <script type="text/javascript" src="/templates/t3_blank/js/jquery.mCustomScrollbar.js"></script>
    <script type="text/javascript" src="/templates/t3_blank/js/linescript.js"></script>

  </body>

</html>