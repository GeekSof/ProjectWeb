<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>COMPIHOST - Soluciones de Internet</title>
<link rel="stylesheet" type="text/css" href="css/estilos.css"/>
<link rel="icon" href="img/logocom.gif" type="image/gif">
<!-- WRAPER INICIO -->
<link rel="stylesheet" href="css/sexylightbox.css" type="text/css" media="all" />
<script src="js/jquery.js"></script>
 
<script src="js/functions.js"></script>
<script src="js/web.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/sexylightbox.v2.3.jquery.js"></script>
<script type="text/javascript">
$(document).ready(
    function(){
           SexyLightbox.initialize({color:'00', 
	                                dir: 'sexyimages'
                                  });
              });
</script>
<script type="text/javascript">
	function meebo(valor){
			window.open('meebo.php','Consultas','width=230,height=520,resizable=NO,scrollbars=NO');
			reload();
	}
</script>

<!-- WRAPER FIN -->
</head>

<body>
<!-- Envolve Chat -->

<!--Documentar chat--------<script type="text/javascript">

var envoSn=117836;

var envProtoType = (("https:" == document.location.protocol) ? "http://" : "http://");

document.write(unescape("%3Cscript src='" + envProtoType + "d.envolve.com/env.nocache.js' type='text/javascript'%3E%3C/script%3E"));

</script>---------- cerrar chat---->



<div id="capa"></div>
<div id="express" class="wrapper">
	<div class="cerrar">Cerrar(X)</div>
	<iframe src="http://info361903.supersite.srsportal.com/domain.php" width="99%" height="650px" style="margin-bottom:10px;"></iframe>
</div>


<div id="contenedor_cabecera">

<div id="grande"></div>

  <div id="logo">

  <h1>Brindamos soluciones de internet a su medida, gracias a la experiencia que contamos siendo nuestros servicios creación y optimización de página web, mantenimiento, implementación de  hosting y dominio, sistema atención de clientes, entre otros.</h1>

  </div>

  <div id="slogan">

    <p>Soluciones de Internet</p></div>

  <div id="menu_sup">

  	<div style="width:440px; float:right">

        <div class="link_sup" align="right" style="width:40px"><img src="img/home.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px; width:48px;"><a href="index.html" title="INICIO">Inicio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/empresa.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="nosotros.html" title="EMPRESA">Empresa</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/portafolio_icon.png" width="37" height="47"/></div>
        
        


        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="portafolio.html" title="PORTAFOLIO">Portafolio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/contacto.png" width="37" height="47"/></div>
                
        

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="contactenos.html" title="CONTÁCTENOS">Contáctenos</a></div>

		<div style="clear:both"></div>        

	</div>

  </div>

  <div style="clear:both"></div>

    <div class="raya"></div>

</div>



<div id="banner">

<div id="contenedor_banner" style="position:relative; background-color:#FFF">

  <div id="menu2" align="center" style="width:164px; height:369px; padding-left:0px; position: static;">

  <ul>

  <li style="width:164px; margin-right:0px; background-color:#FFF;"><a class="som_men" style="background-image:url(img/menu_amarillo.png); background-repeat:no-repeat; background-color:#FFF;" id="sup1" href="promociones.html" title="PROMOCIONES">Promociones</a></li>

  <li><a class="som_men" id="sup2" href="hosting.html" title="HOSTING">Hosting</a></li>
  
  <li><a class="som_men" href="http://info361903.supersite.srsportal.com/domain.php?TB_iframe=true&amp;height=700&amp;width=800" rel="sexylightbox" title="DOMINIO">Dominio</a></li>

  <li><a class="som_men" id="sup3" href="soluciones_web.html" title="SOLUCIONES WEB">Soluciones Web</a></li>

  <li><a class="som_men" id="sup7" href="e_marketing.html" title="E - MARKETING">E - Marketing</a></li>

  <li><a class="som_men" id="sup6" href="soporte.html" title="SOPORTE">Soporte Remoto</a></li>

  <!--<li><a class="som_men" id="sup5" href="sistemas.html" title="SISTEMAS">Sistemas</a></li>   -->

    </ul>

</div>
<div style="background:url(img/tablet.jpg) no-repeat; width:821px; height:373px; position:absolute; left:182px; top:0px; ">

  <section style="overflow:visible;"> 

    	<div style="position: absolute; width:300px; margin:123px 0 0 -90px; padding:0 20px;top: -100px;left: 90px;"> 
                <div class="pix_diapo">
					<div data-thumb="diapo/images/thumbs/up-official-trailer-fake.jpg" title="Haz clic y entérate de nuestras promociones">
                        <iframe width="734" height="324" src="http://www.youtube.com/embed/c1Z9tTjHIMA?rel=0&modestbranding=1&autoplay=1" data-fake="diapo/images/slides/up-official-trailer-fake.jpg" frameborder="0" allowfullscreen ></iframe>
                        
                        <div class="elemHover caption fromLeft elemToHide" style="bottom: 350px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; left:0">
                            You can also display videos, but it requires a "fake image"... read the documentation please
                        </div>
                    </div>

                    <div data-thumb="diapo/images/thumbs/megamind1048.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b1.jpg"></a>
                       <!-- <div class="caption elemHover fromLeft">
                            This is a simple sliding image with caption. You can have more than one caption and decide the layout of the caption via css.
                        </div>-->
                    </div>
                    
<!--                    <div data-thumb="diapo/images/thumbs/megamind_07.jpg">
                        <a href="https://www.facebook.com/COMPIHOST/app_79458893817" target="_blank" title="Haz clic y participa gratis en nuestros Sorteos"><img src="diapo/images/slides/b2.jpg"></a>-->
<!--                        <div class="caption elemHover fromRight" style="bottom:65px; padding-bottom:5px; color:#ff0; text-transform:uppercase">
                            Here you can see two captions.
                        </div>
                        <div class="caption elemHover fromLeft" style="padding-top:5px;">
                            The first are loaded immediately before than the second one
                        </div>-->
<!--                    </div>-->
                    
<!--                    <div data-thumb="diapo/images/thumbs/wall-e.jpg" data-time="7000">
                        <img src="diapo/images/slides/wall-e.jpg">
                        <div class="elemHover caption fromLeft" style="bottom:70px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px;">
                            You can also get the same effect as the caption with:
                        </div>
                        <div class="elemHover button fromTop" data-easing="easeOutExpo" style="left:388px; bottom:78px;">
                            A button
                        </div>
                        <div class="elemHover button button2 fromBottom" data-easing="easeOutExpo" style="left:512px; bottom:78px;">
                            Or two buttons
                        </div>
                        <div class="elemHover fadeIn" style="left:600px; bottom:auto; top:0; padding-top:50px; color:#ff0; font-size:13px; line-height:20px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; background:url(diapo/images/demo/arrow_caption.png) no-repeat 230px 30px">
                            Or any other html element...<br>
                            and you can decide the transition time of any slide
                        </div>
                    </div>-->
                    
<!-- Video -->                    
                    
                                     
                    
                    <div data-thumb="diapo/images/thumbs/ratatouille2.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b3.jpg"></a>
                    </div>
                    
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 


</div>

<div style="clear:both"></div>

</div>

</div><!-- INICIO CUERPO -->
<div id="contenedor_cuerpo">
	<div class="raya"></div>


  <div id="cuerpo">
    <div id="cuerpo_i">
    
    
    
    
    
      <div class="caja_1" style="height:230px;">
      <h1 class="fondo1">SOOPORTE TECNICO DE PC'S</h1>
      <div class="index_imagen" style="float:right; margin-left:10px; margin-top:5px; margin-right:5px;"><img src="img/sop2.jpg" width="213" height="180" border="0" />
      </div>
      <p class="c1"> Pensando en usted, para brindarle la confianza y la solidez, que implica nuestra experiencia en este rubro, le ofrecemos un servicio integral de Soluciones Informáticas, Mantenimiento, Diagnóstico de Computadoras, Soporte Técnico Online,  Instalación de Software, Antivirus, Cableado y Configuración de Redes para Internet e intranet. <br />
        La calidad y el tiempo de entrega de nuestros servicios, destacan sobre cualquier otro aspecto. Nuestros esfuerzos colectivos son los mejores referentes de lo que somos y lo que podemos decir de nosotros. </p>
      </div>
      <div class="caja_1">
        <h1 class="fondo1">SOPORTE TECNICO PRESENCIAL</h1>
        <div class="index_imagen" style="float:left; margin-left:10px; margin-top:15px; margin-right:10px;"><img src="img/sop3.jpg" width="188" height="126" border="0" />
      </div>
        <p class="c1"> Se trata de un servicio de <strong>mantenimiento</strong>. Nuestros técnicos se desplazarán a su empresa o domicilio con sus herramientas de trabajo para resolver cualquier problema informático que nos notifique en el menor tiempo posible.<br />
          El  buen funcionamiento de su PC en su empresa tanto como en su hogar es de suma importancia, hoy en día trabajamos con Internet, compartimos los mismos recursos dentro de nuestra oficina, es una herramienta de trabajo más, la cual tiene que funcionar en perfectas condiciones.<br />
        </p>
</div>
      <div class="caja_1">
      <h1 class="fondo1">SOPORTE Y SERVICIO TECNICO REMOTO (ONLINE)</h1>
      <div class="index_imagen" style="float:right; margin-left:10px; margin-top:5px;"><img src="img/sop1.jpg" width="242" height="153" border="0" />
      </div>
      <p class="c1"> Gracias a Internet podemos brindar <strong>soporte y servicio técnido remoto</strong> a nuestros clientes. Si dispone de una conexión a internet (con una simple conexión con modem es suficiente) podemos acceder a su PC y solucionar muchos inconvenientes gracias a nuestro<strong>Soporte y servicio técnico remoto</strong>.  Si la actualización de software y su configuración es un dolor de cabeza deje su computadora en manos de nuestro servicio de soporte técnico remoto de computadoras y olvide esas complicaciones. Solucionamos estos inconvenientes y muchos otros. Instalamos además cualquier Software que requiera (juegos, aplicaciones, actualizaciones, etc.). <br />
      </p>
</div>
      <div class="caja_500">
     Optimice su Computadora - Consiga el máximo potencial</div>
      
      
      
      
      
    <!--  <div class="caja_1">
      <h1 class="fondo1" style="text-align:center">GRATIS - LOS PAQUETES TIENEN REGALO </h1>
      <div style="float:left; width:384px; margin-left:10px;">
      <ul class="cablis_1">
		<li class="lis_1">Capacitación de 2 horas del uso del Gestos de contenidos.</li>
		<li class="lis_1">Registro en buscadores como  google, Bing y Yahoo.</li>
		<li class="lis_1">2 meses gratis registro en  AmarillasLatinas.net.</li>
      </ul>
      </div>
      <div style="float:left; width:384px; margin-left:10px;">
      <ul class="cablis_1">
		<li class="lis_1">6 meses gratis Sistema de atención a clientes.</li>
		<li class="lis_1">Disco duro Virtual de 1 GB Gratis.</li>
		<li class="lis_1">Llamada gratis por 100 minutos a todo destino .</li>
      </ul>
      </div>
      <div style="clear:both"></div>
      </div>-->
     
      
      
      
      <div class="caja_1">
      <h1 class="fondo1" style="text-align:center">  NUESTROS SERVICIOS</h1>
      <p class="c1">COMPIHOST ofrece los siguientes Servicios:</p>
      <!--<div style="float:left; width:384px; margin-left:10px;">
      <ul class="cablis_1">
		<li class="lis_1">Información de la empresa.</li>
		<li class="lis_1">Información de sus servicios y/ o productos.</li>
      </ul>
      </div>-->
      
      
      <div class="index_imagen" style="float:right; margin-left:10px;"><img src="img/servicio_tecnico.png" width="346" height="313" border="0" />
      </div>
      <div style="float:left; width:384px; margin-left:10px;">
        <ul>
          <li>Diagnóstico</li>
          <li>Mantenmimiento Preventivo</li>
          <li>Mantenimiento Correctivo</li>
          <li>Formateo e Instalación de Sistemas Operativos</li>
          <li>Instalación de Programas y Aplicativos</li>
          <li>Búsqueda y eliminación de virus</li>
          <li>Búsqueda y eliminación de spyware</li>
          <li>Optimización de equipo</li>
          <li><span lang="ES-SV" xml:lang="ES-SV">Desfragmentación de discos duros</span></li>
          <li><span lang="ES-SV" xml:lang="ES-SV">Escaneo sistema de archivos</span> </li>
          <li><span lang="ES-SV" xml:lang="ES-SV">Escaneo del registro</span> </li>
          <li>Cableado Estructurado CAT5, CAT6.</li>
          <li>Redes Inalámbricas.</li>
          <li>Recuperacion de Información (Windows XP)</li>
          <li>Configuración de correos corporativos</li>
          <li>Aceleración de tu PC, etc.</li>
        </ul>
      </div>
      
     
<br style="clear:both" />
      </div>
      
      
   
   
   
      <!--<div class="caja_1">
      <h1 class="fondo1" style="text-align:center">TODOS NUESTRO SERVIVIO DE SOPORTE TECNICO ES CON GARANTÍA</h1>
      <div style="float:left; width:384px; margin-left:10px;">
      <ul class="cablis_1">
		<li class="lis_1">Diseño de Sitio Web  a escoger. </li>
		<li class="lis_1">Publicación de su sitio para colocarlo en la web.</li>
		<li class="lis_1">Creación de cuenta de email (hasta 10 cuentas).</li>
		<li class="lis_1">Un mapa de ubicación.</li>
		<li class="lis_1">Entrenamiento y Consultas.</li>        
      </ul>
      </div>
      <div style="float:left; width:384px; margin-left:10px;">
      <ul class="cablis_1">
		<li class="lis_1">Una cabecera con el logo y slogan de su empresa.</li>
		<li class="lis_1">Una descripción de su servicio o productos.</li>
		<li class="lis_1">Un contador de visita.</li>
		<li class="lis_1">Registro en buscadores como  google, Bing y Yahoo.</li>
		<li class="lis_1">Un formulario de contáctenos para que le escriban a su correo.</li>  
      </ul>
      </div>
      <div style="clear:both"></div>
      </div>-->   
   
   
   
    
    
    
    
    
    
    
    
       <!--<div class="caja_200">
      <h1 class="fondo200">PLANES DE SERVICIO SOPORTE Y GARANTÍA</h1>
      <div  class="oferta2" style="float:left; width:370px; margin-left:10px; text-align:left; margin-top:10px;">
        <h4>
          <p align="center" style="color:#333"> PLAN ASISTENCIA UNICA
      </p>
    </h4>
      <ul class="cablis_1">
		<li class="lis_1">El cliente recibirá los servicios correspondientes a sus requerimientos.</li>
		<li class="lis_1">El cliente verificará el desempeño de su máquina, finalizada la asistencia.</li>
		<li class="lis_1"> El cliente tiene derecho a una asistencia remota durante los dos días posteriores a la asistencia.</li>
		</ul>
      <div style="width:185px; color: #F00; text-align: center; float:left; margin-bottom:20px;">
            <p class="caja_101" style="font-size:20px">S/. 70 .00
            </p>
              (Asistencia Presencial)
              
        </div>
              <div style="width:185px; color: #F00; text-align: center; float:left;margin-bottom:20px;">
            <p class="caja_101" style="font-size:20px">S/. 25 .00
              </p>
              (Asistencia Remota)
              
        </div>

<br />
      <p style="font-style:italic; font-size:12px; color:#666"> * EL precio esta planteado en base a una asistencia presencial por máquina, esto puede variar dependiendo dependiendo del número de máquinas.
      </div>
      <div  class="oferta2" style="float:left; width:370px; margin-left:10px; text-align:left; margin-top:10px;">
        <h4>
          <p align="center" style="color:#333"> PLAN ASISTENCIA MENSUAL</p>
    </h4>
      <ul class="cablis_1">
		<li class="lis_1">El cliente recibirá los servicios correspondientes a sus requerimientos.</li>
		<li class="lis_1">El cliente verificará el desempeño de su máquina, finalizada la asistencia.</li>
		<li class="lis_1"> El cliente tiene derecho a una asistencia remota durante los dos días posteriores a la asistencia.</li>
		</ul>
      <div style="width:185px; color: #F00; text-align: center; float:left; margin-bottom:20px;">
            <p class="caja_101" style="font-size:20px">S/. 70 .00
            </p>
              (Asistencia Presencial)
              
        </div>
              <div style="width:185px; color: #F00; text-align: center; float:left;margin-bottom:20px;">
            <p class="caja_101" style="font-size:20px">S/. 25 .00
              </p>
              (Asistencia Remota)
              
        </div>

<br />
      <p style="font-style:italic; font-size:12px; color:#666"> * EL precio esta planteado en base a una asistencia presencial por máquina, esto puede variar dependiendo dependiendo del número de máquinas.
      </div>
      <!--<div style="float:left; width:384px; margin-left:10px;">
       <br />
      <h4>
      <p align="center"> PLAN ASISTENCIA MENSUAL
      </p>
      </h4>
      <ul class="cablis_1">
		<li class="lis_1">Diseño y Programación Flash.</li>
		<li class="lis_1">Búsqueda Web Avanzada.</li>
		<li class="lis_1">Administración de Suscripción de Miembros.</li>
		<li class="lis_1">Páginas Protegidas por Contraseña.</li>
		<li class="lis_1">Calendario.</li>
        
		<li class="lis_1">Integración con Medios y Redes Sociales.</li> 
		<li class="lis_1">Formularios Personalizados.</li>
		<li class="lis_1">Alistamiento en Negocios Locales.</li>
		<li class="lis_1">Preguntas Frecuentes.</li>
		<li class="lis_1">Mapeo Integrado.</li> 
        
        <li class="lis_1">Configuración y Autenticación Segura de Certificados SSL.</li>
		<li class="lis_1">Comercio Electrónico – Lance su tienda en línea.</li>
		<li class="lis_1">Entrenamiento del uso del administrador de contenidos.</li> 
 
      </ul>
     </div>-->
             <div class="raya"></div>
          <br style="clear:both"/>
          
    </div>
      
  </div>
    
    
    
    
    
    <!-- INICIO OFERTAS -->
    <div id="cuerpo_d" align="center">
		

<!--      <div class="oferta2 mouse" onclick="location.href='dominio.php';">

      <p class="clase_2" style="padding:0px;">S/. 52<br /> 

      <p class="clase_3">por año</p>

      <p class="clase_1">Dominio</p>

      </div> -->

      <div class="oferta3 mouse" onclick="SexyLightbox.show('','cotizar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_4">COTIZAR</p>

      <p class="clase_6">la atención es inmediata</p>

      </div>  

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">NOTIFIQUE</p>

      <p class="clase_1">Todo Pago Realizado</p>

      </div>

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">SOPORTE</p>

      <p class="clase_1">Realice sus Consultas</p>

      </div>

      <div class="oferta3">

      <p class="clase_4">99.9%</p>

      <p class="clase_6">Tiempo de Actividad Garantizado</p>

      </div> 

    </div>    
    <!-- FIN OFERTAS --> 

    <div style="clear:both"></div>
  </div>

</div>
<!-- FIN CUERPO -->


<div id="contenedor_pie">

<div id="pie">
  <div id="logo_pie">
  <h1>COMPIHOST.NET, empresa peruana con mas de 6 años de experiencia y brindando el servicio de alojamiento web y registro de dominios.</h1>
  </div>
  <div id="slogan_pie">
  <ul>
    <li><a href="soporte.php" title="SOPORTE">SOPORTE</a></li>
    <li><a href="nuestra_tecnologia.php" title="NUESTRA TECNOLOGÍA">NUESTRA TECNOLOGÍA</a></li>
    <li><a href="preguntas_frecuentes.php" title="PREGUNTAS FRECUENTES">PREGUNTAS FRECUENTES</a></li>
    <li><a href="politicas_servicio.php" title="POLÍTICAS DEL SERVICIO">POLÍTICAS DEL SERVICIO</a></li>
    <li><a href="terminos_condiciones.php" title="TERMINOS Y CONDICIONES">TERMINOS Y CONDICIONES</a></li>
  </ul>
  </div>
  <div id="menu_pie">
  <p><strong>Teléfono: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email:</strong></p>
  <p>(511) 796 2663 - (511) 780 4649 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ventas@compihost.net</p>
  </div>
  <div style="clear:both"></div>
</div>
</div>
<script type="text/JavaScript">
	$(window).resize(function(){
        	$('.wrapper').css({
	               position:'fixed',
        	       left: ($(window).width() - $('.wrapper').outerWidth())/2,
               		top: ($(window).height() - $('.wrapper').outerHeight())/2
	          });
	});
	// Ejecutamos la función
	$(window).resize();
	$(document).ready(function(){
		$('#sup4').click(function(){
			$('#capa').fadeIn();
			$('#express').fadeIn();
		})
		$('.cerrar,#capa').click(function(){
		$('#capa').fadeOut();
		$('.wrapper').fadeOut();
	})
})
</script>
<!-- Script del Slider -->
<link rel='stylesheet' id='style-css'  href='diapo/diapo.css' type='text/css' media='all'> 
<script type='text/javascript' src='diapo/scripts/jquery.min.js'></script>
<!--[if !IE]><!--><script type='text/javascript' src='diapo/scripts/jquery.mobile-1.0rc2.customized.min.js'></script><!--<![endif]-->
<script type='text/javascript' src='diapo/scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='diapo/scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='diapo/scripts/diapo.js'></script> 

<script>
$(function(){
	$('.pix_diapo').diapo();
});
</script>



</body>

</html>

 <!-- Begin Attracta Include 2013-06-02 15:47 -->
<script type='text/javascript'> 
function attracta_loadjs(url) {
   (function() {
       var s = document.createElement('script');
       s.type = 'text/javascript';
       s.async = true;
       s.src = url;
       var x = document.getElementsByTagName('script')[0];
       x.parentNode.insertBefore(s, x);
   })();
}
function attracta_shouldrun() {
   var v = ["/admin/","/adm/","/wp-admin/","/administrator/"];
   for (x in v) if(window.location.pathname.indexOf(v[x]) == 0) return false;
   return true;
}
function attracta_window_width() {
   if (document.body && document.body.offsetWidth) return document.body.offsetWidth;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) return document.documentElement.offsetWidth;
   if (window.innerWidth) return window.innerWidth;
   return 0;
}
function attracta_window_height() {
   if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetHeight ) return document.documentElement.offsetHeight;
   if (window.innerHeight) return window.innerHeight;
   return 0;
}
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17302325-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- End Attracta Include 2013-06-02 15:47 -->

