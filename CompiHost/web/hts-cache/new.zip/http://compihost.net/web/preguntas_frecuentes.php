
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>COMPIHOST - Soluciones de Internet</title>

<link rel="stylesheet" type="text/css" href="css/estilos.css"/>

<link rel="icon" href="img/logocom.gif" type="image/gif">

<!-- WRAPER INICIO -->

<link rel="stylesheet" href="css/sexylightbox.css" type="text/css" media="all" />

<script src="js/jquery.js"></script>

<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<script type="text/javascript" src="js/sexylightbox.v2.3.jquery.js"></script>

<script type="text/javascript">

$(document).ready(

    function(){

           SexyLightbox.initialize({color:'00', 

	                                dir: 'sexyimages'

                                  });

              });

</script>

<script type="text/javascript">

	function meebo(valor){

			window.open('meebo.php','Consultas','width=230,height=520,resizable=NO,scrollbars=NO');			reload();

	}

</script>



<!-- WRAPER FIN -->

</head>



<body>

<!-- Envolve Chat -->

<!--Documentar chat--------<script type="text/javascript">

var envoSn=117836;

var envProtoType = (("https:" == document.location.protocol) ? "http://" : "http://");

document.write(unescape("%3Cscript src='" + envProtoType + "d.envolve.com/env.nocache.js' type='text/javascript'%3E%3C/script%3E"));

</script>---------- cerrar chat---->



<div id="capa"></div>
<div id="express" class="wrapper">
	<div class="cerrar">Cerrar(X)</div>
	<iframe src="http://info361903.supersite.srsportal.com/domain.php" width="99%" height="650px" style="margin-bottom:10px;"></iframe>
</div>


<div id="contenedor_cabecera">

<div id="grande"></div>

  <div id="logo">

  <h1>Brindamos soluciones de internet a su medida, gracias a la experiencia que contamos siendo nuestros servicios creación y optimización de página web, mantenimiento, implementación de  hosting y dominio, sistema atención de clientes, entre otros.</h1>

  </div>

  <div id="slogan">

    <p>Soluciones de Internet</p></div>

  <div id="menu_sup">

  	<div style="width:440px; float:right">

        <div class="link_sup" align="right" style="width:40px"><img src="img/home.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px; width:48px;"><a href="index.html" title="INICIO">Inicio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/empresa.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="nosotros.html" title="EMPRESA">Empresa</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/portafolio_icon.png" width="37" height="47"/></div>
        
        


        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="portafolio.html" title="PORTAFOLIO">Portafolio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/contacto.png" width="37" height="47"/></div>
                
        

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="contactenos.html" title="CONTÁCTENOS">Contáctenos</a></div>

		<div style="clear:both"></div>        

	</div>

  </div>

  <div style="clear:both"></div>

    <div class="raya"></div>

</div>



<div id="banner">

<div id="contenedor_banner" style="position:relative; background-color:#FFF">

  <div id="menu2" align="center" style="width:164px; height:369px; padding-left:0px; position: static;">

  <ul>

  <li style="width:164px; margin-right:0px; background-color:#FFF;"><a class="som_men" style="background-image:url(img/menu_amarillo.png); background-repeat:no-repeat; background-color:#FFF;" id="sup1" href="promociones.html" title="PROMOCIONES">Promociones</a></li>

  <li><a class="som_men" id="sup2" href="hosting.html" title="HOSTING">Hosting</a></li>
  
  <li><a class="som_men" href="http://info361903.supersite.srsportal.com/domain.php?TB_iframe=true&amp;height=700&amp;width=800" rel="sexylightbox" title="DOMINIO">Dominio</a></li>

  <li><a class="som_men" id="sup3" href="soluciones_web.html" title="SOLUCIONES WEB">Soluciones Web</a></li>

  <li><a class="som_men" id="sup7" href="e_marketing.html" title="E - MARKETING">E - Marketing</a></li>

  <li><a class="som_men" id="sup6" href="soporte.html" title="SOPORTE">Soporte Remoto</a></li>

  <!--<li><a class="som_men" id="sup5" href="sistemas.html" title="SISTEMAS">Sistemas</a></li>   -->

    </ul>

</div>
<div style="background:url(img/tablet.jpg) no-repeat; width:821px; height:373px; position:absolute; left:182px; top:0px; ">

  <section style="overflow:visible;"> 

    	<div style="position: absolute; width:300px; margin:123px 0 0 -90px; padding:0 20px;top: -100px;left: 90px;"> 
                <div class="pix_diapo">
					<div data-thumb="diapo/images/thumbs/up-official-trailer-fake.jpg" title="Haz clic y entérate de nuestras promociones">
                        <iframe width="734" height="324" src="http://www.youtube.com/embed/c1Z9tTjHIMA?rel=0&modestbranding=1&autoplay=1" data-fake="diapo/images/slides/up-official-trailer-fake.jpg" frameborder="0" allowfullscreen ></iframe>
                        
                        <div class="elemHover caption fromLeft elemToHide" style="bottom: 350px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; left:0">
                            You can also display videos, but it requires a "fake image"... read the documentation please
                        </div>
                    </div>

                    <div data-thumb="diapo/images/thumbs/megamind1048.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b1.jpg"></a>
                       <!-- <div class="caption elemHover fromLeft">
                            This is a simple sliding image with caption. You can have more than one caption and decide the layout of the caption via css.
                        </div>-->
                    </div>
                    
<!--                    <div data-thumb="diapo/images/thumbs/megamind_07.jpg">
                        <a href="https://www.facebook.com/COMPIHOST/app_79458893817" target="_blank" title="Haz clic y participa gratis en nuestros Sorteos"><img src="diapo/images/slides/b2.jpg"></a>-->
<!--                        <div class="caption elemHover fromRight" style="bottom:65px; padding-bottom:5px; color:#ff0; text-transform:uppercase">
                            Here you can see two captions.
                        </div>
                        <div class="caption elemHover fromLeft" style="padding-top:5px;">
                            The first are loaded immediately before than the second one
                        </div>-->
<!--                    </div>-->
                    
<!--                    <div data-thumb="diapo/images/thumbs/wall-e.jpg" data-time="7000">
                        <img src="diapo/images/slides/wall-e.jpg">
                        <div class="elemHover caption fromLeft" style="bottom:70px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px;">
                            You can also get the same effect as the caption with:
                        </div>
                        <div class="elemHover button fromTop" data-easing="easeOutExpo" style="left:388px; bottom:78px;">
                            A button
                        </div>
                        <div class="elemHover button button2 fromBottom" data-easing="easeOutExpo" style="left:512px; bottom:78px;">
                            Or two buttons
                        </div>
                        <div class="elemHover fadeIn" style="left:600px; bottom:auto; top:0; padding-top:50px; color:#ff0; font-size:13px; line-height:20px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; background:url(diapo/images/demo/arrow_caption.png) no-repeat 230px 30px">
                            Or any other html element...<br>
                            and you can decide the transition time of any slide
                        </div>
                    </div>-->
                    
<!-- Video -->                    
                    
                                     
                    
                    <div data-thumb="diapo/images/thumbs/ratatouille2.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b3.jpg"></a>
                    </div>
                    
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 


</div>

<div style="clear:both"></div>

</div>

</div>
<!-- INICIO CUERPO -->

<div id="contenedor_cuerpo">

  <div class="raya"></div>

  <div id="cuerpo">

    <div id="cuerpo_i">

    

    

    

    

    

      <div class="caja_1">            <a name="pregunta0"></a>

      <h1 class="fondo1">PREGUNTAS FRECUENTES</h1>

   

<ul>

<li><a href="#pregunta1">¿Qué es el servicio de Hosting ó Web Hosting?</a></li>

<li><a href="#pregunta2">¿Qué es un dominio?</a></li>

<li><a href="#pregunta3">¿Que puedo utilizar como parte del nombre de mi dominio?</a></li>

<li><a href="#pregunta4">¿Qué es un DNS?</a></li>

<li><a href="#pregunta5">¿Qué es la Propagación de los DNS?</a></li>

<li><a href="#pregunta6">¿Cuánto tiempo tarda en dispersarse?</a></li>

<li><a href="#pregunta7">¿Que sucede si pasa un año y no renuevo contrato?</a></li>

<li><a href="#pregunta8">¿Cuales son los pasos a seguir para contratar hosting con Compina.net?</a></li>

<li><a href="#pregunta9">¿Cuánto tiempo demora la activación del Servicio?</a></li>

<li><a href="#pregunta10">¿Como pago?</a></li>

<li><a href="#pregunta11">¿Cuentan con planes para empresas?</a></li>

<li><a href="#pregunta12">¿Que sucede cuando se sobrepasa el Espacio en Disco de mi cuenta?</a></li>

<li><a href="#pregunta13">¿Cuento con un Panel de Administración?</a></li>

<li><a href="#pregunta14">¿Tengo acceso FTP?</a></li>

<li><a href="#pregunta15">¿Y el soporte técnico?</a></li>

<li><a href="#pregunta16">¿Cuáles son los límites al contenido del sitio?</a></li>

<li><a href="#pregunta17">¿Cómo creo una cuenta de correo?</a></li>

<li><a href="#pregunta18">¿Cómo configuro mis cuentas de correo el Programa Outlook Express?</a></li>

<li><a href="#pregunta19">¿Cuento con un sistema de estadísticas de mi Sitio?</a></li>

<li><a href="#pregunta20">¿Cómo puedo instalar un contador en mi sitio?</a></li>

<li><a href="#pregunta21">¿Cúal es la velocidad de la conexión de los servidores?</a></li>

</ul>



      </div>

      

      

      <div class="caja_1">

      <h1 class="fondo1">RESPUESTAS</h1>

            <p class="c1">

            <a name="pregunta1"></a>

<strong>¿Qué es el servicio de Hosting ó Web Hosting?</strong><br />

El servicio de Hosting es el alquiler de un espacio en el disco duro de uno de nuestros servidores que están conectados directamente a la red de Internet en donde queda alojada su web. Esto quiere decir, que gracias a nuestra tecnología su pagina se beneficiará con mayores prestaciones y mejor tiempo de respuesta de su sitio hacia sus visitantes en la web.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta2"></a>

<strong>¿Qué es un dominio?</strong><br />

El dominio, es el nombre que usted usará para invocar su sitio web. Además puede identificar el país, si es un sitio de comercio, la organización, etc. Los más utilizados son .com.pe o .pe (identifica a Perú) y los utilizados a nivel mundial .com , .net , .org , .biz entre otros.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta3"></a>

<strong>¿Que puedo utilizar como parte del nombre de mi dominio?</strong><br />

El nombre del dominio puede utilizar cualquier palabra o puede ser una serie de caracteres pertenecientes al alfabeto definido por las letras del abecedario "a" a "z" (sin acentos, ni "ñ"), los dígitos "0" a "9" y el carácter "-" (signo menos).<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta4"></a>

<strong>¿Qué es un DNS?</strong><br />

DNS (Domain Name Server): Servidor de nombres. Es el equipo que resuelve los nombres de dominios. 

El Sistema de Nombres de Dominio o DNS: es un sistema que traduce un nombre de dominio a un número IP y, de esta forma, se localiza el servidor donde reside un sitio Web. Cada página web tiene una dirección IP asignada. La función de los servidores DNS es traducir el nombre de cada página a su correspondiente dirección IP.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta5"></a>

<strong>¿Qué es la Propagación de los DNS?</strong><br />

La propagación es el tiempo durante el cual la información de sus NS es dispersada en los servers de la red de Internet.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta6"></a>

<strong>¿Cuánto tiempo tarda en dispersarse?</strong><br />

El tiempo de Propagación oscila entre 12 a 24 horas máximo.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta7"></a>

<strong>¿Que sucede si pasa un año y no renuevo contrato?</strong><br />

Compina.net le envía con anticipación varios avisos al e-mail(s) registrado(s) con nosotros. Si el contrato no es renovado, la cuenta de hosting se elimina 5 días hábiles después de vencido este.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta8"></a>

<strong>¿Cuales son los pasos a seguir para contratar hosting con Compina.net?</strong><br />

Llene el formulario Contratar más el comprobante de pago, y en algunas horas, previa confirmación, estará recibiendo en su mail, los datos necesarios para comenzar a utilizar su servicio.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta9"></a>

<strong>¿Cuánto tiempo demora la activación del Servicio?</strong><br />

Una vez que confirmemos los datos del formulario de contrato, enviamos inmediatamente a usted todo lo necesario para que haga uso de su espacio Web. (Tiempo estimado entre 1hora hasta un máximo de 24 horas).<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



        <p class="c1">

          <a name="pregunta10"></a>

<strong>¿Como pago?</strong><br />

Tenemos diversas <a href="formas_pago.html">Formas de Pago</a>: puede ser a traves de Depósito ó Transferencia Bancaria.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta11"></a>

<strong>¿Qué es el servicio de Hosting ó Web Hosting?</strong><br />

¿Cuentan con planes para empresas?<br />

Si, los planes que se ajustan para su empresa son: <br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ESPACIO <a href="web_hosting.html">NHD-01</a> espacio de 1 GB <br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ESPACIO <a href="web_hosting.html">NHD-02</a> espacio de 2,5 GB <br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ESPACIO <a href="web_hosting.html">NHD-03</a> espacio de 5 GB <br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ESPACIO <a href="web_hosting.html">NHD-04</a> espacio de 10 GB <br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ESPACIO <a href="web_hosting.html">NHD-05</a> espacio de 25 GB <br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ESPACIO <a href="web_hosting.html">NHD-06</a> espacio de 50 GB <br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ESPACIO <a href="web_hosting.html">NHD-07</a> espacio de 100 GB <br />

Si necesita mas espacio o ver sus caracteristicas de cada uno dar click.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta12"></a>

<strong>¿Que sucede cuando se sobrepasa el Espacio en Disco de mi cuenta?</strong><br />

Si el Espacio en Disco excede al asignado, Usted deberá adquirir MB adicionales, no acrecentamos su espacio automáticamente porque implica un costo, deberá contactarse con nosotros e indicarnos cuantos MB se le reasignarán a su Plan.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta13"></a>

<strong>¿Cuento con un Panel de Administración?</strong><br />

Cada uno de nuestros clientes posee su propio Panel de Control. Desde el Panel de Control pueden acceder a todas las funcionalidades del servicio de hosting (estadísticas, crear sus cuentas de correo electrónico, crear bases de datos, instalar un foro, sala de chat, etc.).<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



        <p class="c1">

          <a name="pregunta14"></a>

<strong>¿Tengo acceso FTP?</strong><br />

Para acceder a su espacio de web hosting en nuestros servidores, usted tiene una o más cuentas FTP que le permitirá ingresar remotamente a todas sus carpetas (bases de datos, sitio web, etc.) para subir archivos tantas veces como necesite las 24 horas, los 365 días del año.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta15"></a>

<strong>¿Y el soporte técnico?</strong><br />

Cualquier necesidad de soporte al email: soporte@compina.net, respondemos inmediatamente ó dentro de un plazo máximo de 6 hrs. Consulte las opciones de <a href="soporte.html">Soporte Técnico</a>.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta16"></a>

<strong>¿Cuáles son los límites al contenido del sitio?</strong><br />



Compina.net no limita ni interfiere en ningún caso respecto del contenido que Ud. desee tener en su sitio web, salvo las siguientes excepciones:<br />

- No admitimos sitios que fomenten la pornografía infantil. <br />

- No admitimos sitios que contengan material que incite a fraude o estafas.<br />

- No se aceptan instalaciones en el servidor que realizen SPAM (envío masivo de correo electrónico no deseado).<br />

- Revise nuestros <a href="terminos_condiciones.html">términos y condiciones</a> de contrato.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta17"></a>

<strong>¿Cómo creo una cuenta de correo?</strong><br />

Para la creación de cuentas de correo deberá ingresar al Panel de Control de su dominio, con su nombre de usuario y contraseña. Encontrará allí una lista de opciones, entre ellas "correo" desde la cual podrá crear cuentas de correos. 

Así de sencillo usted puede realizar estas tareas y otras en forma totalmente autónoma en el momento que Ud. lo desee y tantas veces como lo necesite. Dele un vistazo a nuestro Panel de Control.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta18"></a>

<strong>¿Cómo configuro mis cuentas de correo el Programa Outlook Express?</strong><br />

En su Outlook Express siga estos pasos:<br />

- Ir a herramientas<br />

- Cuentas<br />

- Agregar<br />

- Correo<br />

- Ponga su nombre ... presione siguiente<br />

- Ponga su dirección de correo (ejemplo: info@sudominio.com) ...siguiente<br />

- Deje POP3 en la primera opción, en correo entrante ponga: mail.sudominio.com, en correo saliente ponga: mail.sudominio.com...siguiente<br />

- En nombre de cuenta, la dirección de correo completa (ejemplo: info@sudominio.com ), abajo la contraseña, active recordar contraseña. <br />

- click en FINALIZAR<br />

Tambien puede revisar nuestros video Tutoriales para configurar el Outlook Express, el Outlook 2003 y el Outlook 2007<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta19"></a>

<strong>¿Cuento con un sistema de estadísticas de mi Sitio?</strong><br />

Sí, Usted cuenta en el Panel de Control con un completo sistema de estadística, puede ver quién visitó su sitio, que páginas navegó, cuánto tiempo estuvo, de dónde provino, y muchos datos más. 

Para visualizarlas deberá ingresar a la opción "Estadísticas Web" de su Panel de Control.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta20"></a>

<strong>¿Cómo puedo instalar un contador en mi sitio?</strong><br />

Los pasos para la instalación del contador, son los siguientes: <br />

1- Ingresar a Cpanel. <br />

2- Ir a CGI Center.<br />

3- Ingresar en Counter.<br /> 

4- Una vez allí, verá que existen una serie de opciones para configurar la hora, la zona horaria, el color, etc.<br /> 

5- Luego de esto, al hacer Preview, verá como quedará. <br />

6- Luego de ver la Preview, hacer click sobre MAKE HTML y abajo de todo muestra el código que debe incluir en la pantalla que desea que aparezca el contador.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



            <p class="c1">

            <a name="pregunta21"></a>

<strong>¿Cúal es la velocidad de la conexión de los servidores?</strong><br />

Conexiones de los Servers: 10GB/Seg contamos con una línea OC-192 que es una fibra óptica de la red con un índice SONET de 9953.28 Mbit/s, o 192 veces 51.84 la señal básica de Mbit/s SONET (OC-1), de ahí el nombre OC-192.<br />

<a href="#pregunta0">[ Volver al inicio ]</a>

</p>



 



      </div>

      

        <div class="img_1">

    <img src="img/preguntas.jpg" width="780" height="414"  alt="NUESTRA TECNOLOGÍA" title="NUESTRA TECNOLOGÍA" />

   </div>  



  

      





   

 



    



      

    </div>

    

    

    

    

    

    <!-- INICIO OFERTAS -->

    <div id="cuerpo_d" align="center">



    <div id="menu_vertical">

    <ul>

    <li><a href="nuestra_tecnologia.html" title="NUESTRA TECNOLOGÍA">Nuestra Tecnología</a></li>  

    <li><a href="preguntas_frecuentes.html" title="PREGUNTAS FRECUENTES">Preguntas Frecuentes</a></li> 

    <li><a href="politicas_servicio.html" title="POLITICAS DEL SERVICIO">Políticas del Servicio</a></li> 

     <li><a href="terminos_condiciones.html" title="TERMINOS Y CONDICIONES">Términos y Condiciones</a></li> 

    </ul>

    <div style="clear:both"></div>

    </div>   

    

<!--      <div class="oferta2 mouse" onclick="location.href='dominio.php';">

      <p class="clase_2" style="padding:0px;">S/. 52<br /> 

      <p class="clase_3">por año</p>

      <p class="clase_1">Dominio</p>

      </div> -->

      <div class="oferta3 mouse" onclick="SexyLightbox.show('','cotizar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_4">COTIZAR</p>

      <p class="clase_6">la atención es inmediata</p>

      </div>  

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">NOTIFIQUE</p>

      <p class="clase_1">Todo Pago Realizado</p>

      </div>

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">SOPORTE</p>

      <p class="clase_1">Realice sus Consultas</p>

      </div>

      <div class="oferta3">

      <p class="clase_4">99.9%</p>

      <p class="clase_6">Tiempo de Actividad Garantizado</p>

      </div> 


    </div>

    <!-- FIN OFERTAS --> 

    <div style="clear:both"></div>

  </div>

    <div class="raya"></div>

</div>

<!-- FIN CUERPO -->





<div id="contenedor_pie">

<div id="pie">
  <div id="logo_pie">
  <h1>COMPIHOST.NET, empresa peruana con mas de 6 años de experiencia y brindando el servicio de alojamiento web y registro de dominios.</h1>
  </div>
  <div id="slogan_pie">
  <ul>
    <li><a href="soporte.html" title="SOPORTE">SOPORTE</a></li>
    <li><a href="nuestra_tecnologia.html" title="NUESTRA TECNOLOGÍA">NUESTRA TECNOLOGÍA</a></li>
    <li><a href="preguntas_frecuentes.html" title="PREGUNTAS FRECUENTES">PREGUNTAS FRECUENTES</a></li>
    <li><a href="politicas_servicio.html" title="POLÍTICAS DEL SERVICIO">POLÍTICAS DEL SERVICIO</a></li>
    <li><a href="terminos_condiciones.html" title="TERMINOS Y CONDICIONES">TERMINOS Y CONDICIONES</a></li>
  </ul>
  </div>
  <div id="menu_pie">
  <p><strong>Teléfono: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email:</strong></p>
  <p>(511) 796 2663 - (511) 780 4649 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ventas@compihost.net</p>
  </div>
  <div style="clear:both;"></div>
</div>
</div>
  <div style="clear:both"><script language="javascript">
function cerrar_chat(){ //cerrar chat
document.getElementById("consulta").style.visibility="hidden";	
document.getElementById("pointer").style.visibility="hidden";
document.getElementById("ventana").style.paddingTop="6px";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/minimizar.png" onclick="abrir_chat();" style="cursor:pointer;"  border="0"/>';	
}



function abrir_chat(){ //abrir chat
document.getElementById("consulta").style.visibility="visible";	
document.getElementById("pointer").style.visibility="visible";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />';
document.getElementById("ventana").style.paddingTop="1px";	
	
	
	} 

</script>



 

<div style="position:fixed; bottom:38px; right:5px; z-index:3000; height:62px;">
<!-- mibew button --><!-- / mibew button -->
<table width="231" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="231" height="51" align="center" valign="top"><a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;"><img src="http://compihost.net/soluciones/chat_compihost/images/boton-consulta.png"  name="consulta" id="consulta" border="0"/></a></td>
  </tr>
  <tr>
    <td height="19" align="center" valign="top">
    
    <table width="150" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="19" height="24" align="center" valign="top">
        <div id="ventana" style="height:14px;" align="center">
      <img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />
        </div>
        </td>
        <td width="131" height="19" align="left" valign="top"><div id="click">
        <a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;">
        <img src="http://compihost.net/soluciones/chat_compihost/images/haz-click.png" width="130" height="19" border="0"/></a></div></td>
      </tr>
    </table>

    
    
    </td>
  </tr>
</table>
<img src="http://compihost.net/soluciones/chat_compihost/images/pointer.png" width="42" height="54" border="0" style="position: absolute; left: 199px; top: 46px;" id="pointer"/></div>





  









</div>

</div>

</div>

<script type="text/JavaScript">
	$(window).resize(function(){
        	$('.wrapper').css({
	               position:'fixed',
        	       left: ($(window).width() - $('.wrapper').outerWidth())/2,
               		top: ($(window).height() - $('.wrapper').outerHeight())/2
	          });
	});
	// Ejecutamos la función
	$(window).resize();
	$(document).ready(function(){
		$('#sup4').click(function(){
			$('#capa').fadeIn();
			$('#express').fadeIn();
		})
		$('.cerrar,#capa').click(function(){
		$('#capa').fadeOut();
		$('.wrapper').fadeOut();
	})
})
</script>
<!-- Script del Slider -->
<link rel='stylesheet' id='style-css'  href='diapo/diapo.css' type='text/css' media='all'> 
<script type='text/javascript' src='diapo/scripts/jquery.min.js'></script>
<!--[if !IE]><!--><script type='text/javascript' src='diapo/scripts/jquery.mobile-1.0rc2.customized.min.js'></script><!--<![endif]-->
<script type='text/javascript' src='diapo/scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='diapo/scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='diapo/scripts/diapo.js'></script> 

<script>
$(function(){
	$('.pix_diapo').diapo();
});
</script>




</body>



</html>


 <!-- Begin Attracta Include 2013-06-02 15:47 -->
<script type='text/javascript'> 
function attracta_loadjs(url) {
   (function() {
       var s = document.createElement('script');
       s.type = 'text/javascript';
       s.async = true;
       s.src = url;
       var x = document.getElementsByTagName('script')[0];
       x.parentNode.insertBefore(s, x);
   })();
}
function attracta_shouldrun() {
   var v = ["/admin/","/adm/","/wp-admin/","/administrator/"];
   for (x in v) if(window.location.pathname.indexOf(v[x]) == 0) return false;
   return true;
}
function attracta_window_width() {
   if (document.body && document.body.offsetWidth) return document.body.offsetWidth;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) return document.documentElement.offsetWidth;
   if (window.innerWidth) return window.innerWidth;
   return 0;
}
function attracta_window_height() {
   if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetHeight ) return document.documentElement.offsetHeight;
   if (window.innerHeight) return window.innerHeight;
   return 0;
}
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17302325-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- End Attracta Include 2013-06-02 15:47 -->

