<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/diagramacion.css"/>
<link rel="stylesheet" type="text/css" href="css/estilos.css"/>
<link rel="stylesheet" type="text/css" href="css/css.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="img/logocom.gif" type="image/gif">
<script type="text/javascript">
function cerrar(){
	alert("hola");
	;
	}
</script>

<title>Consultas ONLINE</title>
</head>
<body>
<center>
<div align="center" style="width:210px; height:500px; padding-top:10px;">
	<embed id="chat" src="http://widget.meebo.com/mm.swf?TyVWsBiFYV" type="application/x-shockwave-flash" width="197" height="384"></embed>
    <br />
    <br />
    <div class="oferta2 index_parrafo_1" style="color:#333; font-weight:bold; background-color: #F5F5F5; border-color:#CCC; width:188px;" align="center">
            HORARIO DE ATENCION<br />
            9:00 am - 1:25 pm<br />
            2:30 pm - 6:00 pm<br />
            (Hora Peruana)
  </div>
</div>
</center>
</body>
</html>

 <!-- Begin Attracta Include 2013-06-02 15:47 -->
<script type='text/javascript'> 
function attracta_loadjs(url) {
   (function() {
       var s = document.createElement('script');
       s.type = 'text/javascript';
       s.async = true;
       s.src = url;
       var x = document.getElementsByTagName('script')[0];
       x.parentNode.insertBefore(s, x);
   })();
}
function attracta_shouldrun() {
   var v = ["/admin/","/adm/","/wp-admin/","/administrator/"];
   for (x in v) if(window.location.pathname.indexOf(v[x]) == 0) return false;
   return true;
}
function attracta_window_width() {
   if (document.body && document.body.offsetWidth) return document.body.offsetWidth;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) return document.documentElement.offsetWidth;
   if (window.innerWidth) return window.innerWidth;
   return 0;
}
function attracta_window_height() {
   if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetHeight ) return document.documentElement.offsetHeight;
   if (window.innerHeight) return window.innerHeight;
   return 0;
}
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17302325-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- End Attracta Include 2013-06-02 15:47 -->

