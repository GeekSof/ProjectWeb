




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>COMPIHOST - Soluciones de Internet</title>

<link rel="stylesheet" type="text/css" href="css/estilos.css"/>

<link rel="icon" href="img/logocom.gif" type="image/gif">

<!-- WRAPER INICIO -->

<link rel="stylesheet" href="css/sexylightbox.css" type="text/css" media="all" />

<script src="js/jquery.js"></script>

<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<script type="text/javascript" src="js/sexylightbox.v2.3.jquery.js"></script>

<script type="text/javascript">

$(document).ready(

    function(){

           SexyLightbox.initialize({color:'00', 

	                                dir: 'sexyimages'

                                  });

              });

</script>

<script type="text/javascript">

	function meebo(valor){

			window.open('meebo.php','Consultas','width=230,height=520,resizable=NO,scrollbars=NO');

			reload();

	}

</script>



<!-- WRAPER FIN -->

</head>



<body>

<!-- Envolve Chat -->

<!--Documentar chat--------<script type="text/javascript">

var envoSn=117836;

var envProtoType = (("https:" == document.location.protocol) ? "http://" : "http://");

document.write(unescape("%3Cscript src='" + envProtoType + "d.envolve.com/env.nocache.js' type='text/javascript'%3E%3C/script%3E"));

</script>---------- cerrar chat---->



<div id="capa"></div>
<div id="express" class="wrapper">
	<div class="cerrar">Cerrar(X)</div>
	<iframe src="http://info361903.supersite.srsportal.com/domain.php" width="99%" height="650px" style="margin-bottom:10px;"></iframe>
</div>


<div id="contenedor_cabecera">

<div id="grande"></div>

  <div id="logo">

  <h1>Brindamos soluciones de internet a su medida, gracias a la experiencia que contamos siendo nuestros servicios creación y optimización de página web, mantenimiento, implementación de  hosting y dominio, sistema atención de clientes, entre otros.</h1>

  </div>

  <div id="slogan">

    <p>Soluciones de Internet</p></div>

  <div id="menu_sup">

  	<div style="width:440px; float:right">

        <div class="link_sup" align="right" style="width:40px"><img src="img/home.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px; width:48px;"><a href="index.html" title="INICIO">Inicio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/empresa.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="nosotros.html" title="EMPRESA">Empresa</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/portafolio_icon.png" width="37" height="47"/></div>
        
        


        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="portafolio.html" title="PORTAFOLIO">Portafolio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/contacto.png" width="37" height="47"/></div>
                
        

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="contactenos.html" title="CONTÁCTENOS">Contáctenos</a></div>

		<div style="clear:both"></div>        

	</div>

  </div>

  <div style="clear:both"></div>

    <div class="raya"></div>

</div>



<div id="banner">

<div id="contenedor_banner" style="position:relative; background-color:#FFF">

  <div id="menu2" align="center" style="width:164px; height:369px; padding-left:0px; position: static;">

  <ul>

  <li style="width:164px; margin-right:0px; background-color:#FFF;"><a class="som_men" style="background-image:url(img/menu_amarillo.png); background-repeat:no-repeat; background-color:#FFF;" id="sup1" href="promociones.html" title="PROMOCIONES">Promociones</a></li>

  <li><a class="som_men" id="sup2" href="hosting.html" title="HOSTING">Hosting</a></li>
  
  <li><a class="som_men" href="http://info361903.supersite.srsportal.com/domain.php?TB_iframe=true&amp;height=700&amp;width=800" rel="sexylightbox" title="DOMINIO">Dominio</a></li>

  <li><a class="som_men" id="sup3" href="soluciones_web.html" title="SOLUCIONES WEB">Soluciones Web</a></li>

  <li><a class="som_men" id="sup7" href="e_marketing.html" title="E - MARKETING">E - Marketing</a></li>

  <li><a class="som_men" id="sup6" href="soporte.html" title="SOPORTE">Soporte Remoto</a></li>

  <!--<li><a class="som_men" id="sup5" href="sistemas.html" title="SISTEMAS">Sistemas</a></li>   -->

    </ul>

</div>
<div style="background:url(img/tablet.jpg) no-repeat; width:821px; height:373px; position:absolute; left:182px; top:0px; ">

  <section style="overflow:visible;"> 

    	<div style="position: absolute; width:300px; margin:123px 0 0 -90px; padding:0 20px;top: -100px;left: 90px;"> 
                <div class="pix_diapo">
					<div data-thumb="diapo/images/thumbs/up-official-trailer-fake.jpg" title="Haz clic y entérate de nuestras promociones">
                        <iframe width="734" height="324" src="http://www.youtube.com/embed/c1Z9tTjHIMA?rel=0&modestbranding=1&autoplay=1" data-fake="diapo/images/slides/up-official-trailer-fake.jpg" frameborder="0" allowfullscreen ></iframe>
                        
                        <div class="elemHover caption fromLeft elemToHide" style="bottom: 350px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; left:0">
                            You can also display videos, but it requires a "fake image"... read the documentation please
                        </div>
                    </div>

                    <div data-thumb="diapo/images/thumbs/megamind1048.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b1.jpg"></a>
                       <!-- <div class="caption elemHover fromLeft">
                            This is a simple sliding image with caption. You can have more than one caption and decide the layout of the caption via css.
                        </div>-->
                    </div>
                    
<!--                    <div data-thumb="diapo/images/thumbs/megamind_07.jpg">
                        <a href="https://www.facebook.com/COMPIHOST/app_79458893817" target="_blank" title="Haz clic y participa gratis en nuestros Sorteos"><img src="diapo/images/slides/b2.jpg"></a>-->
<!--                        <div class="caption elemHover fromRight" style="bottom:65px; padding-bottom:5px; color:#ff0; text-transform:uppercase">
                            Here you can see two captions.
                        </div>
                        <div class="caption elemHover fromLeft" style="padding-top:5px;">
                            The first are loaded immediately before than the second one
                        </div>-->
<!--                    </div>-->
                    
<!--                    <div data-thumb="diapo/images/thumbs/wall-e.jpg" data-time="7000">
                        <img src="diapo/images/slides/wall-e.jpg">
                        <div class="elemHover caption fromLeft" style="bottom:70px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px;">
                            You can also get the same effect as the caption with:
                        </div>
                        <div class="elemHover button fromTop" data-easing="easeOutExpo" style="left:388px; bottom:78px;">
                            A button
                        </div>
                        <div class="elemHover button button2 fromBottom" data-easing="easeOutExpo" style="left:512px; bottom:78px;">
                            Or two buttons
                        </div>
                        <div class="elemHover fadeIn" style="left:600px; bottom:auto; top:0; padding-top:50px; color:#ff0; font-size:13px; line-height:20px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; background:url(diapo/images/demo/arrow_caption.png) no-repeat 230px 30px">
                            Or any other html element...<br>
                            and you can decide the transition time of any slide
                        </div>
                    </div>-->
                    
<!-- Video -->                    
                    
                                     
                    
                    <div data-thumb="diapo/images/thumbs/ratatouille2.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b3.jpg"></a>
                    </div>
                    
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 


</div>

<div style="clear:both"></div>

</div>

</div>
<!-- INICIO CUERPO -->

<div id="contenedor_cuerpo">

  <div class="raya"></div>

  <div id="cuerpo">

    <div id="cuerpo_i">

    

    

      <div class="caja_1">

      <h1 class="fondo1">TERMINOS Y CONDICIONES</h1>

      <p class="c1">

<strong>1. COMPIHOST.NET</strong> se reserva el derecho de admisión según sus condiciones de servicio. 

<br /><br />

<strong>2.</strong> <strong>El cliente</strong> o <strong>contratante</strong> acepta estas condiciones aquí propuestas al momento de realizar una compra de servicios, pudiendo estar ser modificadas sin previo aviso. Estando obligado a los pagos por estos mismos mediante formularios de contrato y aceptando sus términos. No se prestará ningún servicio hasta que el cliente haya abonado la totalidad del pago por los servicios contratados.<br /><br />

El servicio se realizará una vez que se tenga constancia mediante comprobante de que se ha realizado la operación de abono. Cualquier gasto originado al utilizar estos medios de pago, serán por cuenta del cliente.<br /><br />

Ninguna de las compras se puede efectuar de manera <strong>ANÓNIMA</strong>, el cliente está obligado a proporcionar a <strong>COMPIHOST.NET</strong> sus datos reales y eventualmente comprobables.

<br /><br />

<strong>3. El Cliente</strong> no podrá exigir mas servicios por lo que ha pagado a <strong>COMPINA.NET</strong>, las <strong>OFERTAS</strong> especiales o <strong>BONOS</strong> adicionales en cada <strong>PLAN</strong> tampoco se consideran como parte de un contrato.

<br /><br />

<strong>4. COMPIHOST.NET</strong> es responsable por los servicios que brinda (Hosting, dominios en un <strong>99% de UP TIME</strong> - Tiempo en Linea).

No podrán ser de nuestra responsabilidad el corte del servicio por agentes ajenos a nuestra responsabilidad como desastres naturales, o similares. Se incluye la petición de algún tribunal de justicia por motivos de investigación al cliente previa orden.

<br /><br />

<strong>5. COMPIHOST.NET</strong>  no se hace responsable por servicios informáticos prestados por terceros pudiendo ser agentes de Hardware, Software, redes, acceso a Internet, etc. que interfieran en el buen funcionamiento del servicio prestado.

<br /><br />

<strong>6. El cliente</strong> es responsable de la información que coloque en su sitio web, o la utilización de correos, quedando terminantemente prohibido aquellos que estipule la ley en el país de contrato.

<br /><br />

<strong>7.</strong> Si la actividad de cualquier cliente genera demanda legal en contra de <strong>COMPINA.NET</strong>, el cliente será responsable por todo el daño financiero ocasionado a <strong>COMPINA.NET</strong>, así como el resto de otros gastos legales (es decir, abogados, costos del transporte, etc).

<br /><br />

<strong>8.</strong> Queda terminantemente prohibido usar los servicios asignados por <strong>COMPIHOST.NET</strong> para realizar (SPAM-Correo Electrónico no solicitado), estar como intermediario o similares. La violación de esta norma automáticamente significará la cancelación definitiva o temporal (según responsabilidad y sometida a sanciones del proveedor) de la cuenta de hosting adquirida sin derecho a reclamo ni reembolso y el contenido del <strong>WEBSITE</strong> será eliminado sin previo aviso. <br /><br />También prohibidos:<br /><br />

SPAM, Hacker, Warez, Cracker, usar el servidor para fines ILÍCITOS, IRC, sexo explicito o desnudos sin consentimiento, pedofilia, terrorismo, almacenaje de música sin derechos o similares, etc. consumo en exceso de los recursos del servidor, abuso del servicio, satanismo o temas contra la moral y las buenas costumbres, racismo y todo aquello que atente con la seguridad del servidor y los sitios alojados en el.

No se podrá utilizar los servicios brindados por COMPIHOST.NET para promover actividades penadas por la ley que no hayan sido consideradas en este texto. <br /><br />

<strong>9.</strong> Debe quedar claro que el <strong>CPU</strong> y <strong>MEMORIA</strong> es diferente al uso de <strong>ESPACIO</strong> y <strong>TRAFICO</strong> asignado en su cuenta. Se suspenden las cuentas cuando estas llegan a consumir de forma excesiva los recursos del servidor, que afectan a otros usuarios y causa que presenten fallos de velocidad y funcionamiento, algo que no puede aceptarse en un hosting compartido. Si el consumo se debe a cuestiones de crecimiento progresivo considerado normal del sitio podemos ayudarle en la migración a un Servidor Virtual (VPS), o un servidor dedicado, por el contrario si son acciones ilegales o que de un momento a otro comprometieran la seguridad y estabilidad del servidor suspenderemos y aplicaremos las sanciones correspondientes.

Consumo máximo permitido: 2% a 3% del <strong>CPU</strong> y <strong>MEMORIA</strong> en periodos cortos de tiempo, de acuerdo a la cuenta que tenga contratada.

<br /><br />

<strong>10.</strong> El servicio de Soporte Técnico es prestado mediante via correo electrónico y/o msn, (Solo emergencias Vía Telefónica al número <strong>511-3763577</strong>). El servicio podrá ser suspendido por motivos de abuso en el servicio, comentarios mal intencionados sin las pruebas correspondientes, negligencias por parte del cliente, o la falta de respeto.

El servicio de soporte se limita únicamente al funcionamiento del servidor prestado, y no comprende aquellos problemas originados por programas, scripts o rutinas colocadas por el propio usuario, <strong>COMPIHOST.NET</strong> asesora pero no capacita.

<br /><br />

<strong>11.</strong> El servicio de Web Hosting (No dominios), podrá suspenderse bajo los siguientes términos (no incluye para el caso de dominios):<br /><br />

a. A petición del cliente: Pudiendo ser por motivos administrativos, en donde no se considera ningún tipo de devoluciones de dinero ya que el contrato es por periodos anuales y el cliente así lo aceptó antes de proceder con la compra.<br /><br />

b. Por COMPINA.NET: Cuando el servicio sea utilizado por algún acto indebido estipulado anteriormente o SPAM. En este caso no hay devoluciones de dinero.<br /><br />

c. Por COMPINA.NET: Cuando haya diferencias insalvables con nuestro cliente  y sea necesaria la desactivación del servicio web, en este caso se retendrá un 50% del monto total entregado (pago) por conceptos administrativos + la parte proporcional del servicio consumido.<br /><br />

Si se ha emitido factura no habrá devolución del 19% del IGV.<br /><br />

<strong>COMPIHOST.NET</strong> no podrá asumir gastos ni reembolsos de ningún tipo mayores a los recibidos por el pago de la prestación del servicio.<br /><br />

* El registro o transferencia de dominios (una vez realizados por <strong>COMPINA.NET</strong>) no tienen devolución alguna debido a la naturaleza del mismo (se hacen de año a año o según periodos contratados por el cliente sin posibilidad regresiva).<br /><br />



<strong>12.</strong> Si bien se realizan copias de seguridad en nuestros servidores, el cliente es responsable de mantener sus propias copias de seguridad de archivos colocados en el servidor o el contenido de los correos.

<br /><br />

<strong>13. </strong>SI en caso de Hosting, el cliente llegara a exceder los servicios proporcionados o estuviera a punto de hacerlo, este debe de pagar por los excesos a la tarifa vigente o contratar un plan superior. Si no realiza los pagos el servicio será suspendido hasta el próximo periodo de conteo.

<br /><br />

<strong>14. </strong>El cliente puede dar por terminado el contrato de prestación de servicios notificando un mes antes del termino del servicio vigente (para contratos anuales) o una semana antes (para contratos mensuales), o en su defecto la renovación de los mismos bajo los términos que aquí se proponen.

<br /><br />

<strong>15.</strong> Renovar cuentas vencidas tienen un costo extra de US$5.00 a US$10.00 dependiendo del plan y el tiempo en que se renueven. En este caso antes de renovar se deben realizar las consultas necesarias para la disponibilidad tecnica.

<br /><br />

<strong>16.</strong> Nuestro costos pueden ser modificados de acuerdo a los índices económicos vigentes a la fecha de renovación y/o contrato. Solo se dará aviso de esos cambios a nuestros clientes.<br /><br />



<strong>17.</strong> Nuestros costos publicados incluyen el 18% del IGV, si lo desea puede opcionalmente pedir una FACTURA/RECIBO.

<br /><br />

<strong>18. </strong>Están liberados del IGV de forma explicita los clientes internacionales (fuera del Territorio Peruano), aquellos clientes no podrán exigir facturas.

<br /><br />

<strong>19. </strong>La Pasarela de Pagos con Tarjeta de Crédito es por el momento exclusivamente para clientes internacionales (que residen fuera de Territorio Peruano). Teniendo en consideración que nuestro sistema antifraude puede tardar hasta 48 horas en procesar su pedido y hacerlo exitoso. Serán sancionados aquellos clientes que intenten cometer fraude o la utilización de cuentas y tarjetas que no les pertenecen sin el consentimiento del propietario, cancelando todo servicio y aplicando las sanciones internacionales correspondientes.<br /><br />

Aunque el descuento en su cuenta de <strong>BANCO</strong> (afiliado a su tarjeta) puede se inmediato, la aprobación puede darse hasta en 48 horas o máximo 72.

El intento de fraude con Tarjeta de Crédito amerita la cancelación de todos los servicios proporcionados y su posterior denuncia ante las autoridades.

<br /><br />

Otros puntos no estipulados aquí se tratarán con el cliente (no teniendo validez legal a no ser firme un contrato con estos arreglos).

<br /><br />

Por favor escriba un e-mail a: info<img src="img/arroba.png" alt="COMPIHOST" title="COMPIHOST" width="14" height="13" />compihost.net para mayor información. Si desea más prontitud en el proceso de su solicitud necesariamente la confirmación es por Teléfono. </p>

      </div>

      

    </div>

    <!-- INICIO OFERTAS -->

    <div id="cuerpo_d" align="center">



 <div id="menu_vertical">

    <ul>

    <li><a href="nuestra_tecnologia.html" title="NUESTRA TECNOLOGÍA">Nuestra Tecnología</a></li>  

    <li><a href="preguntas_frecuentes.html" title="PREGUNTAS FRECUENTES">Preguntas Frecuentes</a></li> 

    <li><a href="politicas_servicio.html" title="POLITICAS DEL SERVICIO">Políticas del Servicio</a></li> 

     <li><a href="terminos_condiciones.html" title="TERMINOS Y CONDICIONES">Términos y Condiciones</a></li> 

    </ul>

    <div style="clear:both"></div>

    </div>
    

<!--      <div class="oferta2 mouse" onclick="location.href='dominio.php';">

      <p class="clase_2" style="padding:0px;">S/. 52<br /> 

      <p class="clase_3">por año</p>

      <p class="clase_1">Dominio</p>

      </div> -->

      <div class="oferta3 mouse" onclick="SexyLightbox.show('','cotizar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_4">COTIZAR</p>

      <p class="clase_6">la atención es inmediata</p>

      </div>  

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">NOTIFIQUE</p>

      <p class="clase_1">Todo Pago Realizado</p>

      </div>

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">SOPORTE</p>

      <p class="clase_1">Realice sus Consultas</p>

      </div>

      <div class="oferta3">

      <p class="clase_4">99.9%</p>

      <p class="clase_6">Tiempo de Actividad Garantizado</p>

      </div> 


    </div>

        <!-- FIN OFERTAS --> 

    <div style="clear:both"><script language="javascript">
function cerrar_chat(){ //cerrar chat
document.getElementById("consulta").style.visibility="hidden";	
document.getElementById("pointer").style.visibility="hidden";
document.getElementById("ventana").style.paddingTop="6px";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/minimizar.png" onclick="abrir_chat();" style="cursor:pointer;"  border="0"/>';	
}



function abrir_chat(){ //abrir chat
document.getElementById("consulta").style.visibility="visible";	
document.getElementById("pointer").style.visibility="visible";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />';
document.getElementById("ventana").style.paddingTop="1px";	
	
	
	} 

</script>



 

<div style="position:fixed; bottom:38px; right:5px; z-index:3000; height:62px;">
<!-- mibew button --><!-- / mibew button -->
<table width="231" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="231" height="51" align="center" valign="top"><a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;"><img src="http://compihost.net/soluciones/chat_compihost/images/boton-consulta.png"  name="consulta" id="consulta" border="0"/></a></td>
  </tr>
  <tr>
    <td height="19" align="center" valign="top">
    
    <table width="150" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="19" height="24" align="center" valign="top">
        <div id="ventana" style="height:14px;" align="center">
      <img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />
        </div>
        </td>
        <td width="131" height="19" align="left" valign="top"><div id="click">
        <a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;">
        <img src="http://compihost.net/soluciones/chat_compihost/images/haz-click.png" width="130" height="19" border="0"/></a></div></td>
      </tr>
    </table>

    
    
    </td>
  </tr>
</table>
<img src="http://compihost.net/soluciones/chat_compihost/images/pointer.png" width="42" height="54" border="0" style="position: absolute; left: 199px; top: 46px;" id="pointer"/></div>





  









</div>

  </div>

    <div class="raya"></div>

</div>

<!-- FIN CUERPO -->





<div id="contenedor_pie">

<div id="pie">
  <div id="logo_pie">
  <h1>COMPIHOST.NET, empresa peruana con mas de 6 años de experiencia y brindando el servicio de alojamiento web y registro de dominios.</h1>
  </div>
  <div id="slogan_pie">
  <ul>
    <li><a href="soporte.html" title="SOPORTE">SOPORTE</a></li>
    <li><a href="nuestra_tecnologia.html" title="NUESTRA TECNOLOGÍA">NUESTRA TECNOLOGÍA</a></li>
    <li><a href="preguntas_frecuentes.html" title="PREGUNTAS FRECUENTES">PREGUNTAS FRECUENTES</a></li>
    <li><a href="politicas_servicio.html" title="POLÍTICAS DEL SERVICIO">POLÍTICAS DEL SERVICIO</a></li>
    <li><a href="terminos_condiciones.html" title="TERMINOS Y CONDICIONES">TERMINOS Y CONDICIONES</a></li>
  </ul>
  </div>
  <div id="menu_pie">
  <p><strong>Teléfono: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email:</strong></p>
  <p>(511) 796 2663 - (511) 780 4649 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ventas@compihost.net</p>
  </div>
  <div style="clear:both;"></div>
</div>
</div>
<script type="text/JavaScript">
	$(window).resize(function(){
        	$('.wrapper').css({
	               position:'fixed',
        	       left: ($(window).width() - $('.wrapper').outerWidth())/2,
               		top: ($(window).height() - $('.wrapper').outerHeight())/2
	          });
	});
	// Ejecutamos la función
	$(window).resize();
	$(document).ready(function(){
		$('#sup4').click(function(){
			$('#capa').fadeIn();
			$('#express').fadeIn();
		})
		$('.cerrar,#capa').click(function(){
		$('#capa').fadeOut();
		$('.wrapper').fadeOut();
	})
})
</script>
<!-- Script del Slider -->
<link rel='stylesheet' id='style-css'  href='diapo/diapo.css' type='text/css' media='all'> 
<script type='text/javascript' src='diapo/scripts/jquery.min.js'></script>
<!--[if !IE]><!--><script type='text/javascript' src='diapo/scripts/jquery.mobile-1.0rc2.customized.min.js'></script><!--<![endif]-->
<script type='text/javascript' src='diapo/scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='diapo/scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='diapo/scripts/diapo.js'></script> 

<script>
$(function(){
	$('.pix_diapo').diapo();
});
</script>




</body>



</html>


 <!-- Begin Attracta Include 2013-06-02 15:47 -->
<script type='text/javascript'> 
function attracta_loadjs(url) {
   (function() {
       var s = document.createElement('script');
       s.type = 'text/javascript';
       s.async = true;
       s.src = url;
       var x = document.getElementsByTagName('script')[0];
       x.parentNode.insertBefore(s, x);
   })();
}
function attracta_shouldrun() {
   var v = ["/admin/","/adm/","/wp-admin/","/administrator/"];
   for (x in v) if(window.location.pathname.indexOf(v[x]) == 0) return false;
   return true;
}
function attracta_window_width() {
   if (document.body && document.body.offsetWidth) return document.body.offsetWidth;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) return document.documentElement.offsetWidth;
   if (window.innerWidth) return window.innerWidth;
   return 0;
}
function attracta_window_height() {
   if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetHeight ) return document.documentElement.offsetHeight;
   if (window.innerHeight) return window.innerHeight;
   return 0;
}
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17302325-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- End Attracta Include 2013-06-02 15:47 -->

