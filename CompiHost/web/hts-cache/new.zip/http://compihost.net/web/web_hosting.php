
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>COMPIHOST - Soluciones de Internet</title>

<link rel="stylesheet" type="text/css" href="css/estilos.css"/>

<link rel="icon" href="img/logocom.gif" type="image/gif" />

<!-- WRAPER INICIO -->

<link rel="stylesheet" href="css/sexylightbox.css" type="text/css" media="all" />

<script src="js/jquery.js"></script>

 

<script src="js/functions.js"></script>

<script src="js/web.js"></script>

<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<script type="text/javascript" src="js/sexylightbox.v2.3.jquery.js"></script>

<script type="text/javascript">

$(document).ready(

    function(){

           SexyLightbox.initialize({color:'00', 

	                                dir: 'sexyimages'

                                  });

              });

</script>

<script type="text/javascript">

	function meebo(valor){

			window.open('meebo.php','Consultas','width=230,height=520,resizable=NO,scrollbars=NO');

			reload();

	}

</script>



<!-- WRAPER FIN -->

</head>



<body>

<!-- Envolve Chat -->

<!--Documentar chat--------<script type="text/javascript">

var envoSn=117836;

var envProtoType = (("https:" == document.location.protocol) ? "http://" : "http://");

document.write(unescape("%3Cscript src='" + envProtoType + "d.envolve.com/env.nocache.js' type='text/javascript'%3E%3C/script%3E"));

</script>---------- cerrar chat---->



<div id="capa"></div>
<div id="express" class="wrapper">
	<div class="cerrar">Cerrar(X)</div>
	<iframe src="http://info361903.supersite.srsportal.com/domain.php" width="99%" height="650px" style="margin-bottom:10px;"></iframe>
</div>


<div id="contenedor_cabecera">

<div id="grande"></div>

  <div id="logo">

  <h1>Brindamos soluciones de internet a su medida, gracias a la experiencia que contamos siendo nuestros servicios creación y optimización de página web, mantenimiento, implementación de  hosting y dominio, sistema atención de clientes, entre otros.</h1>

  </div>

  <div id="slogan">

    <p>Soluciones de Internet</p></div>

  <div id="menu_sup">

  	<div style="width:440px; float:right">

        <div class="link_sup" align="right" style="width:40px"><img src="img/home.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px; width:48px;"><a href="index.html" title="INICIO">Inicio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/empresa.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="nosotros.html" title="EMPRESA">Empresa</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/portafolio_icon.png" width="37" height="47"/></div>
        
        


        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="portafolio.html" title="PORTAFOLIO">Portafolio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/contacto.png" width="37" height="47"/></div>
                
        

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="contactenos.html" title="CONTÁCTENOS">Contáctenos</a></div>

		<div style="clear:both"></div>        

	</div>

  </div>

  <div style="clear:both"></div>

    <div class="raya"></div>

</div>



<div id="banner">

<div id="contenedor_banner" style="position:relative; background-color:#FFF">

  <div id="menu2" align="center" style="width:164px; height:369px; padding-left:0px; position: static;">

  <ul>

  <li style="width:164px; margin-right:0px; background-color:#FFF;"><a class="som_men" style="background-image:url(img/menu_amarillo.png); background-repeat:no-repeat; background-color:#FFF;" id="sup1" href="promociones.html" title="PROMOCIONES">Promociones</a></li>

  <li><a class="som_men" id="sup2" href="hosting.html" title="HOSTING">Hosting</a></li>
  
  <li><a class="som_men" href="http://info361903.supersite.srsportal.com/domain.php?TB_iframe=true&amp;height=700&amp;width=800" rel="sexylightbox" title="DOMINIO">Dominio</a></li>

  <li><a class="som_men" id="sup3" href="soluciones_web.html" title="SOLUCIONES WEB">Soluciones Web</a></li>

  <li><a class="som_men" id="sup7" href="e_marketing.html" title="E - MARKETING">E - Marketing</a></li>

  <li><a class="som_men" id="sup6" href="soporte.html" title="SOPORTE">Soporte Remoto</a></li>

  <!--<li><a class="som_men" id="sup5" href="sistemas.html" title="SISTEMAS">Sistemas</a></li>   -->

    </ul>

</div>
<div style="background:url(img/tablet.jpg) no-repeat; width:821px; height:373px; position:absolute; left:182px; top:0px; ">

  <section style="overflow:visible;"> 

    	<div style="position: absolute; width:300px; margin:123px 0 0 -90px; padding:0 20px;top: -100px;left: 90px;"> 
                <div class="pix_diapo">
					<div data-thumb="diapo/images/thumbs/up-official-trailer-fake.jpg" title="Haz clic y entérate de nuestras promociones">
                        <iframe width="734" height="324" src="http://www.youtube.com/embed/c1Z9tTjHIMA?rel=0&modestbranding=1&autoplay=1" data-fake="diapo/images/slides/up-official-trailer-fake.jpg" frameborder="0" allowfullscreen ></iframe>
                        
                        <div class="elemHover caption fromLeft elemToHide" style="bottom: 350px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; left:0">
                            You can also display videos, but it requires a "fake image"... read the documentation please
                        </div>
                    </div>

                    <div data-thumb="diapo/images/thumbs/megamind1048.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b1.jpg"></a>
                       <!-- <div class="caption elemHover fromLeft">
                            This is a simple sliding image with caption. You can have more than one caption and decide the layout of the caption via css.
                        </div>-->
                    </div>
                    
<!--                    <div data-thumb="diapo/images/thumbs/megamind_07.jpg">
                        <a href="https://www.facebook.com/COMPIHOST/app_79458893817" target="_blank" title="Haz clic y participa gratis en nuestros Sorteos"><img src="diapo/images/slides/b2.jpg"></a>-->
<!--                        <div class="caption elemHover fromRight" style="bottom:65px; padding-bottom:5px; color:#ff0; text-transform:uppercase">
                            Here you can see two captions.
                        </div>
                        <div class="caption elemHover fromLeft" style="padding-top:5px;">
                            The first are loaded immediately before than the second one
                        </div>-->
<!--                    </div>-->
                    
<!--                    <div data-thumb="diapo/images/thumbs/wall-e.jpg" data-time="7000">
                        <img src="diapo/images/slides/wall-e.jpg">
                        <div class="elemHover caption fromLeft" style="bottom:70px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px;">
                            You can also get the same effect as the caption with:
                        </div>
                        <div class="elemHover button fromTop" data-easing="easeOutExpo" style="left:388px; bottom:78px;">
                            A button
                        </div>
                        <div class="elemHover button button2 fromBottom" data-easing="easeOutExpo" style="left:512px; bottom:78px;">
                            Or two buttons
                        </div>
                        <div class="elemHover fadeIn" style="left:600px; bottom:auto; top:0; padding-top:50px; color:#ff0; font-size:13px; line-height:20px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; background:url(diapo/images/demo/arrow_caption.png) no-repeat 230px 30px">
                            Or any other html element...<br>
                            and you can decide the transition time of any slide
                        </div>
                    </div>-->
                    
<!-- Video -->                    
                    
                                     
                    
                    <div data-thumb="diapo/images/thumbs/ratatouille2.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b3.jpg"></a>
                    </div>
                    
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 


</div>

<div style="clear:both"></div>

</div>

</div>
<!-- INICIO CUERPO -->

<div id="contenedor_cuerpo">

	<div class="raya"></div>

  <div id="cuerpo">

    <div id="cuerpo_i">

    

      <div class="caja_1">

      <h1 class="fondo1">SOLUCIONES WEB</h1>

      <p class="c1">

      Trabajamos cerca a nuestros clientes creando originales y dinámicos sitios web, aseguramos funcionalidad, claridad y un gran dinamismo, para que el usuario se sienta "atraído". <br />

      <br />

Creamos sitios web adecuados a las necesidades de su organización, desde páginas web sencillas hasta complejos sistemas informáticos con presencia en Internet. 

      </p>

      </div>

      

           <ul class="cablis_1" style="padding-top:0px;">

		<li class="lis_1">El registro de un dominio dura como mínimo 1 Año.</li>

		<li class="lis_1">Los precios incluyen impuesto de ley (IGV).</li> 

      </ul>

      

      

    <div id="otro">  

      <div class="caja_6">

      <h1 class="fondo6">WEB MYPE - 1</h1>

      <ul class="cablis_1">
        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web con diseño plantilla<br />

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web máximo 5 pantallas<br />

 ------------------------------------------------------------------<br />

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;100 mb de hosting y Dominio<br />

      <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;5 cuentas de correo corporativo<br />

      <img src="../mails/images/check.png" width="15" height="13" align="left" id="check"/>&nbsp;1 asistencia remota (30 minutos)<br />

       <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Contará con estadísticas<br />

------------------------------------------------------------------
        </ul>
      <center>
        <table width="360" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="195" height="121" align="center" valign="middle">
              <table width="182" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="182"><div style="background-image:url(../mails/images/laptor_2.png); width:185; height:100px; background-repeat:no-repeat; padding-top:5px;" align="center"><img src="../mails/images/mype1.jpg" width="132" height="80" /></div></td>
                  </tr>
                <tr>
                  <td align="center" valign="middle"><font face="Verdana, Geneva, sans-serif" style="font-size:13px;"><strong>7 días laborales</strong></font></td>
                  </tr>
                </table>
              </td>
            <td width="159" align="center" valign="middle"><div class="circulo_precio" align="center">  
              
              <font style="font-size:17px"> Único Pago</font><br/>
              
             <font style="font-size:22px"><strong> S/.700</strong></font>
              
              
              </span>
              
              <br/>
              
            <font style="font-size:12px">  Precio Incluye<br /> IGV</font>
              
              </span></div></td>
          </tr>
          </table><br />
      </center>

     

<div align="center">
        <table width="265" border="0">
        <tr>
          <td width="123" height="36"><a href="pyme_01.php?TB_iframe=true&amp;height=620&amp;width=850" rel="sexylightbox" class="l_1"><div class="btm_buton"> más información</div></a></td>
          <td width="11">&nbsp;l&nbsp;</td>
          <td width="117"><div class="link1"><a href="cotizar_codigo.php?codigo=MYPE-1&tipo_web=MYPE-1&dias_laborales=(7 dias laborales)&idcodigo=EMPRENDEDORTB_iframe=true&height=620&width=850" rel="sexylightbox" class="l_1"><div class="btm_buton"> ordenar pedido</div></a></div></td>
        </tr>
      </table>
      </div>
      


      </div>

      <div class="caja_6" style="margin-right:0px;">

      <h1 class="fondo6">WEB MYPE - 2</h1>

      <ul class="cablis_1">

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web con diseño plantilla<br />

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web máximo 5 pantallas<br />

------------------------------------------------------------------
<br />
<img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;100 mb de hosting y Dominio<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;5 cuentas de correo corporativo<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;1 asistencia remota (30 minutos)<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Contará con estadísticas<br />

------------------------------------------------------------------

      </ul>



      <div align="center">
        <table width="360" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="195" height="121" align="center" valign="middle">
              <table width="182" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="182"><div style="background-image:url(../mails/images/laptor_2.png); width:185; height:100px; background-repeat:no-repeat; padding-top:5px;" align="center">
                    <img src="../mails/images/MyPE-02.jpg" width="132" height="80" /></div></td>
                  </tr>
                <tr>
                  <td align="center" valign="middle"><font face="Verdana, Geneva, sans-serif" style="font-size:13px;"><strong>10 días laborales</strong></font></td>
                  </tr>
                </table>
              </td>
            <td width="159" align="center" valign="middle"><div class="circulo_precio" align="center">  
              
              <font style="font-size:17px"> Único Pago</font><br/>
              
             <font style="font-size:22px"><strong> S/.1000</strong></font>
              
              
              </span>
              
              <br/>
              
            <font style="font-size:12px">  Precio Incluye<br /> IGV</font>
              
              </span></div></td>
            </tr>
        </table>
        
        <br/>
        
        
        
      </div>
      <div align="center">
        <table width="265" border="0">
        <tr>
          <td width="123" height="36"><a href="pyme_02.php?TB_iframe=true&amp;height=620&amp;width=850" rel="sexylightbox" class="l_1">
          <div class="btm_buton">más información</div></a></td>
          <td width="11">&nbsp;l&nbsp;</td>
          <td width="117"><div class="link1"><a href="cotizar_codigo.php?codigo=MYPE-2&tipo_web=MYPE-2&dias_laborales=(10 dias laborales)&idcodigo=EMPRENDEDORTB_iframe=true&height=620&width=850" rel="sexylightbox" class="l_1"><div class="btm_buton"> ordenar pedido</div></a></div></td>
        </tr>
      </table>
    </div>
      </div>

      <div class="caja_6">

      <h1 class="fondo6">WEB STANDARD - 1</h1>

      <ul class="cablis_1">

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web con diseño plantilla<br />

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web máximo 8 pantallas<br />

------------------------------------------------------------------
<br />
<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;500 mb de hosting y Dominio
<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;10 cuentas de correo corporativo<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;1 asistencia remota (30 minutos)<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Contará con estadísticas<br />

------------------------------------------------------------------

      </ul>

      <div align="center">
        <table width="360" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="195" height="121" align="center" valign="middle">
              <table width="182" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="182"><div style="background-image:url(../mails/images/laptor_2.png); width:185; height:100px; background-repeat:no-repeat; padding-top:5px;" align="center"><img src="tipo_web/STANDARD-1_01.jpg" width="132" height="80" /></div></td>
                  </tr>
                <tr>
                  <td align="center" valign="middle"><font face="Verdana, Geneva, sans-serif" style="font-size:13px;"><strong>15 días laborales</strong></font></td>
                  </tr>
                </table>
              </td>
            <td width="159" align="center" valign="middle"><div class="circulo_precio" align="center">  
              
              <font style="font-size:17px"> Único Pago</font><br/>
              
             <font style="font-size:22px"><strong> S/.1300</strong></font>
              
              
              </span>
              
              <br/>
              
            <font style="font-size:12px">  Precio Incluye<br /> IGV</font>
              
              </span></div></td>
            </tr>
        </table><br />
      </div>
      <div align="center">
        <table width="265" border="0">
        <tr>
          <td width="123" height="36"><a href="pyme_03.php?TB_iframe=true&amp;height=620&amp;width=850" rel="sexylightbox" class="l_1">
          <div class="btm_buton">más información</div></a></td>
          <td width="11">&nbsp;l&nbsp;</td>
          <td width="117"><div class="link1"><a href="cotizar_codigo.php?codigo=STANDARD-1&tipo_web=STANDARD - 1&dias_laborales=(15 dias laborales)&idcodigo=EMPRENDEDORTB_iframe=true&height=620&width=850" rel="sexylightbox" class="l_1"><div class="btm_buton"> ordenar pedido</div></a></div></td>
        </tr>
      </table>
  </div>
      </div>

      <div class="caja_6" style="margin-right:0px;">

      <h1 class="fondo6">WEB STANDARD - 2</h1>

      <ul class="cablis_1">

        <img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;Página web con diseño plantilla<br />

        <img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;Página web máximo 10 pantallas<br />

       <img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;Contará con un Administrador de Contenidos<br />

------------------------------------------------------------------
<br />
<img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;1000 mb de hosting y Dominio<br />

<img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;20 cuentas de correo corporativo<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;1 asistencia remota (30 minutos)<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Contará con estadísticas<br />

------------------------------------------------------------------

      </ul>

      <div align="center">
        <table width="360" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="195" height="121" align="center" valign="middle">
              <table width="182" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="182"><div style="background-image:url(../mails/images/laptor_2.png); width:185; height:100px; background-repeat:no-repeat; padding-top:5px;" align="center"><img src="../mails/images/standar-2.jpg" width="132" height="80" /></div></td>
                  </tr>
                <tr>
                  <td align="center" valign="middle"><font face="Verdana, Geneva, sans-serif" style="font-size:13px;"><strong>22 días laborales</strong></font></td>
                  </tr>
                </table>
              </td>
            <td width="159" align="center" valign="middle"><div class="circulo_precio" align="center">  
              
              <font style="font-size:17px"> Único Pago</font><br/>
              
             <font style="font-size:22px"><strong> S/.2500</strong></font>
              
              
              </span>
              
              <br/>
              
            <font style="font-size:12px">  Precio Incluye<br /> IGV</font>
              
              </span></div></td>
            </tr>
        </table><br />
        
        
      </div>
      <div align="center">
        <table width="265" border="0">
        <tr>
          <td width="123" height="36"><a href="pyme_04.php?TB_iframe=true&amp;height=620&amp;width=850" rel="sexylightbox" class="l_1">
          <div class="btm_buton">más información</div></a></td>
          <td width="11">&nbsp;l&nbsp;</td>
          <td width="117"><div class="link1"><a href="cotizar_codigo.php?codigo=STANDARD-2&tipo_web=STANDARD - 2&dias_laborales=(22 dias laborales)&idcodigo=EMPRENDEDORTB_iframe=true&height=620&width=850" rel="sexylightbox" class="l_1"><div class="btm_buton"> ordenar pedido</div></a></div></td>
        </tr>
      </table>
    </div>

      </div>

      <div class="caja_6">

      <h1 class="fondo6">WEB PREMIER - 1</h1>

      <ul class="cablis_1">

        <img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;Página web con diseño personalizado<br />

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web máximo 10 pantallas<br />

       <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Contará con un Administrador de Contenidos<br />

        ------------------------------------------------------------------
<br />
  <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;2500 mb de hosting y Dominio<br />

  <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;25 cuentas de correo corporativo<br />

  <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;1 asistencia remota (30 minutos)<br />

 <img src="../mails/images/check.png" width="15" height="13" align="left"  id="check"/>&nbsp;Contará con estadísticas<br />

        ------------------------------------------------------------------

      </ul>


      <div align="center">
        <table width="360" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="198" height="121" align="center" valign="middle">
              <table width="182" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="182"><div style="background-image:url(../mails/images/laptor_2.png); width:185; height:100px; background-repeat:no-repeat; padding-top:5px;" align="center"><img src="../mails/images/premier-1.jpg" width="132" height="80" border="0" /></div></td>
                  </tr>
                <tr>
                  <td align="center" valign="middle"><font face="Verdana, Geneva, sans-serif" style="font-size:13px;"><strong>30 días laborales</strong></font></td>
                  </tr>
                </table>
              </td>
            <td width="158" align="center" valign="middle"><div class="circulo_precio" align="center">  
              
              <font style="font-size:17px"> Único Pago</font><br/>
              
             <font style="font-size:22px"><strong> S/.3850</strong></font>
              
              
              </span>
              
              <br/>
              
            <font style="font-size:12px">  Precio Incluye<br /> IGV</font>
              
              </span></div></td>
            </tr>
        </table><br />
      </div>
      <div align="center">
        <table width="265" border="0">
        <tr>
          <td width="123" height="36"><a href="nwp_05.php?TB_iframe=true&amp;height=620&amp;width=850" rel="sexylightbox" class="l_1">
          <div class="btm_buton">más información</div></a></td>
          <td width="11">&nbsp;l&nbsp;</td>
          <td width="117"><div class="link1"><a href="cotizar_codigo.php?codigo=PREMIER-1&tipo_web=PREMIER - 1&dias_laborales=(30 dias laborales)&idcodigo=EMPRENDEDORTB_iframe=true&height=620&width=850" rel="sexylightbox" class="l_1"><div class="btm_buton"> ordenar pedido</div></a></div></td>
        </tr>
      </table>
    </div>

      </div>

      <div class="caja_6" style="margin-right:0px;">

      <h1 class="fondo6">WEB PREMIER - 2</h1>

      <ul class="cablis_1">

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web con diseño personalizado<br />

       <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Página web máximo 10 pantallas<br />

        <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Contará con un Administrador de Contenidos<br />

       <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Se adapta PC, Laptop, Tablet y móvil<br />

        ------------------------------------------------------------------<br />

  <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;5000 mb de hosting y Dominio<br />

 <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;50 cuentas de correo corporativo<br />

  <img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;1 asistencia remota (30 minutos)<br />

<img src="../mails/images/check.png" width="15" height="13" align="left" id="check" />&nbsp;Contará con estadísticas<br />

        ------------------------------------------------------------------

      </ul>

   
      <div align="center">
        <table width="360" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="195" height="121" align="center" valign="middle">
              <table width="182" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="182"><div style="background-image:url(../mails/images/laptor_2.png); width:185; height:100px; background-repeat:no-repeat; padding-top:5px;" align="center"><img src="../mails/images/premier-2.png" width="132" height="80" /></div></td>
                  </tr>
                <tr>
                  <td align="center" valign="middle"><font face="Verdana, Geneva, sans-serif" style="font-size:13px;"><strong>40 días laborales</strong></font></td>
                  </tr>
                </table>
              </td>
            <td width="159" align="center" valign="middle"><div class="circulo_precio" align="center">  
              
              <font style="font-size:17px"> Único Pago</font><br/>
              
             <font style="font-size:22px"><strong> S/.5200</strong></font>
              
              
              </span>
              
              <br/>
              
            <font style="font-size:12px">  Precio Incluye<br /> IGV</font>
              
              </span></div></td>
            </tr>
        </table><br />
        
      </div>
      <div align="center">
        <table width="265" border="0">
        <tr>
          <td width="123" height="36"><a href="nwp_06.php?TB_iframe=true&amp;height=620&amp;width=850" rel="sexylightbox" class="l_1">
          <div class="btm_buton">más información</div></a></td>
          <td width="11">&nbsp;l&nbsp;</td>
          <td width="117"><div class="link1"><a href="cotizar_codigo.php?codigo=PREMIER-2&tipo_web=PREMIER - 2&dias_laborales=(40 dias laborales)&idcodigo=EMPRENDEDORTB_iframe=true&height=620&width=850" rel="sexylightbox" class="l_1"><div class="btm_buton"> ordenar pedido</div></a></div></td>
        </tr>
      </table>
</div>

      </div>

      <div style="clear:both"></div>

      

      

      

    </div>  

      

    <!--  <div class="caja_1">

      <h1 class="fondo1" style="text-align:center">GRATIS - LOS PAQUETES TIENEN REGALO </h1>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">Capacitación de 2 horas del uso del Gestos de contenidos.</li>

		<li class="lis_1">Registro en buscadores como  google, Bing y Yahoo.</li>

		<li class="lis_1">2 meses gratis registro en  AmarillasLatinas.net.</li>

      </ul>

      </div>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">6 meses gratis Sistema de atención a clientes.</li>

		<li class="lis_1">Disco duro Virtual de 1 GB Gratis.</li>

		<li class="lis_1">Llamada gratis por 100 minutos a todo destino .</li>

      </ul>

      </div>

      <div style="clear:both"></div>

      </div>-->

     

      

      

      

      <div class="caja_1">

      <h1 class="fondo1" style="text-align:center">ENTREGA DE MATERIALES – POR PARTE DEL CLIENTE</h1>

      <p class="c1">El cliente debe entregar los siguientes materiales:</p>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">Información de la empresa.</li>

		<li class="lis_1">Información de sus servicios y/ o productos.</li>

		<li class="lis_1">Si el material es en otro idioma el cliente debe de proporcionarlo.</li>

      </ul>

      </div>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">Material fotográfico de alta definición.</li>

		<li class="lis_1">Logo en alta resolución.</li>

      </ul>

      </div>

      <div style="clear:both"></div>

      <p class="c1">La calidad en los contenidos (redacción y ortografía)  e imágenes (tamaño y resolución) a trabajar, están bajo responsabilidad del cliente.<br /><br />

En caso de haber retrasos en la entrega de materiales por el cliente,  <strong>COMPIHOST</strong> tendrá libertad de modificar el tiempo de entrega acordado. </p>

      </div>

      

     <div class="caja_500">

     Capture Clientes - Consiga Contactos - Domine su Mercado

     </div> 

   

   

   

      <div class="caja_1">

      <h1 class="fondo1" style="text-align:center">TODOS LOS PAQUETES DE NEGOCIO INCLUYEN</h1>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">Diseño de Sitio Web  a escoger. </li>

		<li class="lis_1">Publicación de su sitio para colocarlo en la web.</li>

		<li class="lis_1">Creación de cuenta de email (hasta 10 cuentas).</li>

		<li class="lis_1">Un mapa de ubicación.</li>

		<li class="lis_1">Entrenamiento y Consultas.</li>        

      </ul>

      </div>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">Una cabecera con el logo y slogan de su empresa.</li>

		<li class="lis_1">Una descripción de su servicio o productos.</li>

		<li class="lis_1">Un contador de visita.</li>

		<li class="lis_1">Registro en buscadores como  google, Bing y Yahoo.</li>

		<li class="lis_1">Un formulario de contáctenos para que le escriban a su correo.</li>  

      </ul>

      </div>

      <div style="clear:both"></div>

      </div>   

   

   

   

    

    

    

    <div class="col_100">

<div class="caja_100" style="height:150px;">

  <p class="caja_101">Precio Justo</p>

  <p class="caja_102">Por que pagar de más... Consideramos que el negocio de nuestros clientes es nuestro principal activo, por eso cuidamos la rentabilidad del cliente, para que su negocio crezca con el mínimo costo y la más alta calidad de servicios.</p>

</div>

<div class="caja_100" style="height:100px;">

  <p class="caja_101">Suscripción</p>

  <p class="caja_102">Se le suscribirá en los principales buscadores como google, yahoo, bing, terra.</p>

</div>

<div class="caja_100" style="height:100px;">

  <p class="caja_101">Atención en línea</p>

  <p class="caja_102">La atención es a través de nuestras distintas formas de comunicación (teléfono, nextel, correo,  msn y skype).</p>

</div>

</div>

    <div class="col_100">

    <div class="caja_100" style="height:150px;">

    <p class="caja_101">Soporte Profesional</p>

    <p class="caja_102">Nuestro Equipo de profesionales está preparado para ayudarte en todo momento, cualquiera sea su nivel de conocimiento, principiante, avanzado o una gran empresa. Los 365 días cuidando tu negocio.</p>

    </div>

    </div>

        <div class="col_100" style="margin-right:0px;">

    <div class="caja_100" style="height:150px;">

    <p class="caja_101">Tranquilidad Garantizada</p>

    <p class="caja_102">Su tranquilidad, lo mas importante... Usted concéntrese en su negocio y nosotros nos hacemos cargo de la tecnología.</p>

    </div>

    <div class="caja_100" style="height:100px;">

    <p class="caja_101">Análisis</p>

    <p class="caja_102">Propuesta web resultado de un completo análisis. </p>

    </div>

    <div class="caja_100" style="height:100px;">

    <p class="caja_101">Publicación</p>

    <p class="caja_102">Publicamos su página web en su servicio de alojamiento web o hosting.</p>

    </div>

    </div>    

    <div style="clear:both"></div>

    

    

    

    

       <div class="caja_200">

      <h1 class="fondo200">OPCIONES ADICIONALES AVANZADAS</h1>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">Servicio de administrador de su página web (WEBMASTER).</li>

		<li class="lis_1">Páginas Adicionales.</li>

		<li class="lis_1">Rediseño y Mejora de Sitio Existente.</li>

		<li class="lis_1">Creación y Configuración de Blog.</li>

		<li class="lis_1">Registro y Configuración de Nombre de Dominio.</li>

        

		<li class="lis_1">Configuración de Alojamiento Web.</li> 

		<li class="lis_1">Manejo de Contenido.</li>

		<li class="lis_1">Desarrollo de Base de Datos Personalizada.</li>

		<li class="lis_1">Newsletters y Email Marketing vía EmailBrain.com.</li>

		<li class="lis_1">Diseño de Logotipo.</li> 

        

        <li class="lis_1">Foros.</li>

		<li class="lis_1">Galería Fotográfica.</li>

		<li class="lis_1">Administración y Autenticación de Usuarios.</li>      

      </ul>

      </div>

      <div style="float:left; width:384px; margin-left:10px;">

      <ul class="cablis_1">

		<li class="lis_1">Diseño y Programación Flash.</li>

		<li class="lis_1">Búsqueda Web Avanzada.</li>

		<li class="lis_1">Administración de Suscripción de Miembros.</li>

		<li class="lis_1">Páginas Protegidas por Contraseña.</li>

		<li class="lis_1">Calendario.</li>

        

		<li class="lis_1">Integración con Medios y Redes Sociales.</li> 

		<li class="lis_1">Formularios Personalizados.</li>

		<li class="lis_1">Alistamiento en Negocios Locales.</li>

		<li class="lis_1">Preguntas Frecuentes.</li>

		<li class="lis_1">Mapeo Integrado.</li> 

        

        <li class="lis_1">Configuración y Autenticación Segura de Certificados SSL.</li>

		<li class="lis_1">Comercio Electrónico – Lance su tienda en línea.</li>

		<li class="lis_1">Entrenamiento del uso del administrador de contenidos.</li> 

 

      </ul>

      </div>

          <div style="clear:both"></div>

      </div> 

      

    </div>

    <!-- INICIO OFERTAS -->

<div id="cuerpo_d" align="center">

	

<!--      <div class="oferta2 mouse" onclick="location.href='dominio.php';">

      <p class="clase_2" style="padding:0px;">S/. 52<br /> 

      <p class="clase_3">por año</p>

      <p class="clase_1">Dominio</p>

      </div> -->

      <div class="oferta3 mouse" onclick="SexyLightbox.show('','cotizar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_4">COTIZAR</p>

      <p class="clase_6">la atención es inmediata</p>

      </div>  

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">NOTIFIQUE</p>

      <p class="clase_1">Todo Pago Realizado</p>

      </div>

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">SOPORTE</p>

      <p class="clase_1">Realice sus Consultas</p>

      </div>

      <div class="oferta3">

      <p class="clase_4">99.9%</p>

      <p class="clase_6">Tiempo de Actividad Garantizado</p>

      </div> 


</div>

    <!-- FIN OFERTAS --> 

    <div style="clear:both"></div>

  </div>

    <div class="raya"></div>
<script language="javascript">
function cerrar_chat(){ //cerrar chat
document.getElementById("consulta").style.visibility="hidden";	
document.getElementById("pointer").style.visibility="hidden";
document.getElementById("ventana").style.paddingTop="6px";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/minimizar.png" onclick="abrir_chat();" style="cursor:pointer;"  border="0"/>';	
}



function abrir_chat(){ //abrir chat
document.getElementById("consulta").style.visibility="visible";	
document.getElementById("pointer").style.visibility="visible";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />';
document.getElementById("ventana").style.paddingTop="1px";	
	
	
	} 

</script>



 

<div style="position:fixed; bottom:38px; right:5px; z-index:3000; height:62px;">
<!-- mibew button --><!-- / mibew button -->
<table width="231" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="231" height="51" align="center" valign="top"><a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;"><img src="http://compihost.net/soluciones/chat_compihost/images/boton-consulta.png"  name="consulta" id="consulta" border="0"/></a></td>
  </tr>
  <tr>
    <td height="19" align="center" valign="top">
    
    <table width="150" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="19" height="24" align="center" valign="top">
        <div id="ventana" style="height:14px;" align="center">
      <img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />
        </div>
        </td>
        <td width="131" height="19" align="left" valign="top"><div id="click">
        <a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;">
        <img src="http://compihost.net/soluciones/chat_compihost/images/haz-click.png" width="130" height="19" border="0"/></a></div></td>
      </tr>
    </table>

    
    
    </td>
  </tr>
</table>
<img src="http://compihost.net/soluciones/chat_compihost/images/pointer.png" width="42" height="54" border="0" style="position: absolute; left: 199px; top: 46px;" id="pointer"/></div>





  









</div>

<!-- FIN CUERPO -->





<div id="contenedor_pie">



<div id="pie">

  <div id="logo_pie">

  <h1>COMPIHOST.NET, empresa peruana con mas de 6 años de experiencia y brindando el servicio de alojamiento web y registro de dominios.</h1>

  </div>

  <div id="slogan_pie">

  <ul>

    <li><a href="soporte.php" title="SOPORTE">SOPORTE</a></li>

    <li><a href="nuestra_tecnologia.php" title="NUESTRA TECNOLOGÍA">NUESTRA TECNOLOGÍA</a></li>

    <li><a href="preguntas_frecuentes.php" title="PREGUNTAS FRECUENTES">PREGUNTAS FRECUENTES</a></li>

    <li><a href="politicas_servicio.php" title="POLÍTICAS DEL SERVICIO">POLÍTICAS DEL SERVICIO</a></li>

    <li><a href="terminos_condiciones.php" title="TERMINOS Y CONDICIONES">TERMINOS Y CONDICIONES</a></li>

  </ul>

  </div>

  <div id="menu_pie">

  <p><strong>Teléfono: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email:</strong></p>

  <p>(511) 796 2663 - (511) 780 4649 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ventas@compihost.net</p>

  </div>

  <div style="clear:both"></div>

</div>

</div>

<script type="text/JavaScript">
	$(window).resize(function(){
        	$('.wrapper').css({
	               position:'fixed',
        	       left: ($(window).width() - $('.wrapper').outerWidth())/2,
               		top: ($(window).height() - $('.wrapper').outerHeight())/2
	          });
	});
	// Ejecutamos la función
	$(window).resize();
	$(document).ready(function(){
		$('#sup4').click(function(){
			$('#capa').fadeIn();
			$('#express').fadeIn();
		})
		$('.cerrar,#capa').click(function(){
		$('#capa').fadeOut();
		$('.wrapper').fadeOut();
	})
})
</script>
<!-- Script del Slider -->
<link rel='stylesheet' id='style-css'  href='diapo/diapo.css' type='text/css' media='all'> 
<script type='text/javascript' src='diapo/scripts/jquery.min.js'></script>
<!--[if !IE]><!--><script type='text/javascript' src='diapo/scripts/jquery.mobile-1.0rc2.customized.min.js'></script><!--<![endif]-->
<script type='text/javascript' src='diapo/scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='diapo/scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='diapo/scripts/diapo.js'></script> 

<script>
$(function(){
	$('.pix_diapo').diapo();
});
</script>




</body>



</html>


 <!-- Begin Attracta Include 2013-06-02 15:47 -->
<script type='text/javascript'> 
function attracta_loadjs(url) {
   (function() {
       var s = document.createElement('script');
       s.type = 'text/javascript';
       s.async = true;
       s.src = url;
       var x = document.getElementsByTagName('script')[0];
       x.parentNode.insertBefore(s, x);
   })();
}
function attracta_shouldrun() {
   var v = ["/admin/","/adm/","/wp-admin/","/administrator/"];
   for (x in v) if(window.location.pathname.indexOf(v[x]) == 0) return false;
   return true;
}
function attracta_window_width() {
   if (document.body && document.body.offsetWidth) return document.body.offsetWidth;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) return document.documentElement.offsetWidth;
   if (window.innerWidth) return window.innerWidth;
   return 0;
}
function attracta_window_height() {
   if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetHeight ) return document.documentElement.offsetHeight;
   if (window.innerHeight) return window.innerHeight;
   return 0;
}
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17302325-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- End Attracta Include 2013-06-02 15:47 -->

