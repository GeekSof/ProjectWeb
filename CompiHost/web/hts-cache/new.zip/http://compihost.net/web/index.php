
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta name="google-site-verification" content="tuzimM9pHI27G4rsY_pFOUJscetosvWB7FxSZuVxioA" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>COMPIHOST - Soluciones en Internet - (511) 7804649 - (511) 4962663</title>

<link rel="stylesheet" type="text/css" href="css/estilos.css"/>

<link rel="icon" href="img/logocom.gif" type="image/gif">

<!-- WRAPER INICIO -->

<link rel="stylesheet" type="text/css" href="sexylightbox.css"/>

<link rel="stylesheet" href="css/sexylightbox.css" type="text/css" media="all" />

<script src="js/jquery.js"></script>

<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<script type="text/javascript" src="js/sexylightbox.v2.3.jquery.js"></script>

<script type="text/javascript">

$(document).ready(

    function(){

           SexyLightbox.initialize({color:'00', dir: 'sexyimages'});

	})

</script>

<script type="text/javascript">

	function meebo(valor){

			window.open('meebo.php','Consultas','width=230,height=520,resizable=NO,scrollbars=NO');

			reload();

	}

</script>

<!-- WRAPER FIN -->



<style type="text/css">

.dscto {

	color: #C00;

	font-size: 22px;

}

#contenedor_cuerpo #cuerpo .index_oferta.mouse .index_oferta_titulo {

	font-weight: bold;

	font-size: 28px;

}

</style>

</head>



<body>

<!-- Envolve Chat -->

<!--Documentar chat--------<script type="text/javascript">

var envoSn=117836;

var envProtoType = (("https:" == document.location.protocol) ? "http://" : "http://");

document.write(unescape("%3Cscript src='" + envProtoType + "d.envolve.com/env.nocache.js' type='text/javascript'%3E%3C/script%3E"));

</script>---------- cerrar chat---->



<div id="capa"></div>
<div id="express" class="wrapper">
	<div class="cerrar">Cerrar(X)</div>
	<iframe src="http://info361903.supersite.srsportal.com/domain.php" width="99%" height="650px" style="margin-bottom:10px;"></iframe>
</div>


<div id="contenedor_cabecera">

<div id="grande"></div>

  <div id="logo">

  <h1>Brindamos soluciones de internet a su medida, gracias a la experiencia que contamos siendo nuestros servicios creación y optimización de página web, mantenimiento, implementación de  hosting y dominio, sistema atención de clientes, entre otros.</h1>

  </div>

  <div id="slogan">

    <p>Soluciones de Internet</p></div>

  <div id="menu_sup">

  	<div style="width:440px; float:right">

        <div class="link_sup" align="right" style="width:40px"><img src="img/home.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px; width:48px;"><a href="index.html" title="INICIO">Inicio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/empresa.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="nosotros.html" title="EMPRESA">Empresa</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/portafolio_icon.png" width="37" height="47"/></div>
        
        


        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="portafolio.html" title="PORTAFOLIO">Portafolio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/contacto.png" width="37" height="47"/></div>
                
        

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="contactenos.html" title="CONTÁCTENOS">Contáctenos</a></div>

		<div style="clear:both"></div>        

	</div>

  </div>

  <div style="clear:both"></div>

    <div class="raya"></div>

</div>



<div id="banner">

<div id="contenedor_banner" style="position:relative; background-color:#FFF">

  <div id="menu2" align="center" style="width:164px; height:369px; padding-left:0px; position: static;">

  <ul>

  <li style="width:164px; margin-right:0px; background-color:#FFF;"><a class="som_men" style="background-image:url(img/menu_amarillo.png); background-repeat:no-repeat; background-color:#FFF;" id="sup1" href="promociones.html" title="PROMOCIONES">Promociones</a></li>

  <li><a class="som_men" id="sup2" href="hosting.html" title="HOSTING">Hosting</a></li>
  
  <li><a class="som_men" href="http://info361903.supersite.srsportal.com/domain.php?TB_iframe=true&amp;height=700&amp;width=800" rel="sexylightbox" title="DOMINIO">Dominio</a></li>

  <li><a class="som_men" id="sup3" href="soluciones_web.html" title="SOLUCIONES WEB">Soluciones Web</a></li>

  <li><a class="som_men" id="sup7" href="e_marketing.html" title="E - MARKETING">E - Marketing</a></li>

  <li><a class="som_men" id="sup6" href="soporte.html" title="SOPORTE">Soporte Remoto</a></li>

  <!--<li><a class="som_men" id="sup5" href="sistemas.html" title="SISTEMAS">Sistemas</a></li>   -->

    </ul>

</div>
<div style="background:url(img/tablet.jpg) no-repeat; width:821px; height:373px; position:absolute; left:182px; top:0px; ">

  <section style="overflow:visible;"> 

    	<div style="position: absolute; width:300px; margin:123px 0 0 -90px; padding:0 20px;top: -100px;left: 90px;"> 
                <div class="pix_diapo">
					<div data-thumb="diapo/images/thumbs/up-official-trailer-fake.jpg" title="Haz clic y entérate de nuestras promociones">
                        <iframe width="734" height="324" src="http://www.youtube.com/embed/c1Z9tTjHIMA?rel=0&modestbranding=1&autoplay=1" data-fake="diapo/images/slides/up-official-trailer-fake.jpg" frameborder="0" allowfullscreen ></iframe>
                        
                        <div class="elemHover caption fromLeft elemToHide" style="bottom: 350px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; left:0">
                            You can also display videos, but it requires a "fake image"... read the documentation please
                        </div>
                    </div>

                    <div data-thumb="diapo/images/thumbs/megamind1048.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b1.jpg"></a>
                       <!-- <div class="caption elemHover fromLeft">
                            This is a simple sliding image with caption. You can have more than one caption and decide the layout of the caption via css.
                        </div>-->
                    </div>
                    
<!--                    <div data-thumb="diapo/images/thumbs/megamind_07.jpg">
                        <a href="https://www.facebook.com/COMPIHOST/app_79458893817" target="_blank" title="Haz clic y participa gratis en nuestros Sorteos"><img src="diapo/images/slides/b2.jpg"></a>-->
<!--                        <div class="caption elemHover fromRight" style="bottom:65px; padding-bottom:5px; color:#ff0; text-transform:uppercase">
                            Here you can see two captions.
                        </div>
                        <div class="caption elemHover fromLeft" style="padding-top:5px;">
                            The first are loaded immediately before than the second one
                        </div>-->
<!--                    </div>-->
                    
<!--                    <div data-thumb="diapo/images/thumbs/wall-e.jpg" data-time="7000">
                        <img src="diapo/images/slides/wall-e.jpg">
                        <div class="elemHover caption fromLeft" style="bottom:70px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px;">
                            You can also get the same effect as the caption with:
                        </div>
                        <div class="elemHover button fromTop" data-easing="easeOutExpo" style="left:388px; bottom:78px;">
                            A button
                        </div>
                        <div class="elemHover button button2 fromBottom" data-easing="easeOutExpo" style="left:512px; bottom:78px;">
                            Or two buttons
                        </div>
                        <div class="elemHover fadeIn" style="left:600px; bottom:auto; top:0; padding-top:50px; color:#ff0; font-size:13px; line-height:20px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; background:url(diapo/images/demo/arrow_caption.png) no-repeat 230px 30px">
                            Or any other html element...<br>
                            and you can decide the transition time of any slide
                        </div>
                    </div>-->
                    
<!-- Video -->                    
                    
                                     
                    
                    <div data-thumb="diapo/images/thumbs/ratatouille2.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b3.jpg"></a>
                    </div>
                    
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 


</div>

<div style="clear:both"></div>

</div>

</div>
<!-- INICIO CUERPO -->

<div id="contenedor_cuerpo" style="position:relative;">

  <div class="raya"></div>

<!-- INICIO CUERPO -->

  <div id="cuerpo">





     <!-- <div class="index_caja">

      <h1 class="index_cabecera">BIENVENIDOS</h1>

      <p class="c1">

 

      </p>

      

      <form  method="post" action="dominio.php">   

      <p style="text-align:center">

      

     <input type="hidden" value='genericos'  name="tipodominio" id="tipodominio"   />

      

      <input name="dominio" id="dominio" type="text" style="width:400px;" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <select name="tld" id="tld"  style="width:130px;"  class="myselect"  onchange="recorrer(this.value)" >

      

   			<OPTION value="com"   class="myoption" >.com</OPTION>

			<OPTION value="net"  class="myoption">.net</OPTION>

			<OPTION value="org"  class="myoption">.org</OPTION>

            <OPTION value="biz" class="myoption" >.biz</OPTION>

			<OPTION value="info" class="myoption">.info</OPTION>

			<OPTION value="us"  class="myoption">.us</OPTION>

            <OPTION value="ws"  class="myoption">.ws</OPTION>

            <OPTION value="eu"  class="myoption">.eu</OPTION>

            <OPTION value="mobi"  class="myoption">.mobi</OPTION>

            <OPTION value="co"  class="myoption">.co</OPTION>

			<OPTION value="me">.tv</OPTION>

			<OPTION value="eu" class="myoption">.es</OPTION>   

      

      </select></p>

       <input class="mybutton" value="Buscar" type="submit"  style="  width:150px;  margin-top:20px; margin-bottom:20px; margin-left:450px; "> 

       

       

   </form>    

 </div>-->





    <!-- INICIO OFERTAS -->

    

    <div class="index_oferta mouse" onclick="location.href='promociones.php';">

    <p class="index_oferta_titulo">S/. 700 <br />

      <!--<span class="dolar">US$

		0
      </span><br />-->

<!--      <span class="dscto">50% dscto.</span>-->

<!--    <div align="right"><span class="index_parrafo_3">antes S/.<s>1200</s></span>

      </p>

    </div>-->

    <p class="index_oferta_subtitulo"> Web Mype - 1</p><br />

    <p class="index_imagen"><img src="img/l1.jpg" width="150" height="108"  alt="PAGINA WEB" title="DESARROLLO WEB EMPRENDEDOR" /></p>

    <p class="index_parrafo_1">&nbsp;</p>

    </div>

    

    <div class="index_oferta mouse" style="margin-right:68px;" onclick="location.href='web_hosting.php';">

      <p class="index_oferta_titulo">S/.

        1000
        <br /> 

<!--        <span class="dolar">US$

0
        </span> <br />

        <span class="dscto">50% dscto.</span></p>

      <div align="right"><span class="index_parrafo_3">antes S/.<s>2000</s></span>

        </p>

      </div>-->

      <p class="index_oferta_subtitulo"> Web Mype - 2</p><br/>

      <p class="index_imagen"><img src="img/l2.jpg" width="150" height="108" alt="PAGINA WEB" title="DESARROLLO WEB EMPRESARIAL" /></p>

      <br/>

    <p class="index_parrafo_1">&nbsp;</p>

    </div>



    <div class="index_oferta mouse" onclick="location.href='web_hosting.php';">

      <p class="index_oferta_titulo">S/.

        1300
        <br />

 <!--       <span class="dolar">US$

0
        </span><br />

        <span class="dscto">50% dscto.</span></p>

      <div align="right"><span class="index_parrafo_3">antes S/.<s>600</s></span>

        </p>

      </div>-->

      <p class="index_oferta_subtitulo"> Web Standard - 1</p><br/>

      <p class="index_imagen" style="padding-top:0px;"><img src="img/l3.jpg" width="150" height="108" alt="IMPACTO DE MAIL" title="DESARROLLO WEB MOVIL" /></p>

      <p class="index_imagen" style="padding-top:0px;">&nbsp;</p>

      <p class="index_oferta_titulo" style="padding-bottom:0px;">&nbsp;</p>

</div>

    

  <div class="index_oferta mouse" style="margin-right:0px;" onclick="location.href='web_hosting.php';">

    <p class="index_oferta_titulo" style="padding-bottom:0px; font-size: 28px;">S/. 2500
      <br />

    <p class="index_oferta_subtitulo">Web Standard - 2</p><br/>

    <p class="index_imagen" style="padding-top:0px;"><span class="index_imagen" style="padding-top:0px;"><img src="img/l4.jpg" width="150" height="108" alt="IMPACTO DE MAIL" title="FACEBOOK" /></span><span class="index_imagen" style="padding-top:0px;"><span class="index_parrafo_1"><br />

      </span></span></p>

    </div>

 

<!--    <div class="index_oferta mouse" onclick="location.href='hosting.php';">

      <p class="index_oferta_titulo" style="padding-bottom:0px;">S/. <span class="index_oferta_titulo" style="padding-bottom:0px;">

        52
      </span></p>

      <p class="index_parrafo_3">por a�o</p>

      <p class="index_oferta_subtitulo">Correos Corporativos</p>

      <p class="index_oferta_subtitulo">&nbsp;</p>

      <p class="index_imagen" style="padding-top:0px;"><img src="img/anuncio3.jpg" width="90" height="80" alt="CORREOS CORPORATIVOS" title="CORREOS CORPORATIVOS" /></p>

<!--      <p class="index_imagen" style="padding-top:0px;">&nbsp;</p>

      <p class="index_parrafo_1">Varios Pack</p>

      <p class="index_parrafo_2">Especialistas en Alojamiento</p>

    </div>-->

    

    <div class="index_oferta mouse" onclick="location.href='soporte_pc.php';">

    <p class="index_oferta_titulo" style="padding-bottom:0px;">Soporte Remoto</p>

<!--<p class="index_parrafo_3"> por 6 meses</p>-->

<!--    <p class="index_oferta_subtitulo" style="line-height:21px;">Sistema de Atenci�n al Cliente</p>-->

<!--    <p class="index_oferta_subtitulo" style="line-height:21px;">&nbsp;</p>-->

    <p class="index_imagen" style="padding-top:0px;"><img src="img/soporte2.jpg" width="181" height="103" alt="SOPORTE T�CNICO DE COMPUTADORAS" title="SOPORTE T�CNICO DE COMPUTADORAS" /></p>

<!--    <p class="index_imagen" style="padding-top:0px;">&nbsp;</p>-->

<p class="index_parrafo_2">Servicio Remoto ONLINE</p>

    </div>

    

    <div class="index_oferta mouse" onclick="location.href='#';" id="sup4">

    <p class="index_oferta_titulo" style="padding-bottom:0px;">S/. 52<br />

<!--      <span class="dolar">US$ 20</span></p>-->

    <p class="index_parrafo_3">por a&ntilde;o</p>

    <p class="index_oferta_subtitulo">Dominio</p>

    <p class="index_imagen" style="padding-top:0px;">
    <a href="http://info361903.supersite.srsportal.com/domain.php?TB_iframe=true&amp;height=700&amp;width=800" rel="sexylightbox">
    <img src="img/anuncio7.jpg" width="159" height="112" alt="DOMINIO" title="DOMINIO" /></a></p>

    </div>



    <div class="index_oferta mouse" onclick="location.href='soluciones_web.php';">

      <p class="index_oferta_titulo">COTIZAR</p>
      <p class="index_imagen"><img src="img/anuncio8.jpg" width="110" height="110" alt="COTIZAR" title="COTIZAR" /></p>
      <p class="index_parrafo_1">Construimos al detalle</p>
      <p class="index_parrafo_2">tu pagina web</p>
      <p class="index_oferta_titulo" style="padding-bottom:0px;">
    </div>
    <div class="index_oferta" style="margin-right:0px;">
      <p class="index_oferta_titulo" style="padding-bottom:0px;">99.9%</p>
      <br />
      <p class="index_parrafo_1">Tiempo de Actividad Garantizado</p>
      <p class="index_parrafo_2" style="text-align:justify; padding:10px 10px;">Una correcta administraci&oacute;n, distribuci&oacute;n de recursos y la alta capacidad de nuestro DataCenter, garantiza la alta disponibilidad de la web y correos de nuestros clientes.</p>
      <p class="index_oferta_titulo"><!--<div class="index_oferta" align="center">

<p class="index_oferta_titulo">Ventas</p>

    <div id="chat" class="index_imagen" style="	width:90px; height:85px; cursor:pointer;" onclick="meebo(1)"><img src="img/anuncio9.jpg" border="0" />

    <p class="index_imagen"><u>Haz click aqu�</u></p>

    </div>



    <p class="index_imagen">Realice sus consultas <br />en tiempo real</p>

<!--<embed id="chat" src="http://widget.meebo.com/mm.swf?TyVWsBiFYV" type="application/x-shockwave-flash" width="186" height="216"></embed>

    </div>-->    </p>
    </div>
    <div class="index_oferta" style="border:#fff 1px solid; background-color:transparent;"></div>
    <div class="index_oferta">
      <p class="index_oferta_titulo">NOTIFIQUE</p>
      <p class="index_imagen"><a href="form_notificar.php?TB_iframe=true&amp;height=450&amp;width=545" rel="sexylightbox"><img src="img/anuncio11.jpg" width="100" height="90" alt="DOMINIO" title="DOMINIO" /></a></p>
      <!--    <p class="index_imagen">&nbsp;</p>-->
      <p class="index_parrafo_1">Todo pago realizado en</p>
      <p class="index_parrafo_2">Wester Union, Moneygram,
        
        dep&oacute;sito bancario o interbancario</p>
    </div>

    

    

    <div class="index_oferta">
      
      <p class="index_oferta_titulo">CONSULTAS</p>

    <p class="index_imagen"><a href="form_soporte.php?TB_iframe=true&amp;height=420&amp;width=545" rel="sexylightbox"><img src="img/anuncio12.jpg" width="120" height="120" alt="PAGINA WEB" title="PAGINA WEB" /></a></p>

    <p class="index_parrafo_1">Realice sus Consultas</p>

  </div>

   

    <div style="clear:both"></div>

    <!-- FIN OFERTAS -->

  </div>      

    
  <p>&nbsp;</p>
   <p>&nbsp;</p>

      

     

    <div class="raya"></div>

</div>

<!-- FIN CUERPO -->





<div id="contenedor_pie">



<div id="pie">

  <div id="logo_pie">

  <h1>COMPIHOST.NET, empresa peruana con mas de 6 a�os de experiencia y brindando el servicio de alojamiento web y registro de dominios.</h1>

  </div>

  <div id="slogan_pie">

  <ul>

    <li><a href="soporte.php" title="SOPORTE">SOPORTE</a></li>

    <li><a href="nuestra_tecnologia.php" title="NUESTRA TECNOLOG�A">NUESTRA TECNOLOG&Iacute;A</a></li>

    <li><a href="preguntas_frecuentes.php" title="PREGUNTAS FRECUENTES">PREGUNTAS FRECUENTES</a></li>

    <li><a href="politicas_servicio.php" title="POL�TICAS DEL SERVICIO">POL&Iacute;TICAS DEL SERVICIO</a></li>

    <li><a href="terminos_condiciones.php" title="TERMINOS Y CONDICIONES">TERMINOS Y CONDICIONES</a></li>

  </ul>

  </div>

  <div id="menu_pie">

  <p><strong>Tel&eacute;fono: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email:</strong></p>

  <p>(511) 796 2663 - (511) 780 4649 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ventas@compihost.net</p>


  </div>
 

  <div style="clear:both;"></div>

</div>

</div>

<script type="text/JavaScript">
	$(window).resize(function(){
        	$('.wrapper').css({
	               position:'fixed',
        	       left: ($(window).width() - $('.wrapper').outerWidth())/2,
               		top: ($(window).height() - $('.wrapper').outerHeight())/2
	          });
	});
	// Ejecutamos la función
	$(window).resize();
	$(document).ready(function(){
		$('#sup4').click(function(){
			$('#capa').fadeIn();
			$('#express').fadeIn();
		})
		$('.cerrar,#capa').click(function(){
		$('#capa').fadeOut();
		$('.wrapper').fadeOut();
	})
})
</script>
<!-- Script del Slider -->
<link rel='stylesheet' id='style-css'  href='diapo/diapo.css' type='text/css' media='all'> 
<script type='text/javascript' src='diapo/scripts/jquery.min.js'></script>
<!--[if !IE]><!--><script type='text/javascript' src='diapo/scripts/jquery.mobile-1.0rc2.customized.min.js'></script><!--<![endif]-->
<script type='text/javascript' src='diapo/scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='diapo/scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='diapo/scripts/diapo.js'></script> 

<script>
$(function(){
	$('.pix_diapo').diapo();
});
</script>



<script language="javascript">
function cerrar_chat(){ //cerrar chat
document.getElementById("consulta").style.visibility="hidden";	
document.getElementById("pointer").style.visibility="hidden";
document.getElementById("ventana").style.paddingTop="6px";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/minimizar.png" onclick="abrir_chat();" style="cursor:pointer;"  border="0"/>';	
}



function abrir_chat(){ //abrir chat
document.getElementById("consulta").style.visibility="visible";	
document.getElementById("pointer").style.visibility="visible";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />';
document.getElementById("ventana").style.paddingTop="1px";	
	
	
	} 

</script>



 

<div style="position:fixed; bottom:38px; right:5px; z-index:3000; height:62px;">
<!-- mibew button --><!-- / mibew button -->
<table width="231" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="231" height="51" align="center" valign="top"><a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;"><img src="http://compihost.net/soluciones/chat_compihost/images/boton-consulta.png"  name="consulta" id="consulta" border="0"/></a></td>
  </tr>
  <tr>
    <td height="19" align="center" valign="top">
    
    <table width="150" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="19" height="24" align="center" valign="top">
        <div id="ventana" style="height:14px;" align="center">
      <img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />
        </div>
        </td>
        <td width="131" height="19" align="left" valign="top"><div id="click">
        <a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;">
        <img src="http://compihost.net/soluciones/chat_compihost/images/haz-click.png" width="130" height="19" border="0"/></a></div></td>
      </tr>
    </table>

    
    
    </td>
  </tr>
</table>
<img src="http://compihost.net/soluciones/chat_compihost/images/pointer.png" width="42" height="54" border="0" style="position: absolute; left: 199px; top: 46px;" id="pointer"/></div>





  











 



</body>



</html>


 <!-- Begin Attracta Include 2013-06-02 15:47 -->
<script type='text/javascript'> 
function attracta_loadjs(url) {
   (function() {
       var s = document.createElement('script');
       s.type = 'text/javascript';
       s.async = true;
       s.src = url;
       var x = document.getElementsByTagName('script')[0];
       x.parentNode.insertBefore(s, x);
   })();
}
function attracta_shouldrun() {
   var v = ["/admin/","/adm/","/wp-admin/","/administrator/"];
   for (x in v) if(window.location.pathname.indexOf(v[x]) == 0) return false;
   return true;
}
function attracta_window_width() {
   if (document.body && document.body.offsetWidth) return document.body.offsetWidth;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) return document.documentElement.offsetWidth;
   if (window.innerWidth) return window.innerWidth;
   return 0;
}
function attracta_window_height() {
   if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetHeight ) return document.documentElement.offsetHeight;
   if (window.innerHeight) return window.innerHeight;
   return 0;
}
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17302325-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- End Attracta Include 2013-06-02 15:47 -->

