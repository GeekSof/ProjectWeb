
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>COMPIHOST - Soluciones de Internet</title>

<link rel="stylesheet" type="text/css" href="css/estilos.css"/>

<link rel="icon" href="img/logocom.gif" type="image/gif">

<!-- WRAPER INICIO -->

<link rel="stylesheet" href="css/sexylightbox.css" type="text/css" media="all" />

<script src="js/jquery.js"></script>

<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<script type="text/javascript" src="js/sexylightbox.v2.3.jquery.js"></script>

<script type="text/javascript">

$(document).ready(

    function(){

           SexyLightbox.initialize({color:'00', 

	                                dir: 'sexyimages'

                                  });

              });

</script>

<script type="text/javascript">

	function meebo(valor){

			window.open('meebo.php','Consultas','width=230,height=520,resizable=NO,scrollbars=NO');			reload();

	}

</script>



<!-- WRAPER FIN -->



</head>



<body>

<!-- Envolve Chat -->

<!--Documentar chat--------<script type="text/javascript">

var envoSn=117836;

var envProtoType = (("https:" == document.location.protocol) ? "http://" : "http://");

document.write(unescape("%3Cscript src='" + envProtoType + "d.envolve.com/env.nocache.js' type='text/javascript'%3E%3C/script%3E"));

</script>---------- cerrar chat---->



<div id="capa"></div>
<div id="express" class="wrapper">
	<div class="cerrar">Cerrar(X)</div>
	<iframe src="http://info361903.supersite.srsportal.com/domain.php" width="99%" height="650px" style="margin-bottom:10px;"></iframe>
</div>


<div id="contenedor_cabecera">

<div id="grande"></div>

  <div id="logo">

  <h1>Brindamos soluciones de internet a su medida, gracias a la experiencia que contamos siendo nuestros servicios creación y optimización de página web, mantenimiento, implementación de  hosting y dominio, sistema atención de clientes, entre otros.</h1>

  </div>

  <div id="slogan">

    <p>Soluciones de Internet</p></div>

  <div id="menu_sup">

  	<div style="width:440px; float:right">

        <div class="link_sup" align="right" style="width:40px"><img src="img/home.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px; width:48px;"><a href="index.html" title="INICIO">Inicio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/empresa.png" width="37" height="47"/></div>

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="nosotros.html" title="EMPRESA">Empresa</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/portafolio_icon.png" width="37" height="47"/></div>
        
        


        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="portafolio.html" title="PORTAFOLIO">Portafolio</a></div>

        <div class="link_sup" align="right" style="width:40px"><img src="img/contacto.png" width="37" height="47"/></div>
                
        

        <div class="link_sup" style="padding-top:17px; height:30px;"><a href="contactenos.html" title="CONTÁCTENOS">Contáctenos</a></div>

		<div style="clear:both"></div>        

	</div>

  </div>

  <div style="clear:both"></div>

    <div class="raya"></div>

</div>



<div id="banner">

<div id="contenedor_banner" style="position:relative; background-color:#FFF">

  <div id="menu2" align="center" style="width:164px; height:369px; padding-left:0px; position: static;">

  <ul>

  <li style="width:164px; margin-right:0px; background-color:#FFF;"><a class="som_men" style="background-image:url(img/menu_amarillo.png); background-repeat:no-repeat; background-color:#FFF;" id="sup1" href="promociones.html" title="PROMOCIONES">Promociones</a></li>

  <li><a class="som_men" id="sup2" href="hosting.html" title="HOSTING">Hosting</a></li>
  
  <li><a class="som_men" href="http://info361903.supersite.srsportal.com/domain.php?TB_iframe=true&amp;height=700&amp;width=800" rel="sexylightbox" title="DOMINIO">Dominio</a></li>

  <li><a class="som_men" id="sup3" href="soluciones_web.html" title="SOLUCIONES WEB">Soluciones Web</a></li>

  <li><a class="som_men" id="sup7" href="e_marketing.html" title="E - MARKETING">E - Marketing</a></li>

  <li><a class="som_men" id="sup6" href="soporte.html" title="SOPORTE">Soporte Remoto</a></li>

  <!--<li><a class="som_men" id="sup5" href="sistemas.html" title="SISTEMAS">Sistemas</a></li>   -->

    </ul>

</div>
<div style="background:url(img/tablet.jpg) no-repeat; width:821px; height:373px; position:absolute; left:182px; top:0px; ">

  <section style="overflow:visible;"> 

    	<div style="position: absolute; width:300px; margin:123px 0 0 -90px; padding:0 20px;top: -100px;left: 90px;"> 
                <div class="pix_diapo">
					<div data-thumb="diapo/images/thumbs/up-official-trailer-fake.jpg" title="Haz clic y entérate de nuestras promociones">
                        <iframe width="734" height="324" src="http://www.youtube.com/embed/c1Z9tTjHIMA?rel=0&modestbranding=1&autoplay=1" data-fake="diapo/images/slides/up-official-trailer-fake.jpg" frameborder="0" allowfullscreen ></iframe>
                        
                        <div class="elemHover caption fromLeft elemToHide" style="bottom: 350px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; left:0">
                            You can also display videos, but it requires a "fake image"... read the documentation please
                        </div>
                    </div>

                    <div data-thumb="diapo/images/thumbs/megamind1048.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b1.jpg"></a>
                       <!-- <div class="caption elemHover fromLeft">
                            This is a simple sliding image with caption. You can have more than one caption and decide the layout of the caption via css.
                        </div>-->
                    </div>
                    
<!--                    <div data-thumb="diapo/images/thumbs/megamind_07.jpg">
                        <a href="https://www.facebook.com/COMPIHOST/app_79458893817" target="_blank" title="Haz clic y participa gratis en nuestros Sorteos"><img src="diapo/images/slides/b2.jpg"></a>-->
<!--                        <div class="caption elemHover fromRight" style="bottom:65px; padding-bottom:5px; color:#ff0; text-transform:uppercase">
                            Here you can see two captions.
                        </div>
                        <div class="caption elemHover fromLeft" style="padding-top:5px;">
                            The first are loaded immediately before than the second one
                        </div>-->
<!--                    </div>-->
                    
<!--                    <div data-thumb="diapo/images/thumbs/wall-e.jpg" data-time="7000">
                        <img src="diapo/images/slides/wall-e.jpg">
                        <div class="elemHover caption fromLeft" style="bottom:70px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px;">
                            You can also get the same effect as the caption with:
                        </div>
                        <div class="elemHover button fromTop" data-easing="easeOutExpo" style="left:388px; bottom:78px;">
                            A button
                        </div>
                        <div class="elemHover button button2 fromBottom" data-easing="easeOutExpo" style="left:512px; bottom:78px;">
                            Or two buttons
                        </div>
                        <div class="elemHover fadeIn" style="left:600px; bottom:auto; top:0; padding-top:50px; color:#ff0; font-size:13px; line-height:20px; width:auto; -webkit-border-top-right-radius: 6px; -webkit-border-bottom-right-radius: 6px; -moz-border-radius-topright: 6px; -moz-border-radius-bottomright: 6px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; background:url(diapo/images/demo/arrow_caption.png) no-repeat 230px 30px">
                            Or any other html element...<br>
                            and you can decide the transition time of any slide
                        </div>
                    </div>-->
                    
<!-- Video -->                    
                    
                                     
                    
                    <div data-thumb="diapo/images/thumbs/ratatouille2.jpg">
                        <a href="http://www.compihost.net/web/web_hosting.php" target="_blank" title="Soluciones Web"><img src="diapo/images/slides/b3.jpg"></a>
                    </div>
                    
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 


</div>

<div style="clear:both"></div>

</div>

</div>
<!-- INICIO CUERPO -->

<div id="contenedor_cuerpo">

  <div class="raya"></div>

  <div id="cuerpo">

    <div id="cuerpo_i">

    

    

    

    

      <div class="caja_1">

      <h1 class="fondo1">POLITICAS DEL SERVICIO</h1>

      <p class="c1">

Al utilizar nuestros servicios de alojamiento web, usted acepta acatar nuestras políticas. Se espera que usted use el Internet con respeto, cortesía y responsabilidad, debido a los derechos de los demás usuarios de Internet.

<br /><br />

Esperamos que tenga el conocimiento básico de como funciona el Internet, los tipos de uso generalmente aceptados y los tipos de uso que se evitan.

<br /><br />

Los siguientes usos son inaceptables:

<br /><br />

Ilegalidad en cualquier forma, incluyendo pero no limitando las actividades como distribución no autorizada o copia de software sin licencia, acoso, fraude, tráfico de material obsceno, comercio de drogas y otras actividades ilegales.

<br /><br />

<strong>INTERPRETACIÓN</strong><br />

El proporcionar estas políticas, tiene como intención servir como guía, y en ningún momento pretenden ser exhaustivas. Los actos que violen las leyes, regulaciones o normas aceptadas en la comunidad de Internet, estén o no expresadas en estas políticas, están prohibidas.

<br /><br />

LA EMPRESA se reserva el derecho en todo momento de prohibir actividades que dañen su reputación comercial o su buena voluntad.

<br /><br />

<strong>USO ILEGAL</strong><br />

Los servidores de LA EMPRESA se pueden utilizar solamente para propósitos legales. La transmisión, la distribución o el almacenaje de cualquier material que viole cualquier ley o regulación aplicable se prohibe. Esto incluye, sin ninguna limitación, el material protegido por derechos de autor, la marca registrada, el secreto comercial u otro derecho de propiedad intelectual usada sin la autorización apropiada, y el material que es obsceno, difamatorio, que constituye una amenaza ilegal, o viola leyes del control de la exportación. Ejemplos de contenidos o de conexiones no aceptables: pirateó de software, los programas de los hackers o los archivos Warez, IRC Bots, Mp3 y pornografía.

<br /><br />

Seremos los únicos árbitros en cuanto a qué constituye una violación de esta disposición.

<br /><br />

<strong>SEGURIDAD DEL SISTEMA Y DE LA RED</strong><br />

Las violaciones de la seguridad del sistema o de la red se prohiben, y pueden dar lugar a responsabilidad criminal y civil. Los ejemplos incluyen, pero no se limitan a los siguientes: Acceso, uso, puesta a prueba, o exploración no autorizada de seguridad de los sistemas o de medidas de la autenticación de datos o del tráfico. Interferencia con servicio a cualquier usuario, servidor o red incluyendo, sin la limitación, bombardeo del correo, flooding, tentativas de sobrecargar un sistema y de difundir ataques. Forzar cualquier cabecera del paquete de TCP-IP o de cualquier parte de la información de cabecera en un email.

<br /><br />

<strong>CONDUCTA INAPROPIADA</strong><br />

Nadie publicará información difamatoria, escandalosa, o privada sobre una persona sin su consentimiento, infligiendo intencionalmente daño moral, o violando marcas registradas, derechos de autor, u otros derechos de propiedad intelectual.

<br /><br />

<strong>SPAMMING</strong><br />

Enviar mensajes no solicitados de correo, incluyendo, sin limitación alguna, publicidad comercial y los avisos informativos, son prohibidos explícitamente. Un usuario no utilizará el mail server de otro sitio para retransmitir el correo sin el permiso expreso del sitio.

<br /><br />

Es contrario a la política de LA EMPRESA que los clientes utilicen nuestros servidores para efectuar o para participar en cualesquiera de las actividades siguientes:

<br /><br />

1. Publicar a cualquier USENET u otro newsgroup, foro, lista de correo u otro grupo similar algún mensaje fuera de tópico, acorde a la descripción de la lista;

<br /><br />

2. Enviar correos electrónicos no solicitados o bulk-emails. Como referencia, nosotros consideramos spam cualquier correo que sea enviado a más de 10 personas al mismo tiempo y que ellos no hayan solicitado recibirlo o si tales correos no solicitados provocan quejas de los recipientes.

<br /><br />

 Por favor haga un esfuerzo de limitar el envío de correos en su cuenta a no más de 5000 mensajes por día, no más de 500 por hora y no más de 20 mensajes por minuto (no trate de hacer trucos y usar varias cuentas de correo para enviar de esta forma correos masivos). Esto causa cargas extremas al servidor e impide a otras personas tener acceso a los servicios del servidor. Los sitios con grandes bases de datos de correos, tienen que ser alojados en un plan linux revendedor y son preferible enviarlas a partir de las 12AM a 8AM del este;

<br /><br />

3. Participar en cualesquiera de las actividades precedentes usando el servicio de otro proveedor, pero direccionando tales actividades a través de un servidor de <strong>LA EMPRESA</strong>, o usar un servidor proporcionado por <strong>LA EMPRESA</strong> como buzón para las respuestas;

<br /><br />

4. Falsificar la información de usuario que se proporcionó a <strong>LA EMPRESA</strong> o a otros usuarios del servicio en conexión con el uso de un servicio de <strong>LA EMPRESA</strong>.

<br /><br />

<strong>CONSECUENCIAS DE LA VIOLACION</strong><br />

Al enterarse de una violación a sus Politicas de uso, LA <strong>EMPRESA</strong> iniciará una investigación. Durante la investigación LA <strong>EMPRESA</strong> puede restringir el servicio a su cliente para prevenir alguna actividad no autorizada adicional. Dependiendo de la severidad de la violación, LA <strong>EMPRESA</strong> puede, a su discreción, restringir, suspender, o terminar la cuenta del cliente y/o utilizar otros medios civiles. Si tal violación es una ofensa criminal, <strong>LA EMPRESA</strong> notificará a las instancias apropiadas para la aplicación de la ley conforme a tal violación.

<br /><br />

<strong>MODIFICACIÓN</strong><br />

LA <strong>EMPRESA</strong> se reserva el derecho de agregar, suprimir, o de modificar cualquier disposición de esta política en cualquier momento sin previo aviso. Cualquier persona que quiera reportar alguna violación a estas políticas no dude en contactarse con nosotros.

</p>

      </div>

      









   

 



    



      

    </div>

    

    

    

    

    

    <!-- INICIO OFERTAS -->

    <div id="cuerpo_d" align="center">



    

    

   

       <div id="menu_vertical">

    <ul>

    <li><a href="nuestra_tecnologia.html" title="NUESTRA TECNOLOGÍA">Nuestra Tecnología</a></li>  

    <li><a href="preguntas_frecuentes.html" title="PREGUNTAS FRECUENTES">Preguntas Frecuentes</a></li> 

    <li><a href="politicas_servicio.html" title="POLITICAS DEL SERVICIO">Políticas del Servicio</a></li> 

     <li><a href="terminos_condiciones.html" title="TERMINOS Y CONDICIONES">Términos y Condiciones</a></li> 

    </ul>

    <div style="clear:both"></div>

    </div>
            

	

<!--      <div class="oferta2 mouse" onclick="location.href='dominio.php';">

      <p class="clase_2" style="padding:0px;">S/. 52<br /> 

      <p class="clase_3">por año</p>

      <p class="clase_1">Dominio</p>

      </div> -->

      <div class="oferta3 mouse" onclick="SexyLightbox.show('','cotizar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_4">COTIZAR</p>

      <p class="clase_6">la atención es inmediata</p>

      </div>  

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">NOTIFIQUE</p>

      <p class="clase_1">Todo Pago Realizado</p>

      </div>

      <div class="oferta2 mouse" onclick="SexyLightbox.show('','form_notificar.php?TB_iframe=true&height=420&width=545','sexylightbox','');">

      <p class="clase_2">SOPORTE</p>

      <p class="clase_1">Realice sus Consultas</p>

      </div>

      <div class="oferta3">

      <p class="clase_4">99.9%</p>

      <p class="clase_6">Tiempo de Actividad Garantizado</p>

      </div> 


    </div>

    <!-- FIN OFERTAS -->

    <div style="clear:both"><script language="javascript">
function cerrar_chat(){ //cerrar chat
document.getElementById("consulta").style.visibility="hidden";	
document.getElementById("pointer").style.visibility="hidden";
document.getElementById("ventana").style.paddingTop="6px";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/minimizar.png" onclick="abrir_chat();" style="cursor:pointer;"  border="0"/>';	
}



function abrir_chat(){ //abrir chat
document.getElementById("consulta").style.visibility="visible";	
document.getElementById("pointer").style.visibility="visible";
document.getElementById("ventana").innerHTML='<img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />';
document.getElementById("ventana").style.paddingTop="1px";	
	
	
	} 

</script>



 

<div style="position:fixed; bottom:38px; right:5px; z-index:3000; height:62px;">
<!-- mibew button --><!-- / mibew button -->
<table width="231" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="231" height="51" align="center" valign="top"><a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;"><img src="http://compihost.net/soluciones/chat_compihost/images/boton-consulta.png"  name="consulta" id="consulta" border="0"/></a></td>
  </tr>
  <tr>
    <td height="19" align="center" valign="top">
    
    <table width="150" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="19" height="24" align="center" valign="top">
        <div id="ventana" style="height:14px;" align="center">
      <img src="http://compihost.net/soluciones/chat_compihost/images/cerrar.png" border="0" style="cursor:pointer;" onclick="cerrar_chat();" />
        </div>
        </td>
        <td width="131" height="19" align="left" valign="top"><div id="click">
        <a href="http://compihost.net/soluciones/chat_compihost/client.php?locale=en" target="_blank" onclick="if(navigator.userAgent.toLowerCase().indexOf('opera') != -1 &amp;&amp; window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('http://compihost.net/soluciones/chat_compihost/client.php?locale=en&amp;url='+escape(document.location.href)+'&amp;referrer='+escape(document.referrer), 'webim', 'toolbar=0,scrollbars=0,location=0,status=1,menubar=0,width=640,height=480,resizable=1');this.newWindow.focus();this.newWindow.opener=window;return false;">
        <img src="http://compihost.net/soluciones/chat_compihost/images/haz-click.png" width="130" height="19" border="0"/></a></div></td>
      </tr>
    </table>

    
    
    </td>
  </tr>
</table>
<img src="http://compihost.net/soluciones/chat_compihost/images/pointer.png" width="42" height="54" border="0" style="position: absolute; left: 199px; top: 46px;" id="pointer"/></div>





  









</div>

  </div>

    <div class="raya"></div>

</div>

<!-- FIN CUERPO -->



<div id="contenedor_pie">

<div id="pie">
  <div id="logo_pie">
  <h1>COMPIHOST.NET, empresa peruana con mas de 6 años de experiencia y brindando el servicio de alojamiento web y registro de dominios.</h1>
  </div>
  <div id="slogan_pie">
  <ul>
    <li><a href="soporte.html" title="SOPORTE">SOPORTE</a></li>
    <li><a href="nuestra_tecnologia.html" title="NUESTRA TECNOLOGÍA">NUESTRA TECNOLOGÍA</a></li>
    <li><a href="preguntas_frecuentes.html" title="PREGUNTAS FRECUENTES">PREGUNTAS FRECUENTES</a></li>
    <li><a href="politicas_servicio.html" title="POLÍTICAS DEL SERVICIO">POLÍTICAS DEL SERVICIO</a></li>
    <li><a href="terminos_condiciones.html" title="TERMINOS Y CONDICIONES">TERMINOS Y CONDICIONES</a></li>
  </ul>
  </div>
  <div id="menu_pie">
  <p><strong>Teléfono: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email:</strong></p>
  <p>(511) 796 2663 - (511) 780 4649 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ventas@compihost.net</p>
  </div>
  <div style="clear:both;"></div>
</div>
</div> 
<script type="text/JavaScript">
	$(window).resize(function(){
        	$('.wrapper').css({
	               position:'fixed',
        	       left: ($(window).width() - $('.wrapper').outerWidth())/2,
               		top: ($(window).height() - $('.wrapper').outerHeight())/2
	          });
	});
	// Ejecutamos la función
	$(window).resize();
	$(document).ready(function(){
		$('#sup4').click(function(){
			$('#capa').fadeIn();
			$('#express').fadeIn();
		})
		$('.cerrar,#capa').click(function(){
		$('#capa').fadeOut();
		$('.wrapper').fadeOut();
	})
})
</script>
<!-- Script del Slider -->
<link rel='stylesheet' id='style-css'  href='diapo/diapo.css' type='text/css' media='all'> 
<script type='text/javascript' src='diapo/scripts/jquery.min.js'></script>
<!--[if !IE]><!--><script type='text/javascript' src='diapo/scripts/jquery.mobile-1.0rc2.customized.min.js'></script><!--<![endif]-->
<script type='text/javascript' src='diapo/scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='diapo/scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='diapo/scripts/diapo.js'></script> 

<script>
$(function(){
	$('.pix_diapo').diapo();
});
</script>




</body>



</html>


 <!-- Begin Attracta Include 2013-06-02 15:47 -->
<script type='text/javascript'> 
function attracta_loadjs(url) {
   (function() {
       var s = document.createElement('script');
       s.type = 'text/javascript';
       s.async = true;
       s.src = url;
       var x = document.getElementsByTagName('script')[0];
       x.parentNode.insertBefore(s, x);
   })();
}
function attracta_shouldrun() {
   var v = ["/admin/","/adm/","/wp-admin/","/administrator/"];
   for (x in v) if(window.location.pathname.indexOf(v[x]) == 0) return false;
   return true;
}
function attracta_window_width() {
   if (document.body && document.body.offsetWidth) return document.body.offsetWidth;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) return document.documentElement.offsetWidth;
   if (window.innerWidth) return window.innerWidth;
   return 0;
}
function attracta_window_height() {
   if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
   if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetHeight ) return document.documentElement.offsetHeight;
   if (window.innerHeight) return window.innerHeight;
   return 0;
}
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17302325-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- End Attracta Include 2013-06-02 15:47 -->

